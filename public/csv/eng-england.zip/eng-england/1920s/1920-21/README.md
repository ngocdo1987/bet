

### Standings


~~~
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. Burnley                       42  17  3  1  56:16    6 10  5  23:20    79:36  +43   82
 2. Manchester City               42  19  2  0  50:13    5  4 12  20:37    70:50  +20   78
 3. Bolton Wanderers              42  15  6  0  53:17    4  8  9  24:36    77:53  +24   71
 4. Newcastle United              42  14  3  4  43:18    6  7  8  23:27    66:45  +21   70
 5. Liverpool                     42  11  7  3  41:17    7  8  6  22:18    63:35  +28   69
 6. Tottenham Hotspur             42  15  2  4  46:16    4  7 10  24:32    70:48  +22   66
 7. Everton                       42   9  8  4  40:26    8  5  8  26:29    66:55  +11   64
 8. Middlesbrough                 42  10  6  5  29:21    7  6  8  24:32    53:53        63
 9. Aston Villa                   42  11  4  6  39:21    7  3 11  24:49    63:70   -7   61
10. Arsenal                       42   9  8  4  31:25    6  6  9  28:38    59:63   -4   59
11. Sunderland                    42  11  4  6  34:19    3  9  9  23:41    57:60   -3   55
12. Manchester United             42   9  4  8  34:26    6  6  9  30:42    64:68   -4   55
13. Blackburn Rovers              42   7  9  5  36:27    6  6  9  21:32    57:59   -2   54
14. Preston North End             42  10  4  7  38:25    5  5 11  23:40    61:65   -4   54
15. Huddersfield Town             42  11  4  6  26:16    4  5 12  16:33    42:49   -7   54
16. West Bromwich Albion          42   8  7  6  31:23    5  7  9  23:35    54:58   -4   53
17. Chelsea                       42   9  7  5  35:24    4  6 11  13:34    48:58  -10   52
18. Bradford City                 42   7  9  5  38:28    5  6 10  23:35    61:63   -2   51
19. Oldham Athletic               42   6  9  6  23:26    3  6 12  26:60    49:86  -37   42
20. Sheffield United              42   5 11  5  22:19    1  7 13  20:49    42:68  -26   36
21. Bradford Park Avenue          42   6  5 10  29:35    2  3 16  14:41    43:76  -33   32
22. Derby County                  42   3 12  6  21:23    2  4 15  11:35    32:58  -26   31
~~~

(Source: `1-division1.csv`)


~~~
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. Birmingham City               42  16  4  1  55:13    8  6  7  24:25    79:38  +41   82
 2. Cardiff City                  42  13  5  3  27:9    11  5  5  32:23    59:32  +27   82
 3. Bristol City                  42  14  3  4  35:12    5 10  6  14:17    49:29  +20   70
 4. Blackpool                     42  12  3  6  32:19    8  7  6  22:23    54:42  +12   70
 5. West Ham United               42  13  5  3  38:11    6  5 10  13:19    51:30  +21   67
 6. Notts County                  42  12  5  4  36:17    6  6  9  19:23    55:40  +15   65
 7. South Shields                 42  13  4  4  41:16    4  6 11  20:30    61:46  +15   61
 8. Leyton Orient                 42  13  6  2  31:9     3  7 11  12:33    43:42   +1   61
 9. Fulham                        42  14  4  3  33:12    2  6 13  10:35    43:47   -4   58
10. Sheffield Wednesday           42   9  7  5  31:14    6  4 11  17:34    48:48        56
11. Bury                          42  10  8  3  29:13    5  2 14  16:36    45:49   -4   55
12. Wolverhampton Wanderers       42  11  4  6  34:24    5  2 14  15:42    49:66  -17   54
13. Leeds United                  42  11  5  5  30:14    3  5 13  10:31    40:45   -5   52
14. Leicester City                42  10  8  3  26:11    2  8 11  13:35    39:46   -7   52
15. Hull City                     42   7 10  4  24:18    3 10  8  19:35    43:53  -10   50
16. Nottingham Forest             42   9  6  6  37:26    3  6 12  11:29    48:55   -7   48
17. Rotherham County              42   8  9  4  23:21    4  3 14  14:32    37:53  -16   48
18. Port Vale                     42   7  6  8  28:19    4  8  9  15:30    43:49   -6   47
19. Stoke City                    42   9  5  7  26:16    3  6 12  20:40    46:56  -10   47
20. Coventry City                 42   8  6  7  24:25    4  5 12  15:45    39:70  -31   47
21. Barnsley                      42   9 10  2  31:17    1  6 14  17:33    48:50   -2   46
22. Stockport County              42   8  6  7  30:24    1  6 14  12:51    42:75  -33   39
~~~

(Source: `2-division2.csv`)


~~~
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. Crystal Palace                42  15  4  2  45:17    9  7  5  25:17    70:34  +36   83
 2. Queens Park Rangers           42  14  4  3  38:11    8  5  8  23:21    61:32  +29   75
 3. Southampton                   42  14  5  2  46:10    5 11  5  18:18    64:28  +36   73
 4. Swindon Town                  42  14  5  2  51:17    7  5  9  22:32    73:49  +24   73
 5. Swansea City                  42   9 10  2  32:19    9  5  7  24:26    56:45  +11   69
 6. Watford                       42  14  4  3  40:15    6  4 11  19:29    59:44  +15   68
 7. Millwall                      42  11  5  5  25:8     7  6  8  17:22    42:30  +12   65
 8. Bristol Rovers                42  15  3  3  51:22    3  4 14  17:35    68:57  +11   61
 9. Merthyr Town                  42  13  5  3  46:20    2 10  9  14:29    60:49  +11   60
10. Luton Town                    42  14  6  1  51:15    2  6 13  10:41    61:56   +5   60
11. Plymouth Argyle               42  10  7  4  25:13    1 14  6  10:21    35:34   +1   54
12. Grimsby Town                  42  12  5  4  32:16    3  4 14  17:43    49:59  -10   54
13. Northampton Town              42  11  4  6  32:23    4  4 13  27:52    59:75  -16   53
14. Portsmouth                    42  10  8  3  28:14    2  7 12  18:34    46:48   -2   51
15. Newport County                42   8  5  8  20:23    6  4 11  23:41    43:64  -21   51
16. Southend United               42  13  2  6  32:20    1  6 14  12:41    44:61  -17   50
17. Brighton & Hove Albion        42  11  6  4  28:20    3  2 16  14:41    42:61  -19   50
18. Norwich City                  42   9 10  2  31:14    1  6 14  13:39    44:53   -9   46
19. Exeter City                   42   9  7  5  27:15    1  8 12  12:39    39:54  -15   45
20. Reading                       42   8  4  9  26:22    4  3 14  16:37    42:59  -17   43
21. Brentford                     42   7  9  5  27:23    2  3 16  15:44    42:67  -25   39
22. Gillingham                    42   6  9  6  19:24    2  3 16  15:50    34:74  -40   36
~~~

(Source: `3-division3.csv`)



---
Pld = Matches; W = Matches won; D = Matches drawn; L = Matches lost; F = Goals for; A = Goals against; +/- = Goal differencence; Pts = Points

