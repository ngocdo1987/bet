

### Standings


~~~
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. Liverpool                     42  15  4  2  43:15    7  9  5  20:21    63:36  +27   79
 2. Tottenham Hotspur             42  15  3  3  43:17    6  6  9  22:22    65:39  +26   72
 3. Burnley                       42  16  3  2  49:18    6  2 13  23:36    72:54  +18   71
 4. Aston Villa                   42  16  3  2  50:19    6  0 15  24:36    74:55  +19   69
 5. Bolton Wanderers              42  12  4  5  40:24    8  3 10  28:35    68:59   +9   67
 6. Cardiff City                  42  13  2  6  40:26    6  8  7  21:27    61:53   +8   67
 7. Newcastle United              42  11  5  5  36:19    7  5  9  23:26    59:45  +14   64
 8. Chelsea                       42   9  6  6  17:16    8  6  7  23:27    40:43   -3   63
 9. Manchester City               42  13  7  1  44:21    5  2 14  21:49    65:70   -5   63
10. Middlesbrough                 42  12  6  3  46:19    4  8  9  33:50    79:69  +10   62
11. Sunderland                    42  13  4  4  46:23    3  4 14  14:39    60:62   -2   56
12. Sheffield United              42  11  3  7  32:17    4  7 10  27:37    59:54   +5   55
13. West Bromwich Albion          42   8  6  7  26:23    7  4 10  25:40    51:63  -12   55
14. Huddersfield Town             42  12  3  6  33:14    3  6 12  20:40    53:54   -1   54
15. Arsenal                       42  10  6  5  27:19    5  1 15  20:37    47:56   -9   52
16. Birmingham City               42   9  2 10  25:29    6  5 10  23:31    48:60  -12   52
17. Blackburn Rovers              42   7  6  8  35:31    6  6  9  19:26    54:57   -3   51
18. Preston North End             42  12  7  2  33:20    1  5 15   9:45    42:65  -23   51
19. Oldham Athletic               42   8  7  6  21:15    5  4 12  17:35    38:50  -12   50
20. Everton                       42  10  7  4  42:22    2  5 14  15:33    57:55   +2   48
21. Bradford City                 42   8  5  8  28:30    3  5 13  20:42    48:72  -24   43
22. Manchester United             42   7  7  7  25:26    1  5 15  16:47    41:73  -32   36
~~~

(Source: `1-division1.csv`)


~~~
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. Nottingham Forest             42  13  7  1  29:9     9  5  7  22:21    51:30  +21   78
 2. Barnsley                      42  14  5  2  43:18    8  3 10  24:34    67:52  +15   74
 3. Stoke City                    42   9 11  1  31:11    9  5  7  29:33    60:44  +16   70
 4. West Ham United               42  15  3  3  39:13    5  5 11  13:26    52:39  +13   68
 5. Hull City                     42  13  5  3  36:13    6  5 10  15:28    51:41  +10   67
 6. Fulham                        42  14  5  2  41:8     4  4 13  16:30    57:38  +19   63
 7. South Shields                 42  11  7  3  25:13    6  5 10  18:25    43:38   +5   63
 8. Leeds United                  42  10  8  3  31:12    6  5 10  17:26    48:38  +10   61
 9. Leicester City                42  11  6  4  30:16    3 11  7   9:18    39:34   +5   59
10. Sheffield Wednesday           42  12  4  5  31:24    3 10  8  16:26    47:50   -3   59
11. Bury                          42  11  3  7  35:19    4  7 10  19:36    54:55   -1   55
12. Derby County                  42  11  3  7  34:22    4  6 11  26:42    60:64   -4   54
13. Leyton Orient                 42  12  4  5  33:18    3  5 13  10:32    43:50   -7   54
14. Rotherham County              42   8  9  4  17:7     6  2 13  15:36    32:43  -11   53
15. Crystal Palace                42   9  6  6  28:20    4  7 10  17:31    45:51   -6   52
16. Notts County                  42  10  7  4  34:18    2  8 11  13:33    47:51   -4   51
17. Wolverhampton Wanderers       42   8  7  6  28:19    5  4 12  16:30    44:49   -5   50
18. Blackpool                     42  11  1  9  33:27    4  4 13  11:30    44:57  -13   50
19. Port Vale                     42  10  5  6  28:19    4  3 14  15:38    43:57  -14   50
20. Coventry City                 42   8  5  8  31:21    4  5 12  20:39    51:60   -9   46
21. Bradford Park Avenue          42  10  5  6  32:22    2  4 15  14:40    46:62  -16   45
22. Bristol City                  42  10  3  8  25:18    2  6 13  12:40    37:58  -21   45
~~~

(Source: `2-division2.csv`)


~~~
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. Stockport County              38  13  5  1  36:10   11  3  5  24:11    60:21  +39   80
 2. Darlington                    38  15  2  2  52:7     7  4  8  29:30    81:37  +44   72
 3. Grimsby Town                  38  15  4  0  54:15    6  4  9  18:32    72:47  +25   71
 4. Accrington Stanley            38  15  1  3  50:15    4  2 13  23:42    73:57  +16   60
 5. Hartlepool United             38  10  6  3  33:11    7  2 10  19:28    52:39  +13   59
 6. Crewe Alexandra               38  13  1  5  39:22    5  4 10  21:35    60:57   +3   59
 7. Stalybridge Celtic            38  14  3  2  42:15    4  2 13  20:48    62:63   -1   59
 8. Walsall                       38  15  2  2  52:17    3  1 15  14:48    66:65   +1   57
 9. Ashington                     38  13  2  4  42:22    4  2 13  17:44    59:66   -7   55
10. Durham City                   38  14  0  5  43:20    3  3 13  25:47    68:67   +1   54
11. Southport                     38  11  6  2  39:12    3  4 12  16:32    55:44  +11   52
12. Wrexham                       38  12  4  3  40:17    2  5 12  11:39    51:56   -5   51
13. Chesterfield                  38  12  2  5  33:15    4  1 14  16:52    49:67  -18   51
14. Lincoln City                  38  11  2  6  32:20    3  4 12  16:39    48:59  -11   48
15. Barrow                        38  11  2  6  29:18    3  3 13  13:36    42:54  -12   47
16. Nelson                        38   7  6  6  27:23    6  1 12  21:43    48:66  -18   46
17. Wigan Borough                 38   9  4  6  32:28    2  5 12  14:44    46:72  -26   42
18. Halifax Town                  38   9  4  6  37:28    1  5 13  19:48    56:76  -20   39
19. Tranmere Rovers               38   7  5  7  41:25    2  6 11  10:36    51:61  -10   38
20. Rochdale                      38   9  2  8  34:24    2  2 15  18:53    52:77  -25   37
~~~

(Source: `3a-division3n.csv`)


~~~
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. Plymouth Argyle               42  17  4  0  43:4     8  7  6  20:20    63:24  +39   86
 2. Southampton                   42  14  7  0  50:8     9  8  4  18:13    68:21  +47   84
 3. Luton Town                    42  16  2  3  47:9     6  6  9  17:26    64:35  +29   74
 4. Portsmouth                    42  13  5  3  38:18    5 12  4  24:21    62:39  +23   71
 5. Queens Park Rangers           42  13  7  1  36:12    5  6 10  17:32    53:44   +9   67
 6. Swindon Town                  42  10  7  4  40:21    6  6  9  32:39    72:60  +12   61
 7. Aberdare Athletic             42  11  6  4  38:18    6  4 11  19:33    57:51   +6   61
 8. Brentford                     42  15  2  4  41:17    1  9 11  11:26    52:43   +9   59
 9. Watford                       42   9  9  3  34:21    4  9  8  20:27    54:48   +6   57
10. Merthyr Town                  42  14  2  5  33:15    3  4 14  12:41    45:56  -11   57
11. Swansea City                  42  11  8  2  40:19    2  7 12  10:28    50:47   +3   54
12. Reading                       42  10  5  6  28:15    4  5 12  12:32    40:47   -7   52
13. Bristol Rovers                42   8  8  5  32:24    6  2 13  20:43    52:67  -15   52
14. Gillingham                    42  11  4  6  36:20    3  4 14  11:40    47:60  -13   50
15. Charlton Athletic             42  10  6  5  28:19    3  5 13  15:37    43:56  -13   50
16. Northampton Town              42  13  3  5  30:17    0  8 13  17:54    47:71  -24   50
17. Norwich City                  42   8 10  3  29:17    4  3 14  21:45    50:62  -12   49
18. Millwall                      42   6 13  2  22:10    4  5 12  16:32    38:42   -4   48
19. Brighton & Hove Albion        42   9  6  6  33:19    4  3 14  12:32    45:51   -6   48
20. Newport County                42   8  7  6  22:18    3  5 13  22:43    44:61  -17   45
21. Exeter City                   42   7  5  9  22:29    4  7 10  16:30    38:59  -21   45
22. Southend United               42   7  5  9  23:23    1  6 14  11:51    34:74  -40   35
~~~

(Source: `3b-division3s.csv`)



---
Pld = Matches; W = Matches won; D = Matches drawn; L = Matches lost; F = Goals for; A = Goals against; +/- = Goal differencence; Pts = Points

