

### Standings


~~~
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. Everton                       42  11  8  2  60:28    9  5  7  42:38   102:66  +36   73
 2. Huddersfield Town             42  15  1  5  57:31    7  6  8  34:37    91:68  +23   73
 3. Leicester City                42  14  5  2  66:25    4  7 10  30:47    96:72  +24   66
 4. Bury                          42  13  1  7  53:35    7  3 11  27:45    80:80        64
 5. Derby County                  42  12  4  5  59:30    5  6 10  37:53    96:83  +13   61
 6. Cardiff City                  42  12  7  2  44:27    5  3 13  26:53    70:80  -10   61
 7. Aston Villa                   42  13  3  5  52:30    4  6 11  26:43    78:73   +5   60
 8. Bolton Wanderers              42  12  5  4  47:26    4  6 11  34:40    81:66  +15   59
 9. Newcastle United              42   9  7  5  49:41    6  6  9  30:40    79:81   -2   58
10. Blackburn Rovers              42  13  5  3  41:22    3  4 14  25:56    66:78  -12   57
11. Sheffield United              42  12  4  5  56:42    3  6 12  23:44    79:86   -7   55
12. Manchester United             42  12  6  3  51:27    4  1 16  21:53    72:80   -8   55
13. Burnley                       42  12  5  4  55:31    4  2 15  27:67    82:98  -16   55
14. Portsmouth                    42  13  4  4  40:23    3  3 15  26:67    66:90  -24   55
15. Sunderland                    42   9  5  7  37:29    6  4 11  37:47    74:76   -2   54
16. Arsenal                       42  10  6  5  49:33    3  9  9  33:53    82:86   -4   54
17. Birmingham City               42  10  7  4  36:25    3  8 10  34:50    70:75   -5   54
18. West Ham United               42   9  7  5  48:34    5  4 12  33:54    81:88   -7   53
19. Tottenham Hotspur             42  12  3  6  47:34    3  5 13  27:52    74:86  -12   53
20. Sheffield Wednesday           42   9  6  6  45:29    4  7 10  36:49    81:78   +3   52
21. Liverpool                     42  10  6  5  54:36    3  7 11  30:51    84:87   -3   52
22. Middlesbrough                 42   7  9  5  46:35    4  6 11  35:53    81:88   -7   48
~~~

(Source: `1-division1.csv`)


~~~
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. Manchester City               42  18  2  1  70:27    7  7  7  30:32   100:59  +41   84
 2. Leeds United                  42  16  2  3  63:15    9  5  7  35:34    98:49  +49   82
 3. Chelsea                       42  15  2  4  46:15    8  6  7  29:30    75:45  +30   77
 4. Preston North End             42  15  3  3  62:24    7  6  8  38:42   100:66  +34   75
 5. Stoke City                    42  14  5  2  44:17    8  3 10  34:42    78:59  +19   74
 6. Swansea City                  42  13  6  2  46:17    5  6 10  29:46    75:63  +12   66
 7. Oldham Athletic               42  15  3  3  55:18    4  5 12  20:33    75:51  +24   65
 8. West Bromwich Albion          42  10  7  4  50:28    7  5  9  40:42    90:70  +20   63
 9. Port Vale                     42  11  6  4  45:20    7  2 12  23:37    68:57  +11   62
10. Nottingham Forest             42  10  6  5  54:37    5  4 12  29:47    83:84   -1   55
11. Bristol City                  42  11  5  5  42:18    4  4 13  34:61    76:79   -3   54
12. Grimsby Town                  42   8  6  7  41:41    6  6  9  28:42    69:83  -14   54
13. Barnsley                      42  10  5  6  43:36    4  6 11  22:49    65:85  -20   53
14. Notts County                  42  10  4  7  47:26    3  8 10  21:48    68:74   -6   51
15. Hull City                     42   9  8  4  25:19    3  7 11  16:35    41:54  -13   51
16. Southampton                   42  11  3  7  54:40    3  4 14  14:37    68:77   -9   49
17. Wolverhampton Wanderers       42  11  5  5  43:31    2  5 14  20:60    63:91  -28   49
18. Blackpool                     42  11  3  7  55:43    2  5 14  28:58    83:101 -18   47
19. Fulham                        42  12  7  2  46:22    1  0 20  22:67    68:89  -21   46
20. Reading                       42   9  8  4  32:22    2  5 14  21:53    53:75  -22   46
21. Leyton Orient                 42   9  7  5  32:25    2  5 14  23:60    55:85  -30   45
22. South Shields                 42   5  5 11  30:41    2  4 15  26:70    56:111 -55   30
~~~

(Source: `2-division2.csv`)


~~~
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. Bradford Park Avenue          42  18  2  1  68:22    9  7  5  33:23   101:45  +56   90
 2. Lincoln City                  42  15  4  2  53:20    9  3  9  38:44    91:64  +27   79
 3. Stockport County              42  16  5  0  62:14    7  3 11  27:37    89:51  +38   77
 4. Doncaster Rovers              42  15  4  2  59:18    8  3 10  21:26    80:44  +36   76
 5. Tranmere Rovers               42  14  6  1  68:28    8  3 10  37:44   105:72  +33   75
 6. Darlington                    42  15  1  5  63:28    6  4 11  26:46    89:74  +15   68
 7. Bradford City                 42  15  4  2  59:19    3  8 10  26:41    85:60  +25   66
 8. Southport                     42  15  2  4  55:24    5  3 13  24:46    79:70   +9   65
 9. Accrington Stanley            42  14  4  3  49:22    4  4 13  27:45    76:67   +9   62
10. Wrexham                       42  15  1  5  48:19    3  5 13  16:48    64:67   -3   60
11. Rochdale                      42  13  4  4  45:24    4  3 14  29:53    74:77   -3   58
12. New Brighton                  42  10  7  4  45:22    4  7 10  27:40    72:62  +10   56
13. Halifax Town                  42  11  7  3  47:24    2  8 11  26:47    73:71   +2   54
14. Hartlepool United             42  10  3  8  41:35    6  3 12  28:46    69:81  -12   54
15. Rotherham United              42  11  6  4  39:19    3  5 13  26:50    65:69   -4   53
16. Chesterfield                  42  10  4  7  46:29    3  6 12  25:49    71:78   -7   49
17. Crewe Alexandra               42  10  6  5  51:28    2  4 15  26:58    77:86   -9   46
18. Ashington                     42  10  5  6  54:36    1  6 14  23:67    77:103 -26   44
19. Barrow                        42  10  8  3  41:24    0  3 18  13:78    54:102 -48   41
20. Wigan Borough                 42   8  5  8  30:32    2  5 14  26:65    56:97  -41   40
21. Durham City                   42  10  5  6  37:30    1  2 18  16:70    53:100 -47   40
22. Nelson                        42   8  4  9  50:49    2  2 17  26:87    76:136 -60   36
~~~

(Source: `3a-division3n.csv`)


~~~
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. Millwall                      42  19  2  0  87:15   11  3  7  40:35   127:50  +77   95
 2. Northampton Town              42  17  3  1  67:23    6  6  9  35:41   102:64  +38   78
 3. Plymouth Argyle               42  17  2  2  60:19    6  5 10  25:35    85:54  +31   76
 4. Brighton & Hove Albion        42  14  4  3  51:24    5  6 10  30:45    81:69  +12   67
 5. Swindon Town                  42  12  6  3  60:26    7  3 11  30:43    90:69  +21   66
 6. Southend United               42  14  2  5  48:19    6  4 11  32:45    80:64  +16   66
 7. Crystal Palace                42  15  3  3  46:23    3  9  9  33:49    79:72   +7   66
 8. Exeter City                   42  11  6  4  49:27    6  6  9  21:33    70:60  +10   63
 9. Newport County                42  12  5  4  52:38    6  4 11  29:46    81:84   -3   63
10. Queens Park Rangers           42   8  5  8  37:35    9  4  8  35:36    72:71   +1   60
11. Charlton Athletic             42  12  5  4  34:27    3  8 10  26:43    60:70  -10   58
12. Brentford                     42  12  4  5  49:30    4  4 13  27:44    76:74   +2   56
13. Luton Town                    42  13  5  3  56:27    3  2 16  38:60    94:87   +7   55
14. Watford                       42  10  5  6  42:34    4  5 12  26:44    68:78  -10   52
15. AFC Bournemouth               42  12  6  3  44:24    1  6 14  28:55    72:79   -7   51
16. Gillingham                    42  10  3  8  33:26    3  8 10  29:55    62:81  -19   50
17. Norwich City                  42   9  8  4  41:26    1  8 12  25:44    66:70   -4   46
18. Bristol Rovers                42  11  3  7  41:36    3  1 17  26:57    67:93  -26   46
19. Walsall                       42   9  6  6  52:35    3  3 15  23:66    75:101 -26   45
20. Coventry City                 42   5  8  8  40:36    6  1 14  27:60    67:96  -29   42
21. Merthyr Town                  42   7  6  8  38:40    2  7 12  15:51    53:91  -38   40
22. Torquay United                42   4 10  7  27:36    4  4 13  26:67    53:103 -50   38
~~~

(Source: `3b-division3s.csv`)



---
Pld = Matches; W = Matches won; D = Matches drawn; L = Matches lost; F = Goals for; A = Goals against; +/- = Goal differencence; Pts = Points

