

### Standings


~~~
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. Huddersfield Town             42  10  8  3  31:10   11  8  2  38:18    69:28  +41   79
 2. West Bromwich Albion          42  13  6  2  40:17   10  4  7  18:17    58:34  +24   79
 3. Bolton Wanderers              42  18  2  1  61:13    4  9  8  15:21    76:34  +42   77
 4. Liverpool                     42  13  5  3  43:20    7  5  9  20:35    63:55   +8   70
 5. Sunderland                    42  13  6  2  39:14    6  4 11  25:37    64:51  +13   67
 6. Bury                          42  13  4  4  35:20    4 11  6  19:31    54:51   +3   66
 7. Newcastle United              42  11  6  4  43:18    5 10  6  18:24    61:42  +19   64
 8. Birmingham City               42  10  8  3  27:17    7  4 10  22:36    49:53   -4   63
 9. Notts County                  42  11  6  4  29:12    5  7  9  13:19    42:31  +11   61
10. Manchester City               42  11  7  3  44:29    6  2 13  32:39    76:68   +8   60
11. Cardiff City                  42  11  5  5  35:19    5  6 10  21:32    56:51   +5   59
12. Tottenham Hotspur             42   9  8  4  32:16    6  4 11  20:27    52:43   +9   57
13. West Ham United               42  12  7  2  37:12    3  5 13  25:48    62:60   +2   57
14. Sheffield United              42  10  5  6  34:25    3  8 10  21:38    55:63   -8   52
15. Aston Villa                   42  10  7  4  34:25    3  6 12  24:46    58:71  -13   52
16. Arsenal                       42  12  3  6  33:17    2  2 17  13:41    46:58  -12   47
17. Everton                       42  11  4  6  25:20    1  7 13  15:40    40:60  -20   47
18. Blackburn Rovers              42   7  6  8  31:26    4  7 10  22:40    53:66  -13   46
19. Leeds United                  42   9  8  4  29:17    2  4 15  17:42    46:59  -13   45
20. Burnley                       42   7  8  6  28:31    4  4 13  18:44    46:75  -29   45
21. Preston North End             42   8  2 11  29:35    2  4 15   8:39    37:74  -37   36
22. Nottingham Forest             42   5  6 10  17:23    1  6 14  12:42    29:65  -36   30
~~~

(Source: `1-division1.csv`)


~~~
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. Leicester City                42  15  4  2  58:9     9  7  5  32:23    90:32  +58   83
 2. Manchester United             42  17  3  1  40:6     6  8  7  17:17    57:23  +34   80
 3. Derby County                  42  15  3  3  49:15    7  8  6  22:21    71:36  +35   77
 4. Wolverhampton Wanderers       42  14  1  6  29:19    6  5 10  26:32    55:51   +4   66
 5. Chelsea                       42  11  8  2  31:12    5  7  9  20:25    51:37  +14   63
 6. Portsmouth                    42   7 13  1  28:14    8  5  8  30:36    58:50   +8   63
 7. Port Vale                     42  12  4  5  34:19    5  4 12  14:37    48:56   -8   59
 8. Southampton                   42  12  8  1  29:10    1 10 10  11:26    40:36   +4   57
 9. Hull City                     42  12  6  3  40:14    3  5 13  10:35    50:49   +1   56
10. Fulham                        42  11  6  4  26:15    4  4 13  15:41    41:56  -15   55
11. Leyton Orient                 42   8  7  6  22:13    6  5 10  20:29    42:42        54
12. South Shields                 42   9  6  6  33:21    3 11  7   9:17    42:38   +4   53
13. Sheffield Wednesday           42  12  3  6  36:23    3  5 13  14:33    50:56   -6   53
14. Blackpool                     42   8  5  8  37:26    6  4 11  28:35    65:61   +4   51
15. Barnsley                      42   8  8  5  30:23    5  4 12  16:36    46:59  -13   51
16. Bradford City                 42  11  6  4  26:13    2  6 13  11:37    37:50  -13   51
17. Oldham Athletic               42   9  5  7  24:21    4  6 11  11:30    35:51  -16   50
18. Stockport County              42  10  6  5  26:15    3  5 13  11:42    37:57  -20   50
19. Middlesbrough                 42   6 10  5  22:21    4  9  8  14:23    36:44   -8   49
20. Stoke City                    42   7  8  6  22:17    5  3 13  12:29    34:46  -12   47
21. Crystal Palace                42   8  4  9  23:19    4  6 11  15:35    38:54  -16   46
22. Coventry City                 42  10  6  5  32:26    1  3 17  13:58    45:84  -39   42
~~~

(Source: `2-division2.csv`)


~~~
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. Darlington                    42  16  4  1  50:14    8  6  7  28:19    78:33  +45   82
 2. Nelson                        42  18  2  1  58:14    5  5 11  21:36    79:50  +29   76
 3. New Brighton                  42  17  3  1  56:16    6  4 11  19:34    75:50  +25   76
 4. Southport                     42  17  2  2  41:7     5  5 11  18:30    59:37  +22   73
 5. Rochdale                      42  17  2  2  53:16    4  5 12  22:37    75:53  +22   70
 6. Bradford Park Avenue          42  15  5  1  59:13    4  7 10  25:29    84:42  +42   69
 7. Chesterfield                  42  14  3  4  42:15    3  8 10  18:29    60:44  +16   62
 8. Lincoln City                  42  13  4  4  39:19    5  4 12  14:39    53:58   -5   62
 9. Halifax Town                  42  11  5  5  36:22    5  6 10  20:30    56:52   +4   59
10. Ashington                     42  13  4  4  41:24    3  6 12  27:52    68:76   -8   58
11. Wigan Borough                 42  10  7  4  39:16    5  4 12  23:49    62:65   -3   56
12. Barrow                        42  14  4  3  39:22    2  3 16  12:52    51:74  -23   55
13. Grimsby Town                  42  10  6  5  38:21    5  3 13  22:39    60:60        54
14. Wrexham                       42  11  5  5  37:21    4  3 14  16:40    53:61   -8   53
15. Accrington Stanley            42  12  5  4  43:23    3  3 15  17:49    60:72  -12   53
16. Doncaster Rovers              42  12  5  4  36:17    2  5 14  18:48    54:65  -11   52
17. Durham City                   42  11  6  4  38:17    2  7 12  12:51    50:68  -18   52
18. Crewe Alexandra               42  11  7  3  35:24    2  6 13  18:54    53:78  -25   52
19. Walsall                       42  10  6  5  27:16    3  5 13  17:37    44:53   -9   50
20. Hartlepool United             42   9  8  4  28:21    3  3 15  17:42    45:63  -18   47
21. Tranmere Rovers               42  11  3  7  40:29    3  1 17  19:49    59:78  -19   46
22. Rotherham County              42   6  5 10  27:31    1  2 18  15:57    42:88  -46   28
~~~

(Source: `3a-division3n.csv`)


~~~
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. Swansea City                  42  17  4  0  51:12    6  7  8  17:23    68:35  +33   80
 2. Plymouth Argyle               42  17  3  1  55:12    6  7  8  22:26    77:38  +39   79
 3. Bristol City                  42  14  5  2  40:10    8  4  9  20:31    60:41  +19   75
 4. Swindon Town                  42  17  2  2  51:13    3  9  9  15:25    66:38  +28   71
 5. Newport County                42  13  6  2  35:12    7  3 11  27:30    62:42  +20   69
 6. Millwall                      42  12  5  4  35:14    6  8  7  23:24    58:38  +20   67
 7. Exeter City                   42  13  4  4  37:19    6  5 10  22:29    59:48  +11   66
 8. Northampton Town              42  12  3  6  34:18    8  3 10  17:26    51:44   +7   66
 9. Brighton & Hove Albion        42  14  3  4  43:17    5  5 11  16:28    59:45  +14   65
10. Southend United               42  14  1  6  34:18    5  4 12  17:43    51:61  -10   62
11. Watford                       42  12  3  6  22:20    5  6 10  16:27    38:47   -9   60
12. Norwich City                  42  10  8  3  39:18    4  5 12  14:33    53:51   +2   55
13. Gillingham                    42  11  8  2  25:11    2  6 13  10:33    35:44   -9   53
14. Reading                       42   9  6  6  28:15    5  4 12   9:23    37:38   -1   52
15. Charlton Athletic             42  12  6  3  31:13    1  6 14  15:35    46:48   -2   51
16. Aberdare Athletic             42  13  4  4  40:21    1  5 15  14:46    54:67  -13   51
17. Queens Park Rangers           42  10  6  5  28:19    4  2 15  14:44    42:63  -21   50
18. Bristol Rovers                42  10  5  6  26:13    2  8 11  16:36    42:49   -7   49
19. Luton Town                    42   9 10  2  34:15    1  7 13  15:42    49:57   -8   47
20. AFC Bournemouth               42   8  6  7  20:17    5  2 14  20:41    40:58  -18   47
21. Brentford                     42   8  7  6  28:26    1  0 20  10:65    38:91  -53   34
22. Merthyr Town                  42   8  3 10  24:27    0  2 19  11:50    35:77  -42   29
~~~

(Source: `3b-division3s.csv`)



---
Pld = Matches; W = Matches won; D = Matches drawn; L = Matches lost; F = Goals for; A = Goals against; +/- = Goal differencence; Pts = Points

