

### Standings


~~~
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. Huddersfield Town             42  15  5  1  35:9     8  6  7  25:24    60:33  +27   80
 2. Cardiff City                  42  14  5  2  35:13    8  8  5  26:21    61:34  +27   79
 3. Sunderland                    42  12  7  2  38:20   10  2  9  33:34    71:54  +17   75
 4. Sheffield United              42  12  5  4  39:16    7  7  7  30:33    69:49  +20   69
 5. Bolton Wanderers              42  13  6  2  45:13    5  8  8  23:21    68:34  +34   68
 6. Aston Villa                   42  10 10  1  33:11    8  3 10  19:26    52:37  +15   67
 7. Everton                       42  13  7  1  43:18    5  6 10  19:35    62:53   +9   67
 8. Blackburn Rovers              42  14  5  2  40:13    3  6 12  14:37    54:50   +4   62
 9. Newcastle United              42  13  5  3  40:21    4  5 12  20:33    60:54   +6   61
10. Manchester City               42  11  7  3  34:24    4  5 12  20:47    54:71  -17   57
11. Liverpool                     42  11  5  5  35:20    4  6 11  14:28    49:48   +1   56
12. Notts County                  42   9  7  5  21:15    5  7  9  23:34    44:49   -5   56
13. West Ham United               42  10  6  5  26:17    3  9  9  14:26    40:43   -3   54
14. Birmingham City               42  10  4  7  25:19    3  9  9  16:30    41:49   -8   52
15. Tottenham Hotspur             42   9  6  6  30:22    3  8 10  20:34    50:56   -6   50
16. West Bromwich Albion          42  10  6  5  43:30    2  8 11   8:32    51:62  -11   50
17. Burnley                       42  10  5  6  39:27    2  7 12  16:33    55:60   -5   48
18. Preston North End             42   8  4  9  34:27    4  6 11  18:40    52:67  -15   46
19. Arsenal                       42   8  5  8  25:24    4  4 13  15:39    40:63  -23   45
20. Nottingham Forest             42   7  9  5  19:15    3  3 15  23:49    42:64  -22   42
21. Chelsea                       42   7  9  5  23:21    2  5 14   8:32    31:53  -22   41
22. Middlesbrough                 42   6  4 11  23:23    1  4 16  14:37    37:60  -23   29
~~~

(Source: `1-division1.csv`)


~~~
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. Leeds United                  42  14  5  2  41:10    7  7  7  20:25    61:35  +26   75
 2. Derby County                  42  15  4  2  52:15    6  5 10  23:27    75:42  +33   72
 3. Bury                          42  15  5  1  42:7     6  4 11  21:28    63:35  +28   72
 4. Blackpool                     42  13  7  1  43:12    5  6 10  29:35    72:47  +25   67
 5. Southampton                   42  13  5  3  36:9     4  9  8  16:22    52:31  +21   65
 6. South Shields                 42  13  5  3  34:16    4  5 12  15:34    49:50   -1   61
 7. Sheffield Wednesday           42  15  5  1  42:9     1  7 13  12:42    54:51   +3   60
 8. Stoke City                    42   9 11  1  27:10    5  7  9  17:32    44:42   +2   60
 9. Leicester City                42  13  4  4  43:16    4  4 13  21:38    64:54  +10   59
10. Barnsley                      42  12  7  2  34:16    4  4 13  23:45    57:61   -4   59
11. Oldham Athletic               42  10 10  1  24:12    4  7 10  21:40    45:52   -7   59
12. Leyton Orient                 42  11  7  3  27:10    3  8 10  13:26    40:36   +4   57
13. Stockport County              42  10  7  4  32:21    3  9  9  12:31    44:52   -8   55
14. Manchester United             42  10  7  4  37:15    3  7 11  15:29    52:44   +8   53
15. Crystal Palace                42  11  7  3  37:19    2  6 13  16:46    53:65  -12   52
16. Port Vale                     42   9  5  7  33:29    4  7 10  17:37    50:66  -16   51
17. Bradford City                 42   8  7  6  24:21    3  8 10  11:27    35:48  -13   48
18. Hull City                     42   8  7  6  32:23    2 10  9  14:28    46:51   -5   47
19. Coventry City                 42   9  6  6  34:23    2  7 12  18:45    52:68  -16   46
20. Fulham                        42   9  8  4  30:20    1  6 14  15:36    45:56  -11   44
21. Nelson                        42   8  8  5  32:31    2  5 14   8:43    40:74  -34   43
22. Bristol City                  42   5  8  8  19:26    2  7 12  13:39    32:65  -33   36
~~~

(Source: `2-division2.csv`)


~~~
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. Wolverhampton Wanderers       42  18  3  0  51:10    6 12  3  25:17    76:27  +49   87
 2. Rochdale                      42  17  4  0  40:8     8  8  5  20:18    60:26  +34   87
 3. Chesterfield                  42  16  4  1  54:15    6  6  9  16:24    70:39  +31   76
 4. Rotherham County              42  16  3  2  46:13    7  3 11  24:30    70:43  +27   75
 5. Bradford Park Avenue          42  17  3  1  50:12    4  7 10  19:31    69:43  +26   73
 6. Darlington                    42  16  5  0  51:19    4  3 14  19:34    70:53  +17   68
 7. Southport                     42  13  7  1  30:10    3  7 11  14:32    44:42   +2   62
 8. Ashington                     42  14  4  3  41:21    4  4 13  18:40    59:61   -2   62
 9. Doncaster Rovers              42  13  4  4  41:17    2  8 11  18:36    59:53   +6   57
10. Wigan Borough                 42  12  5  4  39:15    2  9 10  16:38    55:53   +2   56
11. Accrington Stanley            42  12  5  4  35:21    4  3 14  13:40    48:61  -13   56
12. Grimsby Town                  42  11  9  1  30:7     3  4 14  19:40    49:47   +2   55
13. Halifax Town                  42  11  4  6  26:17    4  6 11  16:42    42:59  -17   55
14. Durham City                   42  12  5  4  40:23    3  4 14  19:37    59:60   -1   54
15. Tranmere Rovers               42  11  5  5  32:21    2 10  9  19:39    51:60   -9   54
16. Walsall                       42  10  5  6  31:20    4  3 14  13:39    44:59  -15   50
17. Wrexham                       42   8 11  2  24:12    2  7 12  13:32    37:44   -7   48
18. New Brighton                  42   9  9  3  28:10    2  4 15  12:43    40:53  -13   46
19. Lincoln City                  42   8  8  5  29:22    2  4 15  19:37    48:59  -11   42
20. Crewe Alexandra               42   6  7  8  20:24    1  6 14  12:34    32:58  -26   34
21. Barrow                        42   7  7  7  25:24    1  2 18  10:56    35:80  -45   33
22. Hartlepool United             42   5  7  9  22:24    2  4 15  11:46    33:70  -37   32
~~~

(Source: `3a-division3n.csv`)


~~~
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. Portsmouth                    42  15  3  3  57:11    9  8  4  30:19    87:30  +57   83
 2. Plymouth Argyle               42  13  6  2  46:15   10  3  8  24:19    70:34  +36   78
 3. Millwall                      42  17  3  1  45:11    5  7  9  19:27    64:38  +26   76
 4. Swansea City                  42  18  2  1  39:10    4  6 11  21:38    60:48  +12   74
 5. Brighton & Hove Albion        42  16  4  1  56:12    5  5 11  12:25    68:37  +31   72
 6. Swindon Town                  42  14  5  2  38:11    3  8 10  20:33    58:44  +14   64
 7. Northampton Town              42  14  3  4  40:15    3  8 10  24:32    64:47  +17   62
 8. Luton Town                    42  11  7  3  35:19    5  7  9  15:25    50:44   +6   62
 9. Newport County                42  15  4  2  39:15    2  5 14  17:49    56:64   -8   60
10. Bristol Rovers                42  11  7  3  34:15    4  6 11  18:31    52:46   +6   58
11. Norwich City                  42  13  5  3  45:18    3  3 15  15:41    60:59   +1   56
12. Exeter City                   42  14  3  4  33:17    1  4 16   4:35    37:52  -15   52
13. Aberdare Athletic             42   9  9  3  35:18    3  5 13  10:40    45:58  -13   50
14. Brentford                     42   9  8  4  33:21    5  0 16  21:50    54:71  -17   50
15. Gillingham                    42  11  6  4  27:15    1  7 13  16:43    43:58  -15   49
16. Merthyr Town                  42  11  8  2  33:19    0  8 13  12:46    45:65  -20   49
17. Reading                       42  12  2  7  35:20    1  7 13  16:37    51:57   -6   48
18. Charlton Athletic             42   8  7  6  26:20    3  8 10  12:25    38:45   -7   48
19. Southend United               42  11  7  3  35:19    1  3 17  18:65    53:84  -31   46
20. AFC Bournemouth               42   6  8  7  19:19    5  3 13  21:46    40:65  -25   44
21. Watford                       42   8  8  5  35:18    1  7 13  10:36    45:54   -9   42
22. Queens Park Rangers           42   9  6  6  28:26    2  3 16   9:51    37:77  -40   42
~~~

(Source: `3b-division3s.csv`)



---
Pld = Matches; W = Matches won; D = Matches drawn; L = Matches lost; F = Goals for; A = Goals against; +/- = Goal differencence; Pts = Points

