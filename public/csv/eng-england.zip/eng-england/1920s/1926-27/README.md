

### Standings


~~~
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. Newcastle United              42  19  1  1  64:20    6  5 10  32:38    96:58  +38   81
 2. Sunderland                    42  15  3  3  70:28    6  4 11  28:42    98:70  +28   70
 3. Huddersfield Town             42  13  6  2  41:19    4 11  6  35:41    76:60  +16   68
 4. Bolton Wanderers              42  15  5  1  54:19    4  5 12  30:43    84:62  +22   67
 5. Burnley                       42  15  4  2  55:30    4  5 12  36:50    91:80  +11   66
 6. West Ham United               42   9  6  6  50:36   10  2  9  36:34    86:70  +16   65
 7. Leicester City                42  13  4  4  58:33    4  8  9  27:37    85:70  +15   63
 8. Liverpool                     42  13  4  4  47:27    5  3 13  22:34    69:61   +8   61
 9. Aston Villa                   42  11  4  6  51:34    7  3 11  30:49    81:83   -2   61
10. Sheffield United              42  12  6  3  46:33    5  4 12  28:53    74:86  -12   61
11. Arsenal                       42  12  5  4  47:30    5  4 12  30:56    77:86   -9   60
12. Derby County                  42  14  4  3  60:28    3  3 15  26:45    86:73  +13   58
13. Tottenham Hotspur             42  11  4  6  48:33    5  5 11  28:45    76:78   -2   57
14. Cardiff City                  42  12  3  6  31:17    4  6 11  24:48    55:65  -10   57
15. Birmingham City               42  13  3  5  36:17    4  1 16  28:56    64:73   -9   55
16. Sheffield Wednesday           42  15  3  3  49:29    0  6 15  26:63    75:92  -17   54
17. Manchester United             42   9  8  4  29:19    4  6 11  23:45    52:64  -12   53
18. Blackburn Rovers              42   9  5  7  40:40    6  3 12  37:56    77:96  -19   53
19. Bury                          42   8  5  8  43:38    4  7 10  25:39    68:77   -9   48
20. Everton                       42  10  6  5  35:30    2  4 15  29:60    64:90  -26   46
21. Leeds United                  42   9  7  5  43:31    2  1 18  26:57    69:88  -19   41
22. West Bromwich Albion          42  10  4  7  47:33    1  4 16  18:53    65:86  -21   41
~~~

(Source: `1-division1.csv`)


~~~
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. Middlesbrough                 42  18  2  1  78:23    9  6  6  44:37   122:60  +62   89
 2. Portsmouth                    42  14  4  3  58:17    9  4  8  29:32    87:49  +38   77
 3. Manchester City               42  15  3  3  65:23    7  7  7  43:38   108:61  +47   76
 4. Chelsea                       42  13  7  1  40:17    7  5  9  22:35    62:52  +10   72
 5. Preston North End             42  14  4  3  54:29    6  5 10  20:43    74:72   +2   69
 6. Nottingham Forest             42  14  6  1  57:23    4  7 10  22:32    79:55  +24   67
 7. Hull City                     42  13  4  4  43:19    7  3 11  20:33    63:52  +11   67
 8. Oldham Athletic               42  12  3  6  50:37    7  3 11  24:47    74:84  -10   63
 9. Blackpool                     42  13  5  3  65:26    5  3 13  30:54    95:80  +15   62
10. Port Vale                     42  11  6  4  50:26    5  7  9  38:52    88:78  +10   61
11. Barnsley                      42  13  5  3  56:23    4  4 13  32:64    88:87   +1   60
12. Swansea City                  42  13  5  3  44:21    3  6 12  24:51    68:72   -4   59
13. Southampton                   42   9  8  4  35:22    6  4 11  25:40    60:62   -2   57
14. Reading                       42  14  1  6  47:20    2  7 12  17:52    64:72   -8   56
15. Notts County                  42  11  4  6  45:24    4  1 16  25:72    70:96  -26   50
16. Wolverhampton Wanderers       42  10  4  7  54:30    4  3 14  19:45    73:75   -2   49
17. Fulham                        42  11  4  6  39:31    2  4 15  19:61    58:92  -34   47
18. South Shields                 42  11  7  3  49:24    1  3 17  22:71    71:95  -24   46
19. Grimsby Town                  42   6  7  8  39:39    5  5 11  35:52    74:91  -17   45
20. Leyton Orient                 42   9  3  9  37:35    3  4 14  23:61    60:96  -36   43
21. Darlington                    42  10  3  8  53:42    2  3 16  26:56    79:98  -19   42
22. Bradford City                 42   6  4 11  30:28    1  5 15  20:60    50:88  -38   30
~~~

(Source: `2-division2.csv`)


~~~
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. Stoke City                    42  17  3  1  57:11   10  6  5  35:29    92:40  +52   90
 2. Rochdale                      42  18  2  1  72:22    8  4  9  33:43   105:65  +40   84
 3. Bradford Park Avenue          42  18  3  0  74:21    6  4 11  27:38   101:59  +42   79
 4. Halifax Town                  42  13  6  2  46:23    8  5  8  24:30    70:53  +17   74
 5. Nelson                        42  16  2  3  64:20    6  5 10  40:55   104:75  +29   73
 6. Stockport County              42  13  4  4  60:31    9  3  9  33:38    93:69  +24   73
 7. New Brighton                  42  14  2  5  49:21    5  8  8  33:46    82:67  +15   67
 8. Chesterfield                  42  14  4  3  65:27    6  1 14  27:44    92:71  +21   65
 9. Tranmere Rovers               42  13  5  3  54:22    6  3 12  31:45    85:67  +18   65
10. Doncaster Rovers              42  13  4  4  58:27    5  7  9  23:38    81:65  +16   65
11. Lincoln City                  42   9  5  7  50:33    6  7  8  40:45    90:78  +12   57
12. Southport                     42  11  5  5  54:32    4  4 13  26:53    80:85   -5   54
13. Wrexham                       42  10  5  6  41:26    4  5 12  24:47    65:73   -8   52
14. Walsall                       42  10  4  7  35:22    4  6 11  33:59    68:81  -13   52
15. Crewe Alexandra               42  11  5  5  46:28    3  4 14  25:53    71:81  -10   51
16. Hartlepool United             42  11  4  6  43:26    3  2 16  23:55    66:81  -15   48
17. Ashington                     42   9  8  4  42:30    3  4 14  18:60    60:90  -30   48
18. Wigan Borough                 42  10  6  5  44:28    1  4 16  22:55    66:83  -17   43
19. Rotherham United              42   8  6  7  41:35    2  6 13  29:57    70:92  -22   42
20. Durham City                   42   9  4  8  35:35    3  2 16  23:70    58:105 -47   42
21. Accrington Stanley            42   9  3  9  45:38    1  4 16  17:60    62:98  -36   37
22. Barrow                        42   5  6 10  22:40    2  2 17  12:77    34:117 -83   29
~~~

(Source: `3a-division3n.csv`)


~~~
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. Bristol City                  42  19  1  1  71:24    8  7  6  33:30   104:54  +50   89
 2. Plymouth Argyle               42  17  4  0  52:14    8  6  7  43:47    95:61  +34   85
 3. Millwall                      42  16  2  3  55:19    7  8  6  34:32    89:51  +38   79
 4. Brighton & Hove Albion        42  15  4  2  61:24    6  7  8  18:26    79:50  +29   74
 5. Swindon Town                  42  16  3  2  64:31    5  6 10  36:54   100:85  +15   72
 6. Crystal Palace                42  12  6  3  57:33    6  3 12  27:48    84:81   +3   63
 7. Newport County                42  15  4  2  40:20    4  2 15  17:51    57:71  -14   63
 8. AFC Bournemouth               42  13  2  6  49:24    5  6 10  29:42    78:66  +12   62
 9. Luton Town                    42  12  9  0  48:19    3  5 13  20:47    68:66   +2   59
10. Bristol Rovers                42  12  4  5  46:28    4  5 12  32:52    78:80   -2   57
11. Charlton Athletic             42  13  5  3  44:22    3  3 15  16:39    60:61   -1   56
12. Exeter City                   42  14  4  3  46:18    1  6 14  30:55    76:73   +3   55
13. Queens Park Rangers           42   9  8  4  41:27    6  1 14  24:44    65:71   -6   54
14. Brentford                     42  10  9  2  46:20    3  5 13  24:41    70:61   +9   53
15. Coventry City                 42  11  4  6  44:33    4  3 14  27:53    71:86  -15   52
16. Northampton Town              42  13  4  4  36:23    2  1 18  23:64    59:87  -28   50
17. Southend United               42  12  3  6  44:25    2  3 16  20:52    64:77  -13   48
18. Merthyr Town                  42  11  5  5  42:25    2  4 15  21:55    63:80  -17   48
19. Norwich City                  42  10  5  6  41:25    2  6 13  18:46    59:71  -12   47
20. Watford                       42   9  6  6  36:27    3  2 16  21:60    57:87  -30   44
21. Gillingham                    42  10  5  6  36:26    1  5 15  18:46    54:72  -18   43
22. Aberdare Athletic             42   8  2 11  38:48    1  5 15  24:53    62:101 -39   34
~~~

(Source: `3b-division3s.csv`)



---
Pld = Matches; W = Matches won; D = Matches drawn; L = Matches lost; F = Goals for; A = Goals against; +/- = Goal differencence; Pts = Points

