

### Standings


~~~
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. Preston North End             22   8  1  2  41:12    7  2  2  30:18    71:30  +41   48
 2. Everton                       22   8  2  1  40:15    6  1  4  25:25    65:40  +25   45
 3. Blackburn Rovers              22   9  0  2  59:18    3  3  5  19:23    78:41  +37   39
 4. West Bromwich Albion          22   8  1  2  37:20    3  2  6  10:30    47:50   -3   36
 5. Wolverhampton Wanderers       22   6  3  2  28:14    4  2  5  23:24    51:38  +13   35
 6. Accrington F.C.               22   6  4  1  33:25    3  2  6  20:31    53:56   -3   33
 7. Derby County                  22   8  2  1  32:13    1  1  9  11:42    43:55  -12   30
 8. Bolton Wanderers              22   6  1  4  37:24    3  0  8  17:41    54:65  -11   28
 9. Aston Villa                   22   6  2  3  30:15    1  3  7  13:36    43:51   -8   26
10. Notts County                  22   4  3  4  20:19    2  2  7  23:32    43:51   -8   23
11. Burnley                       22   3  1  7  20:21    1  4  6  16:44    36:65  -29   17
12. Stoke City                    22   2  3  6  18:20    1  1  9   9:49    27:69  -42   13
~~~

(Source: `1-division1.csv`)



---
Pld = Matches; W = Matches won; D = Matches drawn; L = Matches lost; F = Goals for; A = Goals against; +/- = Goal differencence; Pts = Points

