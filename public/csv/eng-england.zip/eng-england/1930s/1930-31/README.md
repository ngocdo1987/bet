

### Standings


~~~
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. Arsenal                       42  14  5  2  67:27   14  5  2  60:32   127:59  +68   94
 2. Aston Villa                   42  17  3  1  86:34    8  6  7  42:44   128:78  +50   84
 3. Sheffield Wednesday           42  14  3  4  65:32    8  5  8  37:43   102:75  +27   74
 4. Portsmouth                    42  11  7  3  46:26    7  6  8  38:41    84:67  +17   67
 5. Huddersfield Town             42  10  8  3  45:27    8  4  9  36:38    81:65  +16   66
 6. Middlesbrough                 42  13  5  3  57:28    6  3 12  41:62    98:90   +8   65
 7. Derby County                  42  12  6  3  56:31    6  4 11  38:48    94:79  +15   64
 8. Manchester City               42  13  2  6  41:29    5  8  8  34:41    75:70   +5   64
 9. Blackburn Rovers              42  14  3  4  54:28    3  5 13  29:56    83:84   -1   59
10. Sunderland                    42  12  4  5  61:38    4  5 12  28:47    89:85   +4   57
11. Liverpool                     42  11  6  4  48:28    4  6 11  38:57    86:85   +1   57
12. Grimsby Town                  42  13  2  6  55:31    4  3 14  27:56    82:87   -5   56
13. Chelsea                       42  13  4  4  42:19    2  6 13  22:48    64:67   -3   55
14. Bolton Wanderers              42  12  6  3  45:26    3  3 15  23:55    68:81  -13   54
15. Leicester City                42  12  4  5  50:38    4  2 15  30:57    80:95  -15   54
16. Sheffield United              42  10  7  4  49:31    4  3 14  29:53    78:84   -6   52
17. Newcastle United              42   9  2 10  41:45    6  4 11  37:42    78:87   -9   51
18. West Ham United               42  11  3  7  56:44    3  5 13  23:50    79:94  -15   50
19. Birmingham City               42  11  3  7  37:28    2  7 12  18:42    55:70  -15   49
20. Leeds United                  42  10  3  8  49:31    2  4 15  19:50    68:81  -13   43
21. Blackpool                     42   8  7  6  41:44    3  3 15  30:81    71:125 -54   43
22. Manchester United             42   6  6  9  30:37    1  2 18  23:78    53:115 -62   29
~~~

(Source: `1-division1.csv`)


~~~
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. Everton                       42  18  1  2  76:31   10  4  7  45:35   121:66  +55   89
 2. West Bromwich Albion          42  14  3  4  40:16    8  7  6  43:33    83:49  +34   76
 3. Tottenham Hotspur             42  15  5  1  64:20    7  2 12  24:35    88:55  +33   73
 4. Wolverhampton Wanderers       42  15  2  4  56:25    6  3 12  28:42    84:67  +17   68
 5. Port Vale                     42  15  3  3  39:16    6  2 13  28:45    67:61   +6   68
 6. Bradford Park Avenue          42  15  4  2  71:24    3  6 12  26:42    97:66  +31   64
 7. Southampton                   42  13  4  4  46:22    6  2 13  28:40    74:62  +12   63
 8. Preston North End             42  12  5  4  55:31    5  6 10  28:33    83:64  +19   62
 9. Burnley                       42  13  5  3  55:30    4  6 11  26:47    81:77   +4   62
10. Bradford City                 42  12  5  4  39:26    5  5 11  22:37    61:63   -2   61
11. Stoke City                    42  11  6  4  34:17    6  4 11  30:54    64:71   -7   61
12. Bury                          42  14  3  4  44:20    5  0 16  31:62    75:82   -7   60
13. Oldham Athletic               42  13  5  3  45:28    3  5 13  16:44    61:72  -11   58
14. Millwall                      42  12  4  5  47:25    4  3 14  24:55    71:80   -9   55
15. Charlton Athletic             42  11  4  6  35:33    4  5 12  24:53    59:86  -27   54
16. Bristol City                  42  11  5  5  29:23    4  3 14  25:59    54:82  -28   53
17. Nottingham Forest             42  12  6  3  54:35    2  3 16  26:50    80:85   -5   51
18. Plymouth Argyle               42  10  3  8  47:33    4  5 12  29:51    76:84   -8   50
19. Barnsley                      42  13  3  5  42:23    0  6 15  17:56    59:79  -20   48
20. Swansea City                  42  11  5  5  40:29    1  5 15  11:45    51:74  -23   46
21. Reading                       42  11  2  8  47:33    1  4 16  25:63    72:96  -24   42
22. Cardiff City                  42   7  6  8  32:31    1  3 17  15:56    47:87  -40   33
~~~

(Source: `2-division2.csv`)


~~~
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. Chesterfield                  42  19  1  1  66:22    7  5  9  36:35   102:57  +45   84
 2. Lincoln City                  42  16  3  2  60:19    9  4  8  42:40   102:59  +43   82
 3. Tranmere Rovers               42  15  4  2  73:27    8  3 10  38:48   111:75  +36   76
 4. Wrexham                       42  16  4  1  61:25    5  8  8  33:37    94:62  +32   75
 5. Southport                     42  15  3  3  52:19    7  6  8  36:37    88:56  +32   75
 6. Hull City                     42  12  7  2  64:20    8  3 10  35:35    99:55  +44   70
 7. Stockport County              42  15  5  1  54:19    5  4 12  23:42    77:61  +16   69
 8. Carlisle United               42  13  4  4  68:32    7  1 13  30:49    98:81  +17   65
 9. Wigan Borough                 42  14  4  3  48:25    5  1 15  28:61    76:86  -10   62
10. Gateshead                     42  14  4  3  46:22    2  9 10  25:51    71:73   -2   61
11. York City                     42  15  3  3  59:30    3  3 15  26:52    85:82   +3   60
12. Darlington                    42   9  6  6  44:30    7  4 10  27:29    71:59  +12   58
13. Accrington Stanley            42  14  2  5  51:31    1  7 13  33:77    84:108 -24   54
14. Barrow                        42  13  4  4  45:23    2  3 16  23:66    68:89  -21   52
15. Rotherham United              42   9  6  6  50:34    4  6 11  31:49    81:83   -2   51
16. Doncaster Rovers              42   9  8  4  40:18    4  3 14  25:47    65:65        50
17. Crewe Alexandra               42  13  2  6  52:35    1  4 16  14:58    66:93  -27   48
18. Halifax Town                  42  11  6  4  30:16    2  3 16  25:73    55:89  -34   48
19. New Brighton                  42  12  4  5  36:25    1  4 16  14:51    50:76  -26   47
20. Hartlepool United             42  10  2  9  47:37    2  4 15  20:49    67:86  -19   42
21. Rochdale                      42   9  1 11  42:50    3  5 13  20:57    62:107 -45   42
22. Nelson                        42   6  7  8  28:40    0  0 21  15:73    43:113 -70   25
~~~

(Source: `3a-division3n.csv`)


~~~
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. Notts County                  42  16  4  1  58:13    8  7  6  39:33    97:46  +51   83
 2. Crystal Palace                42  17  2  2  71:20    5  5 11  36:51   107:71  +36   73
 3. Brentford                     42  14  3  4  62:30    8  3 10  28:34    90:64  +26   72
 4. Southend United               42  16  0  5  53:26    6  5 10  23:34    76:60  +16   71
 5. Northampton Town              42  10  6  5  37:20    8  6  7  40:39    77:59  +18   66
 6. Brighton & Hove Albion        42  13  5  3  45:20    4 10  7  23:33    68:53  +15   66
 7. Luton Town                    42  15  3  3  61:17    4  5 12  15:34    76:51  +25   65
 8. Queens Park Rangers           42  15  0  6  57:23    5  3 13  25:52    82:75   +7   63
 9. Fulham                        42  15  3  3  49:21    3  4 14  28:54    77:75   +2   61
10. Torquay United                42  13  5  3  56:26    4  4 13  24:58    80:84   -4   60
11. Swindon Town                  42  15  5  1  68:29    3  1 17  21:65    89:94   -5   60
12. Exeter City                   42  12  6  3  55:35    5  2 14  29:55    84:90   -6   59
13. AFC Bournemouth               42  11  7  3  39:22    4  6 11  33:51    72:73   -1   58
14. Coventry City                 42  11  4  6  55:28    5  5 11  20:37    75:65  +10   57
15. Bristol Rovers                42  12  3  6  49:36    4  5 12  26:56    75:92  -17   56
16. Gillingham                    42  10  6  5  40:29    4  4 13  21:47    61:76  -15   52
17. Walsall                       42   9  5  7  44:38    5  4 12  34:57    78:95  -17   51
18. Watford                       42   9  4  8  41:29    5  3 13  31:46    72:75   -3   49
19. Leyton Orient                 42  12  3  6  47:33    2  4 15  16:58    63:91  -28   49
20. Thames                        42  12  5  4  34:20    1  3 17  20:73    54:93  -39   47
21. Newport County                42  10  5  6  45:31    1  1 19  24:80    69:111 -42   39
22. Norwich City                  42  10  7  4  37:20    0  1 20  10:56    47:76  -29   38
~~~

(Source: `3b-division3s.csv`)



---
Pld = Matches; W = Matches won; D = Matches drawn; L = Matches lost; F = Goals for; A = Goals against; +/- = Goal differencence; Pts = Points

