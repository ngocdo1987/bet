

### Standings


~~~
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. Arsenal                       42  15  4  2  52:16    6  6  9  25:28    77:44  +33   73
 2. Wolverhampton Wanderers       42  11  8  2  47:21    9  3  9  25:28    72:49  +23   71
 3. Preston North End             42   9  9  3  34:21    7  8  6  30:23    64:44  +20   65
 4. Middlesbrough                 42  12  4  5  40:26    7  4 10  32:39    72:65   +7   65
 5. Brentford                     42  10  6  5  44:27    8  3 10  25:32    69:59  +10   63
 6. Charlton Athletic             42  14  5  2  43:14    2  9 10  22:37    65:51  +14   62
 7. Bolton Wanderers              42  11  6  4  38:22    4  9  8  26:38    64:60   +4   60
 8. Sunderland                    42  12  6  3  32:18    2 10  9  23:39    55:57   -2   58
 9. Leeds United                  42  11  6  4  38:26    3  9  9  26:43    64:69   -5   57
10. Blackpool                     42  10  5  6  33:26    6  3 12  28:40    61:66   -5   56
11. Liverpool                     42   9  5  7  40:30    6  6  9  25:41    65:71   -6   56
12. Huddersfield Town             42  11  3  7  29:24    6  2 13  26:44    55:68  -13   56
13. Everton                       42  11  5  5  54:34    5  2 14  25:41    79:75   +4   55
14. Chelsea                       42  11  6  4  40:22    3  7 11  25:43    65:65        55
15. Derby County                  42  10  5  6  42:36    5  5 11  24:51    66:87  -21   55
16. Leicester City                42   9  6  6  31:26    5  5 11  23:49    54:75  -21   53
17. Stoke City                    42  10  7  4  42:21    3  5 13  16:38    58:59   -1   51
18. Portsmouth                    42  11  6  4  41:22    2  6 13  21:46    62:68   -6   51
19. Grimsby Town                  42  11  5  5  29:23    2  7 12  22:45    51:68  -17   51
20. Manchester City               42  12  2  7  49:33    2  6 13  31:44    80:77   +3   50
21. West Bromwich Albion          42  10  5  6  46:36    4  3 14  28:55    74:91  -17   50
22. Birmingham City               42   7 11  3  34:28    3  7 11  24:34    58:62   -4   48
~~~

(Source: `1-division1.csv`)


~~~
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. Aston Villa                   42  17  2  2  50:12    8  5  8  23:23    73:35  +38   82
 2. Manchester United             42  15  3  3  50:18    7  6  8  32:32    82:50  +32   75
 3. Sheffield United              42  15  4  2  46:19    7  5  9  27:37    73:56  +17   75
 4. Coventry City                 42  12  5  4  31:15    8  7  6  35:30    66:45  +21   72
 5. Tottenham Hotspur             42  14  3  4  46:16    5  3 13  29:38    75:54  +21   63
 6. Burnley                       42  15  4  2  35:11    2  6 13  19:43    54:54        61
 7. Bradford Park Avenue          42  13  4  4  51:22    4  5 12  18:34    69:56  +13   60
 8. Fulham                        42  10  7  4  44:23    6  4 11  17:34    61:57   +4   59
 9. Bury                          42  12  3  6  43:26    6  2 13  20:34    63:60   +3   59
10. Chesterfield                  42  12  2  7  39:24    4  7 10  24:39    63:63        57
11. West Ham United               42  13  5  3  34:16    1  9 11  19:36    53:52   +1   56
12. Luton Town                    42  10  6  5  53:36    5  4 12  36:50    89:86   +3   55
13. Plymouth Argyle               42  10  7  4  40:30    4  5 12  17:35    57:65   -8   54
14. Southampton                   42  12  6  3  42:26    3  3 15  13:51    55:77  -22   54
15. Norwich City                  42  11  5  5  35:28    3  6 12  21:47    56:75  -19   53
16. Sheffield Wednesday           42  10  5  6  27:21    4  5 12  22:35    49:56   -7   52
17. Blackburn Rovers              42  13  6  2  51:29    1  4 16  20:50    71:79   -8   52
18. Swansea City                  42  12  6  3  31:21    1  6 14  14:52    45:73  -28   51
19. Newcastle United              42  12  4  5  38:18    2  4 15  13:40    51:58   -7   50
20. Nottingham Forest             42  12  3  6  29:21    2  5 14  18:39    47:60  -13   50
21. Barnsley                      42   7 11  3  30:20    4  3 14  20:44    50:64  -14   47
22. Stockport County              42   8  6  7  24:24    3  3 15  19:46    43:70  -27   42
~~~

(Source: `2-division2.csv`)


~~~
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. Tranmere Rovers               42  15  4  2  57:21    8  6  7  24:20    81:41  +40   79
 2. Doncaster Rovers              42  15  4  2  48:16    6  8  7  26:33    74:49  +25   75
 3. Hull City                     42  11  8  2  51:19    9  5  7  29:24    80:43  +37   73
 4. Gateshead                     42  15  5  1  53:20    5  6 10  31:39    84:59  +25   71
 5. Oldham Athletic               42  16  4  1  48:18    3  9  9  19:28    67:46  +21   70
 6. Rotherham United              42  13  6  2  45:21    7  4 10  23:35    68:56  +12   70
 7. Lincoln City                  42  14  3  4  48:17    5  5 11  18:33    66:50  +16   65
 8. Crewe Alexandra               42  14  3  4  47:17    4  6 11  24:36    71:53  +18   63
 9. Chester                       42  13  4  4  54:31    3  8 10  23:41    77:72   +5   60
10. Wrexham                       42  14  4  3  37:15    2  7 12  21:48    58:63   -5   59
11. York City                     42  11  4  6  40:25    5  6 10  30:43    70:68   +2   58
12. Carlisle United               42  11  5  5  35:19    4  4 13  22:48    57:67  -10   54
13. New Brighton                  42  12  5  4  43:18    3  3 15  17:43    60:61   -1   53
14. Bradford City                 42  12  6  3  46:21    2  4 15  20:48    66:69   -3   52
15. Port Vale                     42  11  8  2  45:27    1  6 14  20:46    65:73   -8   50
16. Rochdale                      42   7 10  4  38:27    6  1 14  29:51    67:78  -11   50
17. Southport                     42   8  8  5  30:26    4  6 11  23:56    53:82  -29   50
18. Halifax Town                  42   9  7  5  24:19    3  5 13  20:47    44:66  -22   48
19. Darlington                    42  10  4  7  37:31    1  6 14  17:48    54:79  -25   43
20. Barrow                        42   9  6  6  28:20    2  4 15  13:51    41:71  -30   43
21. Hartlepool United             42  10  8  3  36:20    0  4 17  17:60    53:80  -27   42
22. Accrington Stanley            42   9  2 10  31:32    2  5 14  14:43    45:75  -30   40
~~~

(Source: `3a-division3n.csv`)


~~~
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. Millwall                      42  15  3  3  53:15    8  7  6  30:22    83:37  +46   79
 2. Bristol City                  42  14  6  1  37:13    7  7  7  31:27    68:40  +28   76
 3. Queens Park Rangers           42  15  3  3  44:17    7  6  8  36:30    80:47  +33   75
 4. Watford                       42  14  4  3  50:15    7  7  7  23:28    73:43  +30   74
 5. Brighton & Hove Albion        42  15  3  3  40:16    6  6  9  24:28    64:44  +20   72
 6. Reading                       42  17  2  2  44:21    3  9  9  27:42    71:63   +8   71
 7. Crystal Palace                42  14  4  3  45:17    4  8  9  22:30    67:47  +20   66
 8. Swindon Town                  42  12  4  5  33:19    5  6 10  16:30    49:49        61
 9. Northampton Town              42  12  4  5  30:19    5  5 11  21:38    51:57   -6   60
10. Cardiff City                  42  13  7  1  57:22    2  5 14  10:32    67:54  +13   57
11. Notts County                  42  10  6  5  29:17    6  3 12  21:33    50:50        57
12. Southend United               42  12  5  4  43:23    3  5 13  27:45    70:68   +2   55
13. AFC Bournemouth               42   8 10  3  36:19    6  2 13  20:37    56:56        54
14. Mansfield Town                42  12  5  4  46:26    3  4 14  16:41    62:67   -5   54
15. Bristol Rovers                42  10  7  4  28:20    3  6 12  18:41    46:61  -15   52
16. Exeter City                   42  10  4  7  37:32    3  8 10  20:38    57:70  -13   51
17. Aldershot                     42  11  4  6  23:14    4  1 16  16:45    39:59  -20   50
18. Newport County                42   9 10  2  31:15    2  6 13  12:37    43:52   -9   49
19. Leyton Orient                 42  10  7  4  27:19    3  0 18  14:42    41:61  -20   46
20. Walsall                       42  10  4  7  34:37    1  3 17  18:51    52:88  -36   40
21. Torquay United                42   7  5  9  22:28    2  7 12  16:45    38:73  -35   39
22. Gillingham                    42   9  5  7  25:25    1  1 19  11:52    36:77  -41   36
~~~

(Source: `3b-division3s.csv`)



---
Pld = Matches; W = Matches won; D = Matches drawn; L = Matches lost; F = Goals for; A = Goals against; +/- = Goal differencence; Pts = Points

