

### Standings


~~~
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. Sunderland                    42  17  2  2  71:33    8  4  9  38:41   109:74  +35   81
 2. Stoke City                    42  13  3  5  35:24    7  4 10  22:33    57:57        67
 3. Derby County                  42  13  5  3  43:23    5  7  9  18:29    61:52   +9   66
 4. Huddersfield Town             42  12  7  2  32:15    6  5 10  27:41    59:56   +3   66
 5. Brentford                     42  11  5  5  48:25    6  7  8  33:35    81:60  +21   63
 6. Preston North End             42  15  3  3  44:18    3  5 13  23:46    67:64   +3   62
 7. Arsenal                       42   9  9  3  44:22    6  6  9  34:26    78:48  +30   60
 8. Manchester City               42  13  2  6  44:17    4  6 11  24:43    68:60   +8   59
 9. Portsmouth                    42  14  4  3  39:22    3  4 14  15:45    54:67  -13   59
10. Chelsea                       42  11  7  3  39:27    4  6 11  26:45    65:72   -7   58
11. Leeds United                  42  11  5  5  41:23    4  6 11  25:41    66:64   +2   56
12. Birmingham City               42  10  6  5  38:31    5  5 11  23:32    61:63   -2   56
13. Grimsby Town                  42  13  4  4  44:20    4  1 16  21:53    65:73   -8   56
14. Middlesbrough                 42  12  6  3  56:23    3  4 14  28:47    84:70  +14   55
15. Wolverhampton Wanderers       42  13  7  1  59:28    2  3 16  18:48    77:76   +1   55
16. Bolton Wanderers              42  11  4  6  41:27    3  9  9  26:49    67:76   -9   55
17. West Bromwich Albion          42  12  3  6  54:31    4  3 14  35:57    89:88   +1   54
18. Everton                       42  12  5  4  61:31    1  8 12  28:58    89:89        52
19. Liverpool                     42  11  4  6  43:23    2  8 11  17:41    60:64   -4   51
20. Sheffield Wednesday           42   9  8  4  35:23    4  4 13  28:54    63:77  -14   51
21. Aston Villa                   42   7  6  8  47:56    6  3 12  34:54    81:110 -29   48
22. Blackburn Rovers              42  10  6  5  32:24    2  3 16  23:72    55:96  -41   45
~~~

(Source: `1-division1.csv`)


~~~
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. Manchester United             42  16  3  2  55:16    6  9  6  30:27    85:43  +42   78
 2. Charlton Athletic             42  15  6  0  53:17    7  5  9  32:41    85:58  +27   77
 3. West Ham United               42  13  5  3  51:23    9  3  9  39:45    90:68  +22   74
 4. Sheffield United              42  15  4  2  51:15    5  8  8  28:35    79:50  +29   72
 5. Plymouth Argyle               42  15  2  4  50:20    5  6 10  21:37    71:57  +14   68
 6. Tottenham Hotspur             42  12  6  3  60:25    6  7  8  31:30    91:55  +36   67
 7. Leicester City                42  14  5  2  53:19    5  5 11  26:38    79:57  +22   67
 8. Newcastle United              42  13  5  3  56:27    7  1 13  32:52    88:79   +9   66
 9. Blackpool                     42  14  3  4  64:34    4  4 13  29:38    93:72  +21   61
10. Norwich City                  42  14  2  5  47:24    3  7 11  25:41    72:65   +7   60
11. Fulham                        42  11  6  4  58:24    4  8  9  18:28    76:52  +24   59
12. Bradford City                 42  12  7  2  32:18    3  6 12  23:47    55:65  -10   58
13. Swansea City                  42  11  3  7  42:26    4  6 11  25:50    67:76   -9   54
14. Bury                          42  10  6  5  41:27    3  6 12  25:57    66:84  -18   51
15. Southampton                   42  11  3  7  32:24    3  6 12  15:41    47:65  -18   51
16. Doncaster Rovers              42  10  7  4  28:17    4  2 15  23:54    51:71  -20   51
17. Bradford Park Avenue          42  13  6  2  43:26    1  3 17  19:58    62:84  -22   51
18. Burnley                       42   9  8  4  35:21    3  5 13  15:38    50:59   -9   49
19. Nottingham Forest             42   8  8  5  43:22    4  3 14  26:54    69:76   -7   47
20. Barnsley                      42   9  4  8  40:32    3  5 13  14:48    54:80  -26   45
21. Port Vale                     42  10  5  6  34:30    2  3 16  22:76    56:106 -50   44
22. Hull City                     42   4  7 10  33:45    1  3 17  14:66    47:111 -64   25
~~~

(Source: `2-division2.csv`)


~~~
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. Chesterfield                  42  15  3  3  60:14    9  9  3  32:25    92:39  +53   84
 2. Chester                       42  14  5  2  69:18    8  6  7  31:27   100:45  +55   77
 3. Tranmere Rovers               42  17  2  2  75:28    5  9  7  18:30    93:58  +35   77
 4. Lincoln City                  42  18  1  2  64:14    4  8  9  27:37    91:51  +40   75
 5. Stockport County              42  15  2  4  45:18    5  6 10  20:31    65:49  +16   68
 6. Crewe Alexandra               42  14  4  3  55:31    5  5 11  25:45    80:76   +4   66
 7. Oldham Athletic               42  13  5  3  60:25    5  4 12  26:48    86:73  +13   63
 8. Accrington Stanley            42  12  5  4  43:24    5  3 13  20:48    63:72   -9   59
 9. Walsall                       42  15  2  4  58:13    1  7 13  21:46    79:59  +20   57
10. Rotherham United              42  14  3  4  49:13    2  6 13  17:53    66:66        57
11. Hartlepool United             42  13  6  2  41:18    2  6 13  16:43    57:61   -4   57
12. Darlington                    42  16  3  2  60:26    1  3 17  14:53    74:79   -5   57
13. Carlisle United               42  13  5  3  44:19    1  7 13  12:43    56:62   -6   54
14. Gateshead                     42  11 10  0  37:18    2  4 15  19:58    56:76  -20   53
15. Halifax Town                  42  12  3  6  34:22    3  4 14  23:39    57:61   -4   52
16. Wrexham                       42  12  3  6  39:18    3  4 14  27:57    66:75   -9   52
17. Barrow                        42   9  9  3  33:16    4  3 14  25:49    58:65   -7   51
18. Mansfield Town                42  13  5  3  55:25    1  4 16  25:66    80:91  -11   51
19. York City                     42  10  8  3  41:28    3  4 14  21:67    62:95  -33   51
20. Rochdale                      42   8 10  3  35:26    2  3 16  23:62    58:88  -30   43
21. Southport                     42   9  8  4  31:26    2  1 18  17:64    48:90  -42   42
22. New Brighton                  42   8  5  8  29:33    1  1 19  14:66    43:99  -56   33
~~~

(Source: `3a-division3n.csv`)


~~~
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. Coventry City                 42  19  1  1  75:12    5  8  8  27:33   102:45  +57   81
 2. Reading                       42  18  0  3  52:20    8  2 11  35:42    87:62  +25   80
 3. Luton Town                    42  13  6  2  56:20    9  6  6  25:25    81:45  +36   78
 4. Queens Park Rangers           42  14  4  3  55:19    8  5  8  29:34    84:53  +31   75
 5. Crystal Palace                42  15  4  2  64:20    7  1 13  32:54    96:74  +22   71
 6. Watford                       42  12  3  6  47:29    8  6  7  33:25    80:54  +26   69
 7. Brighton & Hove Albion        42  13  4  4  48:25    5  4 12  22:38    70:63   +7   62
 8. AFC Bournemouth               42   9  6  6  36:26    7  5  9  24:30    60:56   +4   59
 9. Notts County                  42  10  5  6  40:25    5  7  9  20:32    60:57   +3   57
10. Torquay United                42  14  4  3  41:27    2  5 14  21:35    62:62        57
11. Bristol City                  42  11  5  5  32:21    4  5 12  16:38    48:59  -11   55
12. Leyton Orient                 42  13  2  6  34:15    3  4 14  21:46    55:61   -6   54
13. Aldershot                     42   9  6  6  29:21    5  6 10  24:40    53:61   -8   54
14. Millwall                      42   9  8  4  33:21    5  4 12  25:50    58:71  -13   54
15. Northampton Town              42  12  5  4  38:24    3  3 15  24:66    62:90  -28   53
16. Gillingham                    42   9  5  7  34:25    5  4 12  32:52    66:77  -11   51
17. Bristol Rovers                42  11  6  4  48:31    3  3 15  21:64    69:95  -26   51
18. Swindon Town                  42  10  5  6  43:33    4  3 14  21:40    64:73   -9   50
19. Southend United               42   8  7  6  38:21    5  3 13  23:41    61:62   -1   49
20. Cardiff City                  42  11  5  5  37:23    2  5 14  23:50    60:73  -13   49
21. Newport County                42   8  4  9  36:44    3  5 13  24:67    60:111 -51   42
22. Exeter City                   42   7  5  9  38:41    1  6 14  21:52    59:93  -34   35
~~~

(Source: `3b-division3s.csv`)



---
Pld = Matches; W = Matches won; D = Matches drawn; L = Matches lost; F = Goals for; A = Goals against; +/- = Goal differencence; Pts = Points

