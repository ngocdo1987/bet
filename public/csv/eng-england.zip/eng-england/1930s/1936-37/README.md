

### Standings


~~~
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. Manchester City               42  15  5  1  56:22    7  8  6  51:39   107:61  +46   79
 2. Charlton Athletic             42  15  5  1  37:13    6  7  8  21:36    58:49   +9   75
 3. Arsenal                       42  10 10  1  43:20    8  6  7  37:29    80:49  +31   70
 4. Derby County                  42  13  3  5  58:39    8  4  9  38:51    96:90   +6   70
 5. Wolverhampton Wanderers       42  16  2  3  63:24    5  3 13  21:43    84:67  +17   68
 6. Middlesbrough                 42  14  6  1  49:22    5  2 14  25:49    74:71   +3   65
 7. Brentford                     42  14  5  2  58:32    4  5 12  24:46    82:78   +4   64
 8. Sunderland                    42  17  2  2  59:24    2  4 15  30:63    89:87   +2   63
 9. Portsmouth                    42  13  3  5  41:29    4  7 10  21:37    62:66   -4   61
10. Grimsby Town                  42  13  3  5  60:32    4  4 13  26:49    86:81   +5   58
11. Stoke City                    42  12  6  3  52:27    3  6 12  20:30    72:57  +15   57
12. Chelsea                       42  11  6  4  36:21    3  7 11  16:34    52:55   -3   55
13. Preston North End             42  10  6  5  35:28    4  7 10  21:39    56:67  -11   55
14. Birmingham City               42   9  7  5  36:24    4  8  9  28:36    64:60   +4   54
15. West Bromwich Albion          42  13  3  5  45:32    3  3 15  32:66    77:98  -21   54
16. Everton                       42  12  7  2  56:23    2  2 17  25:55    81:78   +3   51
17. Huddersfield Town             42  12  5  4  39:21    0 10 11  23:43    62:64   -2   51
18. Leeds United                  42  14  3  4  44:20    1  1 19  16:60    60:80  -20   49
19. Liverpool                     42   9  8  4  38:26    3  3 15  24:58    62:84  -22   47
20. Bolton Wanderers              42   6  6  9  22:33    4  8  9  21:33    43:66  -23   44
21. Manchester United             42   8  9  4  29:26    2  3 16  26:52    55:78  -23   42
22. Sheffield Wednesday           42   8  5  8  32:29    1  7 13  21:40    53:69  -16   39
~~~

(Source: `1-division1.csv`)


~~~
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. Leicester City                42  14  4  3  56:26   10  4  7  33:31    89:57  +32   80
 2. Blackpool                     42  13  4  4  49:19   11  3  7  39:34    88:53  +35   79
 3. Bury                          42  13  4  4  46:26    9  4  8  28:29    74:55  +19   74
 4. Newcastle United              42  11  3  7  45:23   11  2  8  35:33    80:56  +24   71
 5. West Ham United               42  14  5  2  47:18    5  6 10  26:37    73:55  +18   68
 6. Plymouth Argyle               42  11  6  4  42:22    7  7  7  29:31    71:53  +18   67
 7. Sheffield United              42  16  4  1  48:14    2  6 13  18:40    66:54  +12   64
 8. Coventry City                 42  11  5  5  35:19    6  6  9  31:35    66:54  +12   62
 9. Tottenham Hotspur             42  13  3  5  57:26    4  6 11  31:40    88:66  +22   60
10. Aston Villa                   42  10  6  5  47:30    6  6  9  35:40    82:70  +12   60
11. Fulham                        42  11  5  5  43:24    4  8  9  28:37    71:61  +10   58
12. Blackburn Rovers              42  11  3  7  49:32    5  7  9  21:30    70:62   +8   58
13. Burnley                       42  11  5  5  37:20    5  5 11  20:41    57:61   -4   58
14. Barnsley                      42  11  6  4  30:23    5  3 13  20:41    50:64  -14   57
15. Chesterfield                  42  12  3  6  54:34    4  5 12  30:55    84:89   -5   56
16. Swansea City                  42  14  2  5  40:16    1  5 15  10:49    50:65  -15   52
17. Norwich City                  42   8  6  7  38:29    6  2 13  25:42    63:71   -8   50
18. Nottingham Forest             42  10  6  5  42:30    2  4 15  26:60    68:90  -22   46
19. Southampton                   42  10  8  3  38:25    1  4 16  15:52    53:77  -24   45
20. Bradford Park Avenue          42  10  4  7  33:33    2  5 14  19:55    52:88  -36   45
21. Bradford City                 42   8  8  5  36:31    1  4 16  18:63    54:94  -40   39
22. Doncaster Rovers              42   6  6  9  18:29    1  4 16  12:55    30:84  -54   31
~~~

(Source: `2-division2.csv`)


~~~
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. Stockport County              42  17  3  1  59:18    6 11  4  25:21    84:39  +45   83
 2. Lincoln City                  42  18  1  2  65:20    7  6  8  38:37   103:57  +46   82
 3. Chester                       42  15  5  1  68:21    7  4 10  19:36    87:57  +30   75
 4. Oldham Athletic               42  13  7  1  49:25    7  4 10  28:34    77:59  +18   71
 5. Hartlepool United             42  16  1  4  53:21    3  6 12  22:48    75:69   +6   64
 6. Halifax Town                  42  12  4  5  40:20    6  5 10  28:43    68:63   +5   63
 7. Hull City                     42  13  6  2  39:22    4  6 11  29:47    68:69   -1   63
 8. Mansfield Town                42  13  1  7  64:35    5  7  9  27:41    91:76  +15   62
 9. Carlisle United               42  13  6  2  42:19    5  2 14  23:49    65:68   -3   62
10. Port Vale                     42  12  6  3  39:23    5  4 12  19:41    58:64   -6   61
11. Wrexham                       42  12  3  6  41:21    4  9  8  30:36    71:57  +14   60
12. York City                     42  13  3  5  54:27    3  8 10  25:43    79:70   +9   59
13. Accrington Stanley            42  14  2  5  51:26    2  7 12  25:43    76:69   +7   57
14. New Brighton                  42  10  8  3  36:16    3  3 15  19:54    55:70  -15   50
15. Rotherham United              42  11  7  3  52:28    3  0 18  26:63    78:91  -13   49
16. Southport                     42  10  8  3  39:28    2  5 14  34:59    73:87  -14   49
17. Barrow                        42  11  5  5  42:25    2  5 14  28:61    70:86  -16   49
18. Rochdale                      42  12  3  6  44:27    1  6 14  25:59    69:86  -17   48
19. Tranmere Rovers               42  10  8  3  52:30    2  1 18  19:58    71:88  -17   45
20. Gateshead                     42   9  8  4  40:31    2  2 17  23:67    63:98  -35   43
21. Crewe Alexandra               42   6  8  7  31:31    4  4 13  24:52    55:83  -28   42
22. Darlington                    42   6  8  7  42:46    2  6 13  24:50    66:96  -30   38
~~~

(Source: `3a-division3n.csv`)


~~~
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. Luton Town                    42  19  1  1  69:16    8  3 10  34:37   103:53  +50   85
 2. Notts County                  42  15  3  3  44:23    8  7  6  30:29    74:52  +22   79
 3. Brighton & Hove Albion        42  15  5  1  49:16    9  0 12  25:27    74:43  +31   77
 4. AFC Bournemouth               42  17  3  1  45:20    3  6 12  20:39    65:59   +6   69
 5. Watford                       42  14  4  3  53:21    5  7  9  32:39    85:60  +25   68
 6. Reading                       42  14  5  2  53:23    5  6 10  23:37    76:60  +16   68
 7. Northampton Town              42  15  4  2  56:22    5  2 14  29:46    85:68  +17   66
 8. Millwall                      42  12  4  5  43:24    6  6  9  21:30    64:54  +10   64
 9. Queens Park Rangers           42  12  2  7  51:24    6  7  8  22:28    73:52  +21   63
10. Southend United               42  10  8  3  49:23    7  3 11  29:44    78:67  +11   62
11. Gillingham                    42  14  5  2  36:18    4  3 14  16:48    52:66  -14   62
12. Leyton Orient                 42  10  8  3  29:17    4  7 10  23:35    52:52        57
13. Swindon Town                  42  12  4  5  52:24    2  7 12  23:49    75:73   +2   53
14. Bristol Rovers                42  14  3  4  49:20    2  1 18  22:60    71:80   -9   52
15. Crystal Palace                42  11  7  3  45:20    2  5 14  17:41    62:61   +1   51
16. Bristol City                  42  13  3  5  42:20    2  3 16  16:50    58:70  -12   51
17. Walsall                       42  11  3  7  38:34    2  7 12  25:51    63:85  -22   49
18. Cardiff City                  42  10  5  6  35:24    4  2 15  19:63    54:87  -33   49
19. Newport County                42   7  7  7  37:28    5  3 13  30:70    67:98  -31   46
20. Torquay United                42   9  5  7  42:32    2  5 14  15:48    57:80  -23   43
21. Exeter City                   42   9  5  7  36:37    1  7 13  23:51    59:88  -29   42
22. Aldershot                     42   5  6 10  29:29    2  3 16  21:60    50:89  -39   30
~~~

(Source: `3b-division3s.csv`)



---
Pld = Matches; W = Matches won; D = Matches drawn; L = Matches lost; F = Goals for; A = Goals against; +/- = Goal differencence; Pts = Points

