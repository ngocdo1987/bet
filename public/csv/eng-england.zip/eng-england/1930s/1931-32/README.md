

### Standings


~~~
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. Everton                       42  18  0  3  84:30    8  4  9  32:34   116:64  +52   82
 2. Arsenal                       42  14  5  2  52:16    8  5  8  38:32    90:48  +42   76
 3. Sheffield Wednesday           42  14  4  3  60:28    8  2 11  36:54    96:82  +14   72
 4. Huddersfield Town             42  11  8  2  47:21    8  2 11  33:42    80:63  +17   67
 5. West Bromwich Albion          42  12  4  5  46:21    8  2 11  31:34    77:55  +22   66
 6. Sheffield United              42  13  3  5  47:32    7  3 11  33:43    80:75   +5   66
 7. Aston Villa                   42  15  1  5  64:28    4  7 10  40:44   104:72  +32   65
 8. Portsmouth                    42  14  2  5  37:21    5  5 11  25:41    62:62        64
 9. Liverpool                     42  13  4  4  56:38    6  2 13  25:55    81:93  -12   63
10. Birmingham City               42  13  5  3  48:22    5  3 13  30:45    78:67  +11   62
11. Newcastle United              42  13  5  3  52:31    5  1 15  28:56    80:87   -7   60
12. Chelsea                       42  12  4  5  43:27    4  4 13  26:46    69:73   -4   56
13. Sunderland                    42  11  4  6  42:29    4  6 11  25:44    67:73   -6   55
14. Bolton Wanderers              42  15  1  5  51:25    2  3 16  21:55    72:80   -8   55
15. Blackburn Rovers              42  12  3  6  57:41    4  3 14  32:54    89:95   -6   54
16. Middlesbrough                 42  12  3  6  41:29    3  5 13  23:60    64:89  -25   53
17. Derby County                  42  13  5  3  51:25    1  5 15  20:50    71:75   -4   52
18. Leicester City                42  11  3  7  46:39    4  4 13  28:55    74:94  -20   52
19. Manchester City               42  10  5  6  49:30    3  7 11  34:43    83:73  +10   51
20. Grimsby Town                  42  11  4  6  39:28    2  2 17  28:70    67:98  -31   45
21. Blackpool                     42   9  4  8  42:40    3  5 13  23:62    65:102 -37   45
22. West Ham United               42   9  5  7  35:37    3  2 16  27:70    62:107 -45   43
~~~

(Source: `1-division1.csv`)


~~~
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. Wolverhampton Wanderers       42  17  3  1  71:11    7  5  9  44:38   115:49  +66   80
 2. Leeds United                  42  12  5  4  36:22   10  5  6  42:32    78:54  +24   76
 3. Stoke City                    42  14  6  1  47:19    5  8  8  22:29    69:48  +21   71
 4. Bury                          42  13  4  4  44:21    8  3 10  26:37    70:58  +12   70
 5. Bradford Park Avenue          42  17  2  2  44:18    4  5 12  28:45    72:63   +9   70
 6. Plymouth Argyle               42  14  4  3  69:29    6  5 10  31:37   100:66  +34   69
 7. Bradford City                 42  10  7  4  53:26    6  6  9  27:35    80:61  +19   61
 8. Millwall                      42  13  3  5  43:21    4  6 11  18:40    61:61        60
 9. Charlton Athletic             42  11  5  5  38:28    6  4 11  23:38    61:66   -5   60
10. Tottenham Hotspur             42  11  6  4  58:37    5  5 11  29:41    87:78   +9   59
11. Manchester United             42  12  3  6  44:31    5  5 11  27:41    71:72   -1   59
12. Nottingham Forest             42  13  4  4  49:27    3  6 12  28:45    77:72   +5   58
13. Preston North End             42  11  6  4  37:25    5  4 12  38:52    75:77   -2   58
14. Southampton                   42  10  5  6  39:30    7  2 12  27:47    66:77  -11   58
15. Swansea City                  42  12  4  5  45:22    4  3 14  28:53    73:75   -2   55
16. Notts County                  42  10  4  7  43:30    3  8 10  32:45    75:75        51
17. Chesterfield                  42  11  3  7  43:33    2  8 11  21:53    64:86  -22   50
18. Oldham Athletic               42  10  4  7  41:34    3  6 12  21:50    62:84  -22   49
19. Burnley                       42   7  8  6  36:36    6  1 14  23:51    59:87  -28   48
20. Port Vale                     42   8  4  9  30:33    5  3 13  28:56    58:89  -31   46
21. Barnsley                      42   8  7  6  35:30    4  2 15  20:61    55:91  -36   45
22. Bristol City                  42   4  7 10  22:37    2  4 15  17:41    39:78  -39   29
~~~

(Source: `2-division2.csv`)


~~~
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. Lincoln City                  42  17  2  2  68:13   11  3  7  44:34   112:47  +65   89
 2. Gateshead                     41  15  3  2  59:20   10  4  7  36:30    95:50  +45   82
 3. Chester                       41  17  2  2  58:22    5  6  9  24:38    82:60  +22   74
 4. Barrow                        40  16  1  3  59:23    8  0 12  27:36    86:59  +27   73
 5. Crewe Alexandra               41  16  3  2  68:27    6  3 11  31:42    99:69  +30   72
 6. Tranmere Rovers               40  15  4  1  76:23    4  7  9  31:35   107:58  +49   68
 7. Hull City                     41  14  1  5  52:21    6  4 11  31:35    83:56  +27   65
 8. Southport                     40  14  5  1  44:15    4  5 11  14:38    58:53   +5   64
 9. Wrexham                       41  15  2  4  47:25    4  5 11  22:44    69:69        64
10. York City                     40  14  3  3  49:24    4  4 12  27:57    76:81   -5   61
11. Darlington                    41  13  1  7  46:27    5  3 12  25:42    71:69   +2   58
12. Hartlepool United             41  10  4  6  47:37    6  2 13  32:64    79:101 -22   54
13. Walsall                       41  13  3  5  45:30    4  0 16  15:55    60:85  -25   54
14. Doncaster Rovers              40  12  3  5  38:27    4  1 15  21:53    59:80  -21   52
15. Accrington Stanley            40  14  4  2  56:20    1  2 17  19:60    75:80   -5   51
16. Stockport County              40  12  3  5  31:15    1  8 11  24:38    55:53   +2   50
17. Halifax Town                  41  11  6  3  36:18    3  2 16  26:69    62:87  -25   50
18. Rotherham United              40  10  3  7  41:23    4  1 15  22:49    63:72   -9   46
19. Carlisle United               41   9  7  4  40:23    2  4 15  26:59    66:82  -16   44
20. New Brighton                  40   8  5  7  25:23    0  3 17  13:53    38:76  -38   32
21. Rochdale                      40   4  2 14  33:63    0  1 19  15:72    48:135 -87   15
22. Wigan Borough                 12   3  1  2   9:9     0  0  6   3:24    12:33  -21   10
~~~

(Source: `3a-division3n.csv`)


~~~
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. Fulham                        42  15  3  3  72:27    9  6  6  39:35   111:62  +49   81
 2. Reading                       42  19  1  1  65:21    4  8  9  32:46    97:67  +30   78
 3. Southend United               42  12  5  4  41:18    9  6  6  36:35    77:53  +24   74
 4. Crystal Palace                42  14  7  0  48:12    6  4 11  26:51    74:63  +11   71
 5. Luton Town                    42  16  1  4  62:25    4  6 11  33:45    95:70  +25   67
 6. Brentford                     42  11  6  4  40:22    8  4  9  28:30    68:52  +16   67
 7. Exeter City                   42  16  3  2  53:16    4  4 13  24:46    77:62  +15   67
 8. Cardiff City                  42  14  2  5  62:29    5  6 10  25:44    87:73  +14   65
 9. Watford                       42  14  4  3  49:27    5  4 12  32:52    81:79   +2   65
10. Brighton & Hove Albion        42  12  4  5  42:21    5  8  8  31:37    73:58  +15   63
11. Norwich City                  42  12  7  2  51:22    5  5 11  25:45    76:67   +9   63
12. Coventry City                 42  17  2  2  74:28    1  6 14  34:69   108:97  +11   62
13. Queens Park Rangers           42  11  6  4  50:30    4  6 11  29:43    79:73   +6   57
14. Northampton Town              42  12  3  6  48:26    4  4 13  21:43    69:69        55
15. AFC Bournemouth               42   8  8  5  42:32    5  4 12  28:46    70:78   -8   51
16. Swindon Town                  42  12  2  7  47:31    2  4 15  23:53    70:84  -14   48
17. Leyton Orient                 42   7  8  6  41:35    5  3 13  36:55    77:90  -13   47
18. Bristol Rovers                42  11  6  4  46:30    2  2 17  19:62    65:92  -27   47
19. Torquay United                42   9  6  6  49:39    3  3 15  23:67    72:106 -34   45
20. Mansfield Town                42  11  5  5  54:45    0  5 16  21:63    75:108 -33   43
21. Gillingham                    42   8  6  7  26:26    2  2 17  14:56    40:82  -42   38
22. Thames                        42   6  7  8  35:35    1  2 18  18:74    53:109 -56   30
~~~

(Source: `3b-division3s.csv`)



---
Pld = Matches; W = Matches won; D = Matches drawn; L = Matches lost; F = Goals for; A = Goals against; +/- = Goal differencence; Pts = Points

