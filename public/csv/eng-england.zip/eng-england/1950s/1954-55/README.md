

### Standings


~~~
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. Chelsea                       42  11  5  5  43:29    9  7  5  38:28    81:57  +24   72
 2. Wolverhampton Wanderers       42  13  5  3  58:30    6  5 10  31:40    89:70  +19   67
 3. Manchester United             42  12  4  5  44:30    8  3 10  40:44    84:74  +10   67
 4. Aston Villa                   42  11  3  7  38:31    9  4  8  34:42    72:73   -1   67
 5. Portsmouth                    42  13  5  3  44:21    5  7  9  30:41    74:62  +12   66
 6. Manchester City               42  11  5  5  45:36    7  5  9  31:33    76:69   +7   64
 7. Sunderland                    42   8 11  2  39:27    7  7  7  25:27    64:54  +10   63
 8. Newcastle United              42  12  5  4  53:27    5  4 12  36:50    89:77  +12   60
 9. Arsenal                       42  12  3  6  44:25    5  6 10  25:38    69:63   +6   60
10. Burnley                       42  11  3  7  29:19    6  6  9  22:29    51:48   +3   60
11. Everton                       42   9  6  6  32:24    7  4 10  30:44    62:68   -6   58
12. Sheffield United              42  10  3  8  41:34    7  4 10  29:52    70:86  -16   58
13. Preston North End             42   8  5  8  47:33    8  3 10  36:31    83:64  +19   56
14. Tottenham Hotspur             42   9  4  8  42:35    7  4 10  30:38    72:73   -1   56
15. West Bromwich Albion          42  11  5  5  44:33    5  3 13  32:63    76:96  -20   56
16. Charlton Athletic             42   8  6  7  43:34    7  4 10  33:41    76:75   +1   55
17. Huddersfield Town             42  10  4  7  28:23    4  9  8  35:45    63:68   -5   55
18. Blackpool                     42   8  6  7  33:26    6  4 11  27:38    60:64   -4   52
19. Bolton Wanderers              42  11  6  4  45:29    2  7 12  17:40    62:69   -7   52
20. Cardiff City                  42   9  4  8  41:38    4  7 10  21:38    62:76  -14   50
21. Leicester City                42   9  6  6  43:32    3  5 13  31:54    74:86  -12   47
22. Sheffield Wednesday           42   7  7  7  42:38    1  3 17  21:62    63:100 -37   34
~~~

(Source: `1-division1.csv`)


~~~
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. Rotherham United              42  17  1  3  59:22    8  3 10  35:42    94:64  +30   79
 2. Luton Town                    42  18  2  1  55:18    5  6 10  33:35    88:53  +35   77
 3. Birmingham City               42  14  4  3  56:22    8  6  7  36:25    92:47  +45   76
 4. Leeds United                  42  14  4  3  43:19    9  3  9  27:34    70:53  +17   76
 5. Stoke City                    42  12  5  4  38:17    9  5  7  31:29    69:46  +23   73
 6. Blackburn Rovers              42  14  4  3  73:31    8  2 11  41:48   114:79  +35   72
 7. Notts County                  42  14  3  4  46:27    7  3 11  28:44    74:71   +3   69
 8. Bristol Rovers                42  15  4  2  52:23    4  3 14  23:47    75:70   +5   64
 9. West Ham United               42  12  4  5  46:28    6  6  9  28:42    74:70   +4   64
10. Swansea City                  42  15  3  3  58:28    2  6 13  28:55    86:83   +3   60
11. Middlesbrough                 42  13  1  7  48:31    5  5 11  25:51    73:82   -9   60
12. Liverpool                     42  11  7  3  55:37    5  3 13  37:59    92:96   -4   58
13. Bury                          42  10  5  6  44:35    5  6 10  33:37    77:72   +5   56
14. Nottingham Forest             42   8  4  9  29:29    8  3 10  29:33    58:62   -4   55
15. Fulham                        42  10  5  6  46:29    4  6 11  30:50    76:79   -3   53
16. Lincoln City                  42   8  6  7  39:35    5  4 12  29:44    68:79  -11   49
17. Doncaster Rovers              42  10  5  6  35:34    4  2 15  23:61    58:95  -37   49
18. Port Vale                     42  10  6  5  31:21    2  5 14  17:50    48:71  -23   47
19. Hull City                     42   7  5  9  30:35    5  5 11  14:34    44:69  -25   46
20. Plymouth Argyle               42  10  4  7  29:26    2  3 16  28:56    57:82  -25   43
21. Ipswich Town                  42  10  3  8  37:28    1  3 17  20:64    57:92  -35   39
22. Derby County                  42   6  6  9  39:34    1  3 17  14:48    53:82  -29   30
~~~

(Source: `2-division2.csv`)


~~~
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. Barnsley                      46  18  3  2  51:17   12  2  9  35:29    86:46  +40   95
 2. Accrington Stanley            46  18  2  3  65:32    7  9  7  31:35    96:67  +29   86
 3. York City                     46  13  5  5  43:27   11  5  7  49:36    92:63  +29   82
 4. Scunthorpe United             46  14  6  3  45:18    9  6  8  36:35    81:53  +28   81
 5. Hartlepool United             46  16  3  4  39:20    9  2 12  25:29    64:49  +15   80
 6. Chesterfield                  46  17  1  5  54:33    7  5 11  27:37    81:70  +11   78
 7. Gateshead                     46  11  7  5  38:26    9  5  9  27:43    65:69   -4   72
 8. Workington                    46  11  7  5  39:23    7  7  9  29:32    68:55  +13   68
 9. Oldham Athletic               46  14  5  4  47:22    5  5 13  27:46    74:68   +6   67
10. Stockport County              46  13  4  6  50:27    5  8 10  34:43    84:70  +14   66
11. Rochdale                      46  13  7  3  39:20    4  7 12  30:46    69:66   +3   65
12. Southport                     46  10  9  4  28:18    6  7 10  19:26    47:44   +3   64
13. Mansfield Town                46  14  4  5  40:28    4  5 14  25:43    65:71   -6   63
14. Halifax Town                  46   9  9  5  41:27    6  4 13  22:40    63:67   -4   58
15. Barrow                        46  12  4  7  39:34    5  2 16  31:55    70:89  -19   57
16. Darlington                    46  10  7  6  41:28    4  7 12  21:45    62:73  -11   56
17. Bradford Park Avenue          46  11  7  5  29:21    4  4 15  27:49    56:70  -14   56
18. Carlisle United               46  12  1 10  53:39    3  5 15  25:50    78:89  -11   51
19. Wrexham                       46   9  6  8  40:35    4  6 13  25:42    65:77  -12   51
20. Tranmere Rovers               46   9  6  8  37:30    4  5 14  18:40    55:70  -15   50
21. Bradford City                 46   9  5  9  30:26    4  5 14  17:29    47:55   -8   49
22. Grimsby Town                  46  10  4  9  28:32    3  4 16  19:46    47:78  -31   47
23. Chester                       46  10  3 10  23:25    2  6 15  21:52    44:77  -33   45
24. Crewe Alexandra               46   8 10  5  45:35    2  4 17  23:56    68:91  -23   44
~~~

(Source: `3a-division3n.csv`)


~~~
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. Bristol City                  46  17  4  2  62:22   13  6  4  39:25   101:47  +54  100
 2. Leyton Orient                 46  16  2  5  48:20   10  7  6  41:27    89:47  +42   87
 3. Southampton                   46  16  6  1  49:19    8  5 10  26:32    75:51  +24   83
 4. Gillingham                    46  12  8  3  41:28    8  7  8  36:38    77:66  +11   75
 5. Millwall                      46  14  6  3  44:25    6  5 12  28:43    72:68   +4   71
 6. Brighton & Hove Albion        46  14  4  5  47:27    6  6 11  29:36    76:63  +13   70
 7. Watford                       46  11  9  3  45:26    7  5 11  26:36    71:62   +9   68
 8. Torquay United                46  12  6  5  51:39    6  6 11  31:43    82:82        66
 9. Coventry City                 46  15  5  3  50:26    3  6 14  17:33    67:59   +8   65
10. Northampton Town              46  13  5  5  47:27    6  3 14  26:54    73:81   -8   65
11. Norwich City                  46  13  5  5  40:23    5  5 13  20:37    60:60        64
12. Southend United               46  13  5  5  48:28    4  7 12  35:52    83:80   +3   63
13. Brentford                     46  11  6  6  44:36    5  8 10  38:46    82:82        62
14. Aldershot                     46  12  6  5  44:23    4  7 12  31:48    75:71   +4   61
15. Queens Park Rangers           46  13  7  3  46:25    2  7 14  23:50    69:75   -6   59
16. Shrewsbury Town               46  14  5  4  49:24    2  5 16  21:54    70:78   -8   58
17. Reading                       46   7 10  6  32:26    6  5 12  33:47    65:73   -8   54
18. AFC Bournemouth               46   7  8  8  32:29    5 10  8  25:36    57:65   -8   54
19. Newport County                46   8  8  7  32:29    3  8 12  28:44    60:73  -13   49
20. Crystal Palace                46   9 11  3  32:24    2  5 16  20:56    52:80  -28   49
21. Swindon Town                  46  10  8  5  30:19    1  7 15  16:45    46:64  -18   48
22. Exeter City                   46   9  7  7  30:31    2  8 13  17:42    47:73  -26   48
23. Walsall                       46   9  6  8  49:36    1  8 14  26:50    75:86  -11   44
24. Colchester United             46   7  6 10  33:40    2  7 14  20:51    53:91  -38   40
~~~

(Source: `3b-division3s.csv`)



---
Pld = Matches; W = Matches won; D = Matches drawn; L = Matches lost; F = Goals for; A = Goals against; +/- = Goal differencence; Pts = Points

