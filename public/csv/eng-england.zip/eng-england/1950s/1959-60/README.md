

### Standings


~~~
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. Burnley                       42  15  2  4  52:28    9  5  7  33:33    85:61  +24   79
 2. Wolverhampton Wanderers       42  15  3  3  63:28    9  3  9  43:39   106:67  +39   78
 3. Tottenham Hotspur             42  10  6  5  43:24   11  5  5  43:26    86:50  +36   74
 4. West Bromwich Albion          42  12  4  5  48:25    7  7  7  35:32    83:57  +26   68
 5. Sheffield Wednesday           42  12  7  2  48:20    7  4 10  32:39    80:59  +21   68
 6. Bolton Wanderers              42  12  5  4  37:27    8  3 10  22:24    59:51   +8   68
 7. Manchester United             42  13  3  5  53:30    6  4 11  49:50   102:80  +22   64
 8. Newcastle United              42  10  5  6  42:32    8  3 10  40:46    82:78   +4   62
 9. Fulham                        42  12  4  5  42:28    5  6 10  31:52    73:80   -7   61
10. Preston North End             42  10  6  5  43:34    6  6  9  36:42    79:76   +3   60
11. Blackpool                     42   9  6  6  32:32    6  4 11  27:39    59:71  -12   55
12. Manchester City               42  11  2  8  47:34    6  1 14  31:50    78:84   -6   54
13. Arsenal                       42   9  5  7  39:38    6  4 11  29:42    68:80  -12   54
14. West Ham United               42  12  3  6  47:33    4  3 14  28:58    75:91  -16   54
15. Blackburn Rovers              42  12  3  6  38:29    4  2 15  22:41    60:70  -10   53
16. Leicester City                42   8  6  7  38:32    5  7  9  28:43    66:75   -9   52
17. Chelsea                       42   7  5  9  44:50    7  4 10  32:41    76:91  -15   51
18. Everton                       42  13  3  5  50:20    0  8 13  23:58    73:78   -5   50
19. Birmingham City               42   9  5  7  37:36    4  5 12  26:44    63:80  -17   49
20. Nottingham Forest             42   8  6  7  30:28    5  3 13  20:46    50:74  -24   48
21. Leeds United                  42   7  5  9  37:46    5  5 11  28:46    65:92  -27   46
22. Luton Town                    42   6  5 10  25:29    3  7 11  25:44    50:73  -23   39
~~~

(Source: `1-division1.csv`)


~~~
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. Aston Villa                   42  17  3  1  62:19    8  6  7  27:24    89:43  +46   84
 2. Cardiff City                  42  15  2  4  55:36    8 10  3  35:26    90:62  +28   81
 3. Liverpool                     42  15  3  3  59:28    5  7  9  31:38    90:66  +24   70
 4. Sheffield United              42  12  5  4  43:22    7  7  7  25:29    68:51  +17   69
 5. Middlesbrough                 42  14  5  2  56:21    5  5 11  34:43    90:64  +26   67
 6. Huddersfield Town             42  13  3  5  44:20    6  6  9  29:32    73:52  +21   66
 7. Bristol Rovers                42  12  6  3  42:28    6  5 10  30:50    72:78   -6   65
 8. Charlton Athletic             42  12  7  2  55:28    5  6 10  35:59    90:87   +3   64
 9. Rotherham United              42   9  9  3  31:23    8  4  9  30:37    61:60   +1   64
10. Ipswich Town                  42  12  5  4  48:24    7  1 13  30:44    78:68  +10   63
11. Leyton Orient                 42  12  4  5  47:25    3 10  8  29:36    76:61  +15   59
12. Swansea City                  42  12  6  3  54:32    3  4 14  28:52    82:84   -2   55
13. Lincoln City                  42  11  3  7  41:25    5  4 12  34:53    75:78   -3   55
14. Brighton & Hove Albion        42   7  8  6  35:32    6  4 11  32:44    67:76   -9   51
15. Scunthorpe United             42   9  7  5  38:26    4  3 14  19:45    57:71  -14   49
16. Derby County                  42   9  4  8  31:28    5  3 13  30:49    61:77  -16   49
17. Stoke City                    42   8  3 10  40:38    6  4 11  26:45    66:83  -17   49
18. Sunderland                    42   8  6  7  35:29    4  6 11  17:36    52:65  -13   48
19. Plymouth Argyle               42  10  6  5  42:36    3  3 15  19:53    61:89  -28   48
20. Portsmouth                    42   6  6  9  36:36    4  6 11  23:41    59:77  -18   42
21. Hull City                     42   7  6  8  27:30    3  4 14  21:46    48:76  -28   40
22. Bristol City                  42   8  3 10  27:31    3  2 16  33:66    60:97  -37   38
~~~

(Source: `2-division2.csv`)


~~~
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. Southampton                   46  19  3  1  68:30    7  6 10  38:45   106:75  +31   87
 2. Norwich City                  46  16  4  3  53:24    8  7  8  29:30    82:54  +28   83
 3. Coventry City                 46  14  6  3  42:22    7  4 12  34:41    76:63  +13   73
 4. Brentford                     46  13  6  4  46:24    8  3 12  32:37    78:61  +17   72
 5. Bury                          46  13  4  6  36:23    8  5 10  28:28    64:51  +13   72
 6. Shrewsbury Town               46  12  7  4  58:34    6  9  8  39:41    97:75  +22   70
 7. Grimsby Town                  46  12  7  4  48:27    6  9  8  39:43    87:70  +17   70
 8. Queens Park Rangers           46  14  7  2  45:16    4  6 13  28:38    73:54  +19   67
 9. Newport County                46  15  2  6  59:36    5  4 14  21:43    80:79   +1   66
10. Colchester United             46  15  6  2  51:22    3  5 15  32:52    83:74   +9   65
11. Southend United               46  15  3  5  49:28    4  5 14  27:46    76:74   +2   65
12. Port Vale                     46  16  4  3  51:19    3  4 16  29:60    80:79   +1   65
13. Swindon Town                  46  12  6  5  39:30    7  2 14  30:48    69:78   -9   65
14. Reading                       46  13  3  7  49:34    5  7 11  35:43    84:77   +7   64
15. AFC Bournemouth               46  12  8  3  47:27    5  5 13  25:45    72:72        64
16. Halifax Town                  46  13  3  7  42:27    5  7 11  28:45    70:72   -2   64
17. Chesterfield                  46  13  3  7  41:31    5  4 14  30:53    71:84  -13   61
18. Barnsley                      46  13  6  4  45:25    2  8 13  20:41    65:66   -1   59
19. Bradford City                 46  10  7  6  39:28    5  5 13  27:46    66:74   -8   57
20. Tranmere Rovers               46  11  8  4  50:29    3  5 15  22:46    72:75   -3   55
21. York City                     46  11  5  7  38:26    2  7 14  19:45    57:71  -14   51
22. Mansfield Town                46  11  4  8  55:48    4  2 17  26:64    81:112 -31   51
23. Wrexham                       46  12  5  6  39:30    2  3 18  29:71    68:101 -33   50
24. Accrington Stanley            46   4  5 14  31:53    7  0 16  26:70    57:123 -66   38
~~~

(Source: `3-division3.csv`)


~~~
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. Walsall                       46  14  5  4  57:33   14  4  5  45:27   102:60  +42   93
 2. Notts County                  46  19  1  3  66:27    7  7  9  43:41   109:68  +41   86
 3. Torquay United                46  17  3  3  56:27    9  5  9  28:31    84:58  +26   86
 4. Watford                       46  17  2  4  62:28    7  7  9  30:39    92:67  +25   81
 5. Gillingham                    46  17  4  2  47:21    4  6 13  27:48    74:69   +5   73
 6. Northampton Town              46  13  6  4  50:22    8  3 12  31:42    81:64  +17   72
 7. Millwall                      46  12  8  3  54:28    6  9  8  31:34    85:62  +23   71
 8. Crystal Palace                46  12  6  5  61:27    7  6 10  23:37    84:64  +20   69
 9. Exeter City                   46  13  7  3  50:30    6  4 13  30:40    80:70  +10   68
10. Stockport County              46  15  6  2  35:10    4  5 14  23:44    58:54   +4   68
11. Bradford Park Avenue          46  12 10  1  48:25    5  5 13  22:43    70:68   +2   66
12. Rochdale                      46  15  4  4  46:19    3  6 14  19:41    65:60   +5   64
13. Aldershot                     46  14  5  4  50:22    4  4 15  27:52    77:74   +3   63
14. Crewe Alexandra               46  14  3  6  51:31    4  6 13  28:57    79:88   -9   63
15. Darlington                    46  11  6  6  40:30    6  3 14  23:43    63:73  -10   60
16. Doncaster Rovers              46  13  3  7  40:23    3  7 13  29:53    69:76   -7   58
17. Workington                    46  10  8  5  41:20    4  6 13  27:40    68:60   +8   56
18. Barrow                        46  11  8  4  52:29    4  3 16  25:58    77:87  -10   56
19. Carlisle United               46   9  6  8  28:28    6  5 12  23:38    51:66  -15   56
20. Chester                       46  10  8  5  37:26    4  4 15  22:51    59:77  -18   54
21. Gateshead                     46  12  3  8  37:27    0  6 17  21:59    58:86  -28   45
22. Southport                     46   9  8  6  30:31    1  7 15  18:60    48:91  -43   45
23. Hartlepool United             46   9  2 12  40:41    1  6 16  19:67    59:108 -49   38
24. Oldham Athletic               46   5  7 11  20:30    3  5 15  21:53    41:83  -42   36
~~~

(Source: `4-division4.csv`)



---
Pld = Matches; W = Matches won; D = Matches drawn; L = Matches lost; F = Goals for; A = Goals against; +/- = Goal differencence; Pts = Points

