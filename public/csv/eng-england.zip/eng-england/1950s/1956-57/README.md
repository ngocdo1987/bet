

### Standings


~~~
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. Manchester United             42  14  4  3  55:25   14  4  3  48:29   103:54  +49   92
 2. Preston North End             42  15  4  2  50:19    8  6  7  34:37    84:56  +28   79
 3. Tottenham Hotspur             42  15  4  2  70:24    7  8  6  34:32   104:56  +48   78
 4. Blackpool                     42  14  3  4  55:26    8  6  7  38:39    93:65  +28   75
 5. Arsenal                       42  12  5  4  45:21    9  3  9  40:48    85:69  +16   71
 6. Wolverhampton Wanderers       42  17  2  2  70:29    3  6 12  24:41    94:70  +24   68
 7. Burnley                       42  14  5  2  41:21    4  5 12  15:29    56:50   +6   64
 8. Bolton Wanderers              42  13  6  2  42:23    3  6 12  23:42    65:65        60
 9. Leeds United                  42  10  8  3  42:18    5  6 10  30:45    72:63   +9   59
10. Aston Villa                   42  10  8  3  45:25    4  7 10  20:30    65:55  +10   57
11. West Bromwich Albion          42   8  8  5  31:25    6  6  9  28:36    59:61   -2   56
12. Birmingham City               42  12  5  4  52:25    3  4 14  17:44    69:69        54
13. Sheffield Wednesday           42  14  3  4  55:29    2  3 16  27:59    82:88   -6   54
14. Chelsea                       42   7  8  6  43:36    6  5 10  30:37    73:73        52
15. Everton                       42  10  5  6  34:28    4  5 12  27:51    61:79  -18   52
16. Luton Town                    42  10  4  7  32:26    4  5 12  26:50    58:76  -18   51
17. Newcastle United              42  10  5  6  43:31    4  3 14  24:56    67:87  -20   50
18. Manchester City               42  10  2  9  48:42    3  7 11  30:46    78:88  -10   48
19. Sunderland                    42   9  5  7  40:30    3  3 15  27:58    67:88  -21   44
20. Portsmouth                    42   8  6  7  37:35    2  7 12  25:57    62:92  -30   43
21. Cardiff City                  42   7  6  8  35:34    3  3 15  18:54    53:88  -35   39
22. Charlton Athletic             42   7  3 11  31:44    2  1 18  31:76    62:120 -58   31
~~~

(Source: `1-division1.csv`)


~~~
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. Leicester City                42  14  5  2  68:36   11  6  4  41:31   109:67  +42   86
 2. Nottingham Forest             42  13  4  4  50:29    9  6  6  44:26    94:55  +39   76
 3. Liverpool                     42  16  1  4  53:26    5 10  6  29:28    82:54  +28   74
 4. Blackburn Rovers              42  12  6  3  49:32    9  4  8  34:43    83:75   +8   73
 5. Stoke City                    42  16  2  3  64:18    4  6 11  19:40    83:58  +25   68
 6. Middlesbrough                 42  12  5  4  51:29    7  5  9  33:31    84:60  +24   67
 7. Sheffield United              42  11  6  4  45:28    8  2 11  42:48    87:76  +11   65
 8. West Ham United               42  12  4  5  31:24    7  4 10  28:39    59:63   -4   65
 9. Swansea City                  42  12  3  6  53:34    7  4 10  37:56    90:90        64
10. Bristol Rovers                42  12  5  4  47:19    6  4 11  34:48    81:67  +14   63
11. Fulham                        42  13  1  7  53:32    6  3 12  31:44    84:76   +8   61
12. Huddersfield Town             42  10  3  8  33:27    8  3 10  35:47    68:74   -6   60
13. Bristol City                  42  13  2  6  49:32    3  7 11  25:47    74:79   -5   57
14. Grimsby Town                  42  12  4  5  41:26    5  1 15  20:36    61:62   -1   56
15. Doncaster Rovers              42  12  5  4  51:21    3  5 13  26:56    77:77        55
16. Leyton Orient                 42   7  8  6  34:38    8  2 11  32:46    66:84  -18   55
17. Rotherham United              42   9  7  5  37:26    4  4 13  37:49    74:75   -1   50
18. Lincoln City                  42   9  4  8  34:27    5  2 14  20:53    54:80  -26   48
19. Barnsley                      42   8  7  6  39:35    4  3 14  20:54    59:89  -30   46
20. Notts County                  42   7  6  8  34:32    2  6 13  24:54    58:86  -28   39
21. Bury                          42   5  3 13  37:47    3  6 12  23:49    60:96  -36   33
22. Port Vale                     42   7  4 10  31:42    1  2 18  26:59    57:101 -44   30
~~~

(Source: `2-division2.csv`)


~~~
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. Derby County                  46  18  3  2  69:18    8  8  7  42:35   111:53  +58   89
 2. Hartlepool United             46  18  4  1  56:21    7  5 11  34:42    90:63  +27   84
 3. Accrington Stanley            46  15  4  4  54:22   10  4  9  41:42    95:64  +31   83
 4. Workington                    46  16  4  3  60:25    8  6  9  33:38    93:63  +30   82
 5. Stockport County              46  16  3  4  51:26    7  5 11  40:49    91:75  +16   77
 6. Chesterfield                  46  17  5  1  60:22    5  4 14  36:57    96:79  +17   75
 7. Bradford City                 46  14  3  6  47:31    8  5 10  31:37    78:68  +10   74
 8. Hull City                     46  14  6  3  45:24    7  4 12  39:45    84:69  +15   73
 9. York City                     46  14  4  5  43:21    7  6 10  32:40    75:61  +14   73
10. Barrow                        46  16  2  5  51:22    5  7 11  25:40    76:62  +14   72
11. Halifax Town                  46  16  2  5  40:24    5  5 13  25:46    65:70   -5   70
12. Wrexham                       46  12  7  4  63:33    7  3 13  32:41    95:74  +21   67
13. Rochdale                      46  14  6  3  38:19    4  6 13  27:46    65:65        66
14. Mansfield Town                46  13  3  7  58:38    4  7 12  33:52    91:90   +1   61
15. Carlisle United               46   9  9  5  44:36    7  4 12  32:49    76:85   -9   61
16. Gateshead                     46   9  6  8  42:38    8  4 11  30:50    72:88  -16   61
17. Scunthorpe United             46   9  5  9  44:36    6 10  7  27:33    71:69   +2   60
18. Darlington                    46  11  5  7  47:36    6  3 14  35:59    82:95  -13   59
19. Oldham Athletic               46   9  7  7  35:31    3  8 12  31:43    66:74   -8   51
20. Bradford Park Avenue          46  11  2 10  41:40    5  1 17  25:53    66:93  -27   51
21. Chester                       46   8  7  8  40:35    2  6 15  15:49    55:84  -29   43
22. Southport                     46   7  8  8  31:34    3  4 16  21:60    52:94  -42   42
23. Tranmere Rovers               46   5  9  9  33:38    2  4 17  18:53    51:91  -40   34
24. Crewe Alexandra               46   5  7 11  31:46    1  2 20  12:64    43:110 -67   27
~~~

(Source: `3a-division3n.csv`)


~~~
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. Ipswich Town                  46  18  3  2  72:20    7  6 10  29:34   101:54  +47   84
 2. Torquay United                46  19  4  0  71:18    5  7 11  18:46    89:64  +25   83
 3. Colchester United             46  15  8  0  49:19    7  6 10  35:37    84:56  +28   80
 4. Southampton                   46  15  4  4  48:20    7  6 10  28:32    76:52  +24   76
 5. AFC Bournemouth               46  15  7  1  57:20    4  7 12  31:42    88:62  +26   71
 6. Brighton & Hove Albion        46  15  6  2  59:26    4  8 11  27:39    86:65  +21   71
 7. Southend United               46  14  3  6  42:20    4  9 10  31:45    73:65   +8   66
 8. Queens Park Rangers           46  12  7  4  42:21    6  4 13  19:39    61:60   +1   65
 9. Brentford                     46  12  9  2  55:29    4  7 12  23:47    78:76   +2   64
10. Watford                       46  11  6  6  44:32    7  4 12  28:43    72:75   -3   64
11. Reading                       46  13  4  6  44:30    5  5 13  36:51    80:81   -1   63
12. Shrewsbury Town               46  11  9  3  45:24    4  9 10  27:55    72:79   -7   63
13. Northampton Town              46  15  5  3  49:22    3  4 16  17:51    66:73   -7   63
14. Newport County                46  15  6  2  51:18    1  7 15  14:44    65:62   +3   61
15. Walsall                       46  11  7  5  49:25    5  5 13  31:49    80:74   +6   60
16. Coventry City                 46  12  5  6  52:36    4  7 12  22:48    74:84  -10   60
17. Millwall                      46  13  7  3  46:29    3  5 15  18:55    64:84  -20   60
18. Plymouth Argyle               46  10  8  5  38:31    6  3 14  30:42    68:73   -5   59
19. Aldershot                     46  11  5  7  43:35    4  7 12  36:57    79:92  -13   57
20. Crystal Palace                46   7 10  6  31:28    4  8 11  31:47    62:75  -13   51
21. Swindon Town                  46  12  3  8  43:33    3  3 17  23:63    66:96  -30   51
22. Exeter City                   46   8  8  7  37:29    4  5 14  24:50    61:79  -18   49
23. Gillingham                    46   7  8  8  29:29    5  5 13  25:56    54:85  -31   49
24. Norwich City                  46   7  5 11  33:37    1 10 12  28:57    61:94  -33   39
~~~

(Source: `3b-division3s.csv`)



---
Pld = Matches; W = Matches won; D = Matches drawn; L = Matches lost; F = Goals for; A = Goals against; +/- = Goal differencence; Pts = Points

