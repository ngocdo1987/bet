

### Standings


~~~
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. Sunderland                    34  12  3  2  32:14    7  3  7  18:21    50:35  +15   63
 2. Everton                       34  11  2  4  31:11    6  5  6  22:24    53:35  +18   58
 3. Newcastle United              34  11  3  3  41:14    3  6  8   7:20    48:34  +14   51
 4. Blackburn Rovers              34  12  2  3  36:16    3  4 10  16:32    52:48   +4   51
 5. Nottingham Forest             34  11  4  2  32:13    2  5 10  11:30    43:43        48
 6. Derby County                  34  11  5  1  26:10    2  4 11  13:31    39:41   -2   48
 7. Bury                          34  11  5  1  31:9     2  3 12  13:29    44:38   +6   47
 8. Aston Villa                   34   9  5  3  27:13    4  3 10  15:27    42:40   +2   47
 9. Sheffield Wednesday           34   9  5  3  30:14    4  3 10  18:38    48:52   -4   47
10. Sheffield United              34  10  5  2  38:13    3  2 12  15:35    53:48   +5   46
11. Notts County                  34  12  2  3  44:19    2  2 13   7:38    51:57   -6   46
12. Wolverhampton Wanderers       34  12  3  2  32:13    1  3 13  14:44    46:57  -11   45
13. Grimsby Town                  34  11  3  3  33:16    2  3 12  11:44    44:60  -16   45
14. Bolton Wanderers              34  10  6  1  38:17    2  2 13  13:39    51:56   -5   44
15. Liverpool                     34   8  3  6  28:16    2  9  6  14:22    42:38   +4   42
16. Stoke City                    34  10  4  3  31:12    1  5 11  14:43    45:55  -10   42
17. Birmingham City               34   8  5  4  31:14    3  3 11  16:31    47:45   +2   41
18. Manchester City               34  10  3  4  28:17    1  3 13  14:41    42:58  -16   39
~~~

(Source: `1-division1.csv`)


~~~
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. West Bromwich Albion          34  14  2  1  52:13   11  3  3  30:16    82:29  +53   80
 2. Middlesbrough                 34  15  1  1  58:7     8  4  5  32:17    90:24  +66   74
 3. Preston North End             34  12  3  2  50:11    6  3  8  21:21    71:32  +39   60
 4. Arsenal                       34  13  2  2  35:9     5  4  8  15:17    50:26  +24   60
 5. Bristol City                  34  13  1  3  39:12    4  5  8  13:23    52:35  +17   57
 6. Lincoln City                  34  11  6  0  26:4     3  7  7  19:31    45:35  +10   55
 7. Doncaster Rovers              34  12  3  2  39:12    1  5 11  10:46    49:58   -9   47
 8. Glossop North End             34   7  6  4  22:15    3  6  8  14:25    36:40   -4   42
 9. Barnsley                      34   9  3  5  36:33    3  3 11  15:30    51:63  -12   42
10. Burton United                 34   8  6  3  32:23    3  2 12  14:31    46:54   -8   41
11. Leicester City                34  11  2  4  26:14    1  3 13  12:42    38:56  -18   41
12. Burnley                       34   9  6  2  30:8     1  4 12  11:37    41:45   -4   40
13. Blackpool                     34   9  3  5  27:21    2  4 11  13:35    40:56  -16   40
14. Manchester United             34  10  2  5  27:12    1  4 12  11:41    38:53  -15   39
15. Port Vale                     34   7  7  3  26:17    3  2 12  17:42    43:59  -16   39
16. Chesterfield                  34  10  3  4  35:18    1  3 13  12:50    47:68  -21   39
17. Stockport County              34   8  3  6  25:20    0  4 13  11:52    36:72  -36   31
18. Gainsborough Trinity          34   4  9  4  26:25    0  2 15   4:55    30:80  -50   23
~~~

(Source: `2-division2.csv`)



---
Pld = Matches; W = Matches won; D = Matches drawn; L = Matches lost; F = Goals for; A = Goals against; +/- = Goal differencence; Pts = Points

