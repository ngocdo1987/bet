

### Standings


~~~
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. Liverpool                     38  14  3  2  49:15    9  2  8  30:31    79:46  +33   74
 2. Preston North End             38  12  5  2  36:15    5  8  6  18:24    54:39  +15   64
 3. Manchester City               38  11  2  6  46:23    8  3  8  27:31    73:54  +19   62
 4. Sheffield Wednesday           38  12  5  2  40:20    6  3 10  23:32    63:52  +11   62
 5. Newcastle United              38  12  4  3  49:23    6  3 10  25:25    74:48  +26   61
 6. Bolton Wanderers              38  13  1  5  51:22    4  6  9  30:45    81:67  +14   58
 7. Birmingham City               38  14  2  3  49:20    3  5 11  16:39    65:59   +6   58
 8. Aston Villa                   38  13  2  4  51:19    4  4 11  21:37    72:56  +16   57
 9. Blackburn Rovers              38  10  5  4  34:18    6  3 10  20:34    54:52   +2   56
10. Stoke City                    38  12  5  2  41:15    4  2 13  13:40    54:55   -1   55
11. Everton                       38  12  1  6  44:30    3  6 10  26:36    70:66   +4   52
12. Arsenal                       38  12  4  3  43:21    3  3 13  19:43    62:64   -2   52
13. Sheffield United              38  10  4  5  33:23    5  2 12  24:39    57:62   -5   51
14. Sunderland                    38  13  2  4  40:21    2  3 14  21:49    61:70   -9   50
15. Derby County                  38  10  5  4  27:16    4  2 13  12:42    39:58  -19   49
16. Notts County                  38   8  9  2  34:21    3  3 13  21:50    55:71  -16   45
17. Nottingham Forest             38  11  2  6  40:27    2  3 14  18:52    58:79  -21   44
18. Bury                          38   8  5  6  30:26    3  5 11  27:48    57:74  -17   43
19. Middlesbrough                 38  10  4  5  41:23    0  7 12  15:48    56:71  -15   41
20. Wolverhampton Wanderers       38   7  5  7  38:28    1  2 16  20:71    58:99  -41   31
~~~

(Source: `1-division1.csv`)


~~~
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. Bristol City                  38  17  1  1  43:8    13  5  1  40:20    83:28  +55   96
 2. Manchester United             38  15  3  1  55:13   13  3  3  35:15    90:28  +62   90
 3. Chelsea                       38  13  4  2  58:16    9  5  5  32:21    90:37  +53   75
 4. West Bromwich Albion          38  13  4  2  53:16    9  4  6  26:20    79:36  +43   74
 5. Hull City                     38  10  5  4  38:21    9  1  9  29:33    67:54  +13   63
 6. Leeds City                    38  11  5  3  38:19    6  4  9  21:28    59:47  +12   60
 7. Leicester City                38  10  3  6  30:21    5  9  5  23:27    53:48   +5   57
 8. Grimsby Town                  38  11  7  1  33:13    4  3 12  13:33    46:46        55
 9. Burnley                       38   9  4  6  26:23    6  4  9  16:30    42:53  -11   53
10. Stockport County              38  11  6  2  36:16    2  3 14   8:40    44:56  -12   48
11. Bradford City                 38   7  4  8  21:22    6  4  9  25:38    46:60  -14   47
12. Barnsley                      38  11  4  4  45:17    1  5 13  15:45    60:62   -2   45
13. Lincoln City                  38  10  1  8  46:29    2  5 12  23:43    69:72   -3   42
14. Gainsborough Trinity          38  10  2  7  35:22    2  2 15   9:35    44:57  -13   40
15. Port Vale                     38  10  4  5  34:25    2  0 17  15:57    49:82  -33   40
16. Blackpool                     38   8  3  8  22:21    2  6 11  15:41    37:62  -25   39
17. Glossop North End             38   9  4  6  36:28    1  4 14  13:43    49:71  -22   38
18. Chesterfield                  38   8  4  7  26:24    2  4 13  14:48    40:72  -32   38
19. Burton United                 38   9  4  6  26:20    1  2 16   8:47    34:67  -33   36
20. Leyton Orient                 38   6  4  9  19:22    1  3 15  16:56    35:78  -43   28
~~~

(Source: `2-division2.csv`)



---
Pld = Matches; W = Matches won; D = Matches drawn; L = Matches lost; F = Goals for; A = Goals against; +/- = Goal differencence; Pts = Points

