

### Standings


~~~
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. Newcastle United              38  18  1  0  51:12    4  6  9  23:34    74:46  +28   73
 2. Bristol City                  38  12  3  4  37:18    8  5  6  29:29    66:47  +19   68
 3. Everton                       38  16  2  1  50:10    4  3 12  20:36    70:46  +24   65
 4. Arsenal                       38  15  1  3  38:15    5  3 11  28:44    66:59   +7   64
 5. Aston Villa                   38  13  4  2  51:19    6  2 11  27:33    78:52  +26   63
 6. Bolton Wanderers              38  10  4  5  35:18    8  4  7  24:29    59:47  +12   62
 7. Sheffield United              38  13  4  2  36:17    4  7  8  21:38    57:55   +2   62
 8. Manchester United             38  10  6  3  33:15    7  2 10  20:41    53:56   -3   59
 9. Birmingham City               38  13  5  1  41:17    2  3 14  11:35    52:52        53
10. Sunderland                    38  10  4  5  42:31    4  5 10  23:35    65:66   -1   51
11. Middlesbrough                 38  11  2  6  33:21    4  4 11  23:42    56:63   -7   51
12. Blackburn Rovers              38  10  3  6  40:25    4  4 11  16:34    56:59   -3   49
13. Preston North End             38  13  4  2  35:19    1  3 15   9:38    44:57  -13   49
14. Sheffield Wednesday           38   8  5  6  33:26    4  6  9  16:34    49:60  -11   47
15. Liverpool                     38   9  2  8  45:32    4  5 10  19:33    64:65   -1   46
16. Bury                          38   9  4  6  30:23    4  2 13  28:45    58:68  -10   45
17. Manchester City               38   7  7  5  29:25    3  5 11  24:52    53:77  -24   42
18. Notts County                  38   6  9  4  31:18    2  6 11  15:32    46:50   -4   39
19. Derby County                  38   8  6  5  29:19    1  3 15  12:40    41:59  -18   36
20. Stoke City                    38   7  6  6  27:22    1  4 14  14:42    41:64  -23   34
~~~

(Source: `1-division1.csv`)


~~~
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. Nottingham Forest             38  16  2  1  43:13   12  2  5  31:23    74:36  +38   88
 2. Chelsea                       38  18  0  1  55:10    8  5  6  25:24    80:34  +46   83
 3. West Bromwich Albion          38  15  2  2  62:15    6  3 10  21:30    83:45  +38   68
 4. Leicester City                38  15  3  1  44:12    5  5  9  18:27    62:39  +23   68
 5. Bradford City                 38  14  2  3  46:21    7  3  9  24:32    70:53  +17   68
 6. Wolverhampton Wanderers       38  13  4  2  49:16    4  3 12  17:37    66:53  +13   58
 7. Burnley                       38  12  4  3  45:13    5  2 12  17:34    62:47  +15   57
 8. Barnsley                      38  14  2  3  56:21    1  6 12  17:34    73:55  +18   53
 9. Hull City                     38  11  2  6  41:20    4  5 10  24:37    65:57   +8   52
10. Grimsby Town                  38  13  2  4  34:16    3  1 15  23:46    57:62   -5   51
11. Leeds City                    38  10  5  4  38:26    3  5 11  17:37    55:63   -8   49
12. Stockport County              38   8  8  3  26:12    4  3 12  16:40    42:52  -10   47
13. Gainsborough Trinity          38  12  3  4  33:20    2  2 15  12:52    45:72  -27   47
14. Glossop North End             38  10  4  5  32:21    3  2 14  21:58    53:79  -26   45
15. Blackpool                     38   9  4  6  25:19    2  7 10   8:32    33:51  -18   44
16. Port Vale                     38  11  5  3  45:26    1  2 16  15:57    60:83  -23   43
17. Leyton Orient                 38   9  7  3  25:13    2  1 16  20:54    45:67  -22   41
18. Chesterfield                  38  10  3  6  36:26    1  4 14  14:40    50:66  -16   40
19. Lincoln City                  38  10  2  7  29:24    2  2 15  17:49    46:73  -27   40
20. Burton United                 38   7  3  9  24:23    1  4 14  10:45    34:68  -34   31
~~~

(Source: `2-division2.csv`)



---
Pld = Matches; W = Matches won; D = Matches drawn; L = Matches lost; F = Goals for; A = Goals against; +/- = Goal differencence; Pts = Points

