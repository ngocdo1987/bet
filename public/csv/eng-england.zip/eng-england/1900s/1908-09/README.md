

### Standings


~~~
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. Newcastle United              38  14  1  4  32:20   10  4  5  33:21    65:41  +24   77
 2. Sunderland                    38  14  0  5  41:23    7  2 10  37:40    78:63  +15   65
 3. Everton                       38  11  3  5  51:28    7  7  5  31:29    82:57  +25   64
 4. Sheffield Wednesday           38  15  0  4  48:24    2  6 11  19:37    67:61   +6   57
 5. Blackburn Rovers              38   6  6  7  29:26    8  7  4  32:24    61:50  +11   55
 6. Arsenal                       38   9  3  7  24:18    5  7  7  28:31    52:49   +3   52
 7. Aston Villa                   38   8  7  4  31:22    6  3 10  27:34    58:56   +2   52
 8. Manchester United             38  10  3  6  37:33    5  4 10  21:35    58:68  -10   52
 9. Middlesbrough                 38  11  2  6  38:21    3  7  9  21:32    59:53   +6   51
10. Chelsea                       38   8  7  4  33:22    6  2 11  23:39    56:61   -5   51
11. Liverpool                     38   9  5  5  36:25    6  1 12  21:40    57:65   -8   51
12. Sheffield United              38   9  5  5  31:25    5  4 10  20:34    51:59   -8   51
13. Bristol City                  38   7  7  5  24:25    6  5  8  21:33    45:58  -13   51
14. Nottingham Forest             38   9  2  8  39:24    5  6  8  27:33    66:57   +9   50
15. Preston North End             38   8  7  4  29:17    5  4 10  19:27    48:44   +4   50
16. Notts County                  38   9  4  6  31:23    5  4 10  20:25    51:48   +3   50
17. Bury                          38   9  6  4  35:27    5  2 12  28:50    63:77  -14   50
18. Manchester City               38  12  3  4  50:23    3  1 15  17:46    67:69   -2   49
19. Bradford City                 38   7  6  6  27:20    5  4 10  20:27    47:47        46
20. Leicester City                38   6  6  7  32:41    2  3 14  22:61    54:102 -48   33
~~~

(Source: `1-division1.csv`)


~~~
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. Bolton Wanderers              38  14  3  2  37:8    10  1  8  22:20    59:28  +31   76
 2. Tottenham Hotspur             38  12  5  2  42:12    8  6  5  25:20    67:32  +35   71
 3. West Bromwich Albion          38  13  5  1  35:9     6  8  5  21:18    56:27  +29   70
 4. Hull City                     38  14  2  3  44:15    5  4 10  19:24    63:39  +24   63
 5. Derby County                  38  13  5  1  38:11    3  6 10  17:30    55:41  +14   59
 6. Oldham Athletic               38  14  4  1  39:9     3  2 14  16:34    55:43  +12   57
 7. Wolverhampton Wanderers       38  10  6  3  32:12    4  5 10  24:36    56:48   +8   53
 8. Glossop North End             38  11  5  3  35:17    4  3 12  22:36    57:53   +4   53
 9. Gainsborough Trinity          38  12  3  4  30:20    3  5 11  19:50    49:70  -21   53
10. Birmingham City               38  10  6  3  35:21    4  3 12  23:40    58:61   -3   51
11. Fulham                        38   8  4  7  39:26    5  7  7  19:22    58:48  +10   50
12. Leeds City                    38  12  3  4  35:19    2  4 13   8:34    43:53  -10   49
13. Grimsby Town                  38   9  5  5  23:14    5  2 12  18:40    41:54  -13   49
14. Burnley                       38   8  4  7  33:28    5  3 11  18:30    51:58   -7   46
15. Bradford Park Avenue          38   9  2  8  30:25    4  4 11  21:34    51:59   -8   45
16. Leyton Orient                 38   7  7  5  25:19    5  2 12  12:30    37:49  -12   45
17. Stockport County              38  11  2  6  25:19    3  1 15  14:52    39:71  -32   45
18. Barnsley                      38  11  3  5  36:19    0  7 12  12:38    48:57   -9   43
19. Chesterfield                  38  10  3  6  30:28    1  5 13   7:39    37:67  -30   41
20. Blackpool                     38   9  6  4  30:22    0  5 14  16:46    46:68  -22   38
~~~

(Source: `2-division2.csv`)



---
Pld = Matches; W = Matches won; D = Matches drawn; L = Matches lost; F = Goals for; A = Goals against; +/- = Goal differencence; Pts = Points

