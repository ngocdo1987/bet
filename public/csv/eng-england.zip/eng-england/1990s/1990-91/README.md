

### Standings


~~~
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. Arsenal                       38  15  4  0  51:10    9  9  1  23:8     74:18  +56   85
 2. Liverpool                     38  14  3  2  42:13    9  4  6  35:27    77:40  +37   76
 3. Crystal Palace                38  11  6  2  26:17    9  3  7  24:24    50:41   +9   69
 4. Leeds United                  38  12  2  5  46:23    7  5  7  19:24    65:47  +18   64
 5. Manchester City               38  12  3  4  35:25    5  8  6  29:28    64:53  +11   62
 6. Manchester United             38  11  4  4  34:17    5  8  6  24:28    58:45  +13   60
 7. Wimbledon                     38   8  6  5  28:22    6  8  5  25:24    53:46   +7   56
 8. Nottingham Forest             38  11  4  4  42:21    3  8  8  23:29    65:50  +15   54
 9. Everton                       38   9  5  5  26:15    4  7  8  24:31    50:46   +4   51
10. Tottenham Hotspur             38   8  9  2  35:22    3  7  9  16:28    51:50   +1   49
11. Chelsea                       38  10  6  3  33:25    3  4 12  25:44    58:69  -11   49
12. Queens Park Rangers           38   8  5  6  27:22    4  5 10  17:31    44:53   -9   46
13. Sheffield United              38   9  3  7  23:23    4  4 11  13:32    36:55  -19   46
14. Southampton                   38   9  6  4  33:22    3  3 13  25:47    58:69  -11   45
15. Norwich City                  38   9  3  7  27:32    4  3 12  14:32    41:64  -23   45
16. Coventry City                 38  10  6  3  30:16    1  5 13  12:33    42:49   -7   44
17. Aston Villa                   38   7  9  3  29:25    2  5 12  17:33    46:58  -12   41
18. Luton Town                    38   7  5  7  22:18    3  2 14  20:43    42:61  -19   37
19. Sunderland                    38   6  6  7  15:16    2  4 13  23:44    38:60  -22   34
20. Derby County                  38   3  8  8  25:36    2  1 16  12:39    37:75  -38   24
~~~

(Source: `1-division1.csv`)


~~~
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. Oldham Athletic               46  17  5  1  55:21    8  8  7  28:32    83:53  +30   88
 2. West Ham United               46  15  6  2  41:18    9  9  5  19:16    60:34  +26   87
 3. Sheffield Wednesday           46  12 10  1  43:23   10  6  7  37:28    80:51  +29   82
 4. Notts County                  46  14  4  5  45:28    9  7  7  31:27    76:55  +21   80
 5. Millwall                      46  11  6  6  43:28    9  7  7  27:23    70:51  +19   73
 6. Brighton & Hove Albion        46  12  4  7  37:31    9  3 11  26:38    63:69   -6   70
 7. Middlesbrough                 46  12  4  7  36:17    8  5 10  30:30    66:47  +19   69
 8. Barnsley                      46  13  7  3  39:16    6  5 12  24:32    63:48  +15   69
 9. Bristol City                  46  14  5  4  44:28    6  2 15  24:43    68:71   -3   67
10. Oxford United                 46  10  9  4  41:29    4 10  9  28:37    69:66   +3   61
11. Newcastle United              46   8 10  5  24:22    6  7 10  25:34    49:56   -7   59
12. Wolverhampton Wanderers       46  11  6  6  45:35    2 13  8  18:28    63:63        58
13. Bristol Rovers                46  11  7  5  29:20    4  6 13  27:39    56:59   -3   58
14. Ipswich Town                  46   9  8  6  32:28    4 10  9  28:40    60:68   -8   57
15. Port Vale                     46  10  4  9  32:24    5  8 10  24:40    56:64   -8   57
16. Charlton Athletic             46   8  7  8  27:25    5 10  8  30:36    57:61   -4   56
17. Portsmouth                    46  10  6  7  34:27    4  5 14  24:43    58:70  -12   53
18. Plymouth Argyle               46  10 10  3  36:20    2  7 14  18:48    54:68  -14   53
19. Blackburn Rovers              46   8  6  9  26:27    6  4 13  25:39    51:66  -15   52
20. Watford                       46   5  8 10  24:32    7  7  9  21:27    45:59  -14   51
21. Swindon Town                  46   8  6  9  31:30    4  8 11  34:43    65:73   -8   50
22. Leicester City                46  12  4  7  41:33    2  4 17  19:50    60:83  -23   50
23. West Bromwich Albion          46   7 11  5  26:21    3  7 13  26:40    52:61   -9   48
24. Hull City                     46   6 10  7  35:32    4  5 14  22:53    57:85  -28   45
~~~

(Source: `2-division2.csv`)


~~~
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. Cambridge United              46  14  5  4  42:22   11  6  6  33:23    75:45  +30   86
 2. Southend United               46  13  6  4  34:23   13  1  9  33:28    67:51  +16   85
 3. Grimsby Town                  46  16  3  4  42:13    8  8  7  24:21    66:34  +32   83
 4. Bolton Wanderers              46  14  5  4  33:18   10  6  7  31:32    64:50  +14   83
 5. Tranmere Rovers               46  13  5  5  38:21   10  4  9  26:25    64:46  +18   78
 6. Brentford                     46  12  4  7  30:22    9  9  5  29:25    59:47  +12   76
 7. Bury                          46  13  6  4  39:26    7  7  9  28:30    67:56  +11   73
 8. Bradford City                 46  13  3  7  36:22    7  7  9  26:32    62:54   +8   70
 9. AFC Bournemouth               46  14  6  3  37:20    5  7 11  21:38    58:58        70
10. Wigan Athletic                46  14  3  6  40:20    6  6 11  31:34    71:54  +17   69
11. Huddersfield Town             46  13  3  7  37:23    5 10  8  20:28    57:51   +6   67
12. Birmingham City               46   8  9  6  21:21    8  8  7  24:28    45:49   -4   65
13. Leyton Orient                 46  15  2  6  35:19    3  8 12  20:39    55:58   -3   64
14. Stoke City                    46   9  7  7  36:29    7  5 11  19:30    55:59   -4   60
15. Reading                       46  11  5  7  34:28    6  3 14  19:38    53:66  -13   59
16. Exeter City                   46  12  6  5  35:16    4  3 16  23:36    58:52   +6   57
17. Preston North End             46  11  5  7  33:29    4  6 13  21:38    54:67  -13   56
18. Shrewsbury Town               46   8  7  8  29:22    6  3 14  32:46    61:68   -7   52
19. Chester                       46  10  3 10  27:27    4  6 13  19:31    46:58  -12   51
20. Swansea City                  46   8  6  9  31:33    5  3 15  18:39    49:72  -23   48
21. Fulham                        46   8  8  7  27:22    2  8 13  14:34    41:56  -15   46
22. Crewe Alexandra               46   6  9  8  35:35    5  2 16  27:45    62:80  -18   44
23. Rotherham United              46   5 10  8  31:38    5  2 16  19:49    50:87  -37   42
24. Mansfield Town                46   5  8 10  23:27    3  6 14  19:36    42:63  -21   38
~~~

(Source: `3-division3.csv`)


~~~
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. Darlington                    46  13  8  2  36:14    9  9  5  32:24    68:38  +30   83
 2. Stockport County              46  16  6  1  54:19    7  7  9  30:28    84:47  +37   82
 3. Hartlepool United             46  15  5  3  35:15    9  5  9  32:33    67:48  +19   82
 4. Peterborough United           46  13  9  1  38:15    8  8  7  29:30    67:45  +22   80
 5. Blackpool                     46  17  3  3  55:17    6  7 10  23:30    78:47  +31   79
 6. Burnley                       46  17  5  1  46:16    6  5 12  24:35    70:51  +19   79
 7. Torquay United                46  14  7  2  37:13    4 11  8  27:34    64:47  +17   72
 8. Scunthorpe United             46  17  4  2  51:20    3  7 13  20:42    71:62   +9   71
 9. Scarborough                   46  13  5  5  36:21    6  7 10  23:35    59:56   +3   69
10. Doncaster Rovers              46  12  5  6  36:22    5  9  9  20:24    56:46  +10   65
11. Northampton Town              46  13  5  5  33:23    4  8 11  23:37    56:60   -4   64
12. Rochdale                      46  10  9  4  29:22    5  8 10  21:31    50:53   -3   62
13. Cardiff City                  46  10  6  7  26:23    5  9  9  17:31    43:54  -11   60
14. Lincoln City                  46  10  7  6  32:27    4 10  9  18:34    50:61  -11   59
15. Chesterfield                  46   8 12  3  33:26    6  2 15  16:35    49:61  -12   56
16. Gillingham                    46   9  9  5  35:27    3  9 11  22:33    57:60   -3   54
17. Walsall                       46   7 12  4  25:17    5  5 13  23:34    48:51   -3   53
18. Hereford United               46   9 10  4  32:19    4  4 15  21:39    53:58   -5   53
19. Maidstone United              46   9  5  9  42:34    4  7 12  24:37    66:71   -5   51
20. Carlisle United               46  12  3  8  30:30    1  6 16  17:59    47:89  -42   48
21. York City                     46   8  6  9  21:23    3  7 13  24:34    45:57  -12   46
22. Halifax Town                  46   9  6  8  34:29    3  4 16  25:50    59:79  -20   46
23. Aldershot                     46   8  7  8  38:43    2  4 17  23:58    61:101 -40   41
24. Wrexham                       46   8  7  8  33:34    2  3 18  15:40    48:74  -26   40
~~~

(Source: `4-division4.csv`)



---
Pld = Matches; W = Matches won; D = Matches drawn; L = Matches lost; F = Goals for; A = Goals against; +/- = Goal differencence; Pts = Points

