

### Standings


~~~
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. Liverpool                     42  15  6  0  46:8    10  4  7  35:22    81:30  +51   85
 2. Manchester United             42  17  3  1  43:8     7  7  7  22:27    65:35  +30   82
 3. Ipswich Town                  42  14  4  3  43:13    8  5  8  25:26    68:39  +29   75
 4. Arsenal                       42   8 10  3  24:12   10  6  5  28:24    52:36  +16   70
 5. Nottingham Forest             42  16  4  1  44:11    4  4 13  19:32    63:43  +20   68
 6. Wolverhampton Wanderers       42   9  6  6  29:20   10  3  8  29:27    58:47  +11   66
 7. Southampton                   42  14  2  5  53:24    4  7 10  12:29    65:53  +12   63
 8. Aston Villa                   42  11  5  5  29:22    5  9  7  22:28    51:50   +1   62
 9. Middlesbrough                 42  11  7  3  31:14    5  5 11  19:30    50:44   +6   60
10. Coventry City                 42  12  2  7  34:24    4  5 12  22:42    56:66  -10   55
11. Tottenham Hotspur             42  11  5  5  30:22    4  5 12  22:40    52:62  -10   55
12. Leeds United                  42  10  7  4  30:17    3  7 11  16:33    46:50   -4   53
13. Norwich City                  42  10  8  3  38:30    3  6 12  20:36    58:66   -8   53
14. West Bromwich Albion          42   9  8  4  37:23    2 11  8  17:27    54:50   +4   52
15. Crystal Palace                42   9  9  3  26:13    3  7 11  15:37    41:50   -9   52
16. Stoke City                    42   9  4  8  27:26    4  6 11  17:32    44:58  -14   49
17. Manchester City               42   8  8  5  28:25    4  5 12  15:41    43:66  -23   49
18. Brighton & Hove Albion        42   8  8  5  25:20    3  7 11  22:37    47:57  -10   48
19. Everton                       42   7  7  7  28:25    2 10  9  15:26    43:51   -8   44
20. Derby County                  42   9  4  8  36:29    2  4 15  11:38    47:67  -20   41
21. Bristol City                  42   6  6  9  22:30    3  7 11  15:36    37:66  -29   40
22. Bolton Wanderers              42   5 11  5  19:21    0  4 17  19:52    38:73  -35   30
~~~

(Source: `1-division1.csv`)


~~~
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. Birmingham City               42  14  5  2  35:14    8  6  7  22:22    57:36  +21   77
 2. Sunderland                    42  16  5  0  47:13    5  7  9  22:34    69:47  +22   75
 3. Leicester City                42  11  5  5  31:20    9  8  4  26:19    57:39  +18   73
 4. Chelsea                       42  13  3  5  33:17    9  4  8  32:36    65:53  +12   73
 5. Queens Park Rangers           42  10  9  2  46:25    8  4  9  29:28    75:53  +22   67
 6. West Ham United               42  13  2  6  37:22    7  5  9  18:23    55:45  +10   67
 7. Luton Town                    42   9 10  2  36:17    7  7  7  30:28    66:45  +21   65
 8. Swansea City                  42  13  1  7  31:20    4  8  9  18:28    49:48   +1   60
 9. Shrewsbury Town               42  12  3  6  41:23    6  2 13  19:30    60:53   +7   59
10. Newcastle United              42  13  6  2  37:20    2  8 11  18:30    55:50   +5   59
11. Oldham Athletic               42  12  5  4  30:21    4  6 11  19:32    49:53   -4   59
12. Cambridge United              42  11  6  4  40:23    3 10  8  21:30    61:53   +8   58
13. Cardiff City                  42  11  4  6  21:16    5  4 12  20:32    41:48   -7   56
14. Preston North End             42   8 10  3  30:23    4  9  8  24:27    54:50   +4   55
15. Leyton Orient                 42   7  9  5  29:31    5  8  8  19:23    48:54   -6   53
16. Wrexham                       42  13  2  6  26:15    3  3 15  13:36    39:51  -12   53
17. Notts County                  42   5 10  6  25:21    7  4 10  27:30    52:51   +1   50
18. Watford                       42   9  6  6  27:18    3  7 11  12:28    39:46   -7   49
19. Bristol Rovers                42   9  8  4  33:23    2  5 14  17:41    50:64  -14   46
20. Fulham                        42   6  4 11  20:28    5  3 13  23:46    43:74  -31   40
21. Burnley                       42   5  9  7  19:23    2  6 13  21:49    40:72  -32   36
22. Charlton Athletic             42   6  6  9  25:31    0  4 17  14:47    39:78  -39   28
~~~

(Source: `2-division2.csv`)


~~~
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. Grimsby Town                  46  18  2  3  46:16    8  8  7  27:26    73:42  +31   88
 2. Blackburn Rovers              46  13  5  5  34:17   12  3  8  23:19    57:36  +21   83
 3. Chesterfield                  46  16  5  2  46:16    7  6 10  25:30    71:46  +25   80
 4. Sheffield Wednesday           46  12  6  5  44:20    9 10  4  37:27    81:47  +34   79
 5. Colchester United             46  10 10  3  39:20   10  2 11  25:36    64:56   +8   72
 6. Exeter City                   46  15  4  4  38:21    5  5 13  22:46    60:67   -7   69
 7. Rotherham United              46  14  4  5  40:22    5  6 12  20:42    60:64   -4   67
 8. Carlisle United               46  13  6  4  45:26    5  6 12  21:30    66:56  +10   66
 9. Reading                       46  15  5  3  43:18    2 10 11  23:46    66:64   +2   66
10. Chester                       46  15  5  3  31:18    3  7 13  20:39    51:57   -6   66
11. Swindon Town                  46  15  4  4  50:20    4  4 15  21:43    71:63   +8   65
12. Sheffield United              46  13  5  5  35:21    5  5 13  25:45    60:66   -6   64
13. Barnsley                      46  10  7  6  29:20    6  7 10  25:37    54:57   -3   62
14. Millwall                      46  14  6  3  49:23    2  6 15  15:37    64:60   +4   60
15. Plymouth Argyle               46  12  8  3  36:17    3  4 16  19:38    55:55        57
16. Gillingham                    46   8  9  6  26:18    6  5 12  23:33    49:51   -2   56
17. Oxford United                 46  10  4  9  34:24    4  9 10  23:38    57:62   -5   55
18. Southend United               46  11  6  6  32:22    4  4 15  18:34    50:56   -6   55
19. Bury                          46  10  4  9  30:23    6  3 14  15:36    45:59  -14   55
20. Blackpool                     46  10  7  6  39:34    4  4 15  20:41    59:75  -16   53
21. Brentford                     46   9  6  8  32:30    5  5 13  26:47    58:77  -19   53
22. Hull City                     46  11  7  5  29:21    1  9 13  22:48    51:69  -18   52
23. Mansfield Town                46   9  9  5  31:24    1  7 15  16:34    47:58  -11   46
24. Wimbledon                     46   6  8  9  34:38    4  7 12  18:40    52:78  -26   45
~~~

(Source: `3-division3.csv`)


~~~
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. Huddersfield Town             46  16  5  2  61:18   10  7  6  37:33    98:51  +47   90
 2. Newport County                46  16  5  2  47:22   11  2 10  36:28    83:50  +33   88
 3. Walsall                       46  12  9  2  43:23   11  9  3  31:24    74:47  +27   87
 4. Portsmouth                    46  15  5  3  62:23    9  7  7  29:26    91:49  +42   84
 5. Bradford City                 46  14  6  3  44:14   10  6  7  33:36    77:50  +27   84
 6. Wigan Athletic                46  13  5  5  42:26    8  8  7  34:35    76:61  +15   76
 7. Peterborough United           46  14  3  6  39:22    7  7  9  19:25    58:47  +11   73
 8. Lincoln City                  46  14  8  1  43:12    4  9 10  21:30    64:42  +22   71
 9. Torquay United                46  13  7  3  47:25    2 10 11  23:44    70:69   +1   62
10. Aldershot                     46  10  7  6  35:23    6  6 11  27:30    62:53   +9   61
11. Northampton Town              46  14  5  4  33:16    2  7 14  18:50    51:66  -15   60
12. Doncaster Rovers              46  11  6  6  37:27    4  8 11  25:36    62:63   -1   59
13. AFC Bournemouth               46   8  9  6  32:25    5  9  9  20:26    52:51   +1   57
14. Scunthorpe United             46  11  9  3  37:23    3  6 14  21:52    58:75  -17   57
15. Tranmere Rovers               46  10  4  9  32:24    4  9 10  18:32    50:56   -6   55
16. Stockport County              46   9  7  7  30:31    5  5 13  18:41    48:72  -24   54
17. York City                     46   9  6  8  35:34    5  5 13  30:48    65:82  -17   53
18. Hartlepool United             46  10  7  6  36:28    4  3 16  23:36    59:64   -5   52
19. Halifax Town                  46  11  9  3  29:19    2  4 17  17:52    46:71  -25   52
20. Hereford United               46   8  7  8  22:21    4  7 12  19:28    41:49   -8   50
21. Port Vale                     46   8  6  9  34:24    4  6 13  22:46    56:70  -14   48
22. Crewe Alexandra               46  10  6  7  25:27    1  7 15  10:41    35:68  -33   46
23. Darlington                    46   7 11  5  33:26    2  6 15  17:48    50:74  -24   44
24. Rochdale                      46   6  7 10  20:28    1  6 16  13:51    33:79  -46   34
~~~

(Source: `4-division4.csv`)



---
Pld = Matches; W = Matches won; D = Matches drawn; L = Matches lost; F = Goals for; A = Goals against; +/- = Goal differencence; Pts = Points

