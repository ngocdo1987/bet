

### Standings


~~~
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. Derby County                  42  16  4  1  43:10    8  6  7  26:23    69:33  +36   82
 2. Leeds United                  42  17  4  0  54:10    7  5  9  19:21    73:31  +42   81
 3. Liverpool                     42  17  3  1  48:16    7  6  8  16:14    64:30  +34   81
 4. Manchester City               42  16  3  2  48:15    7  8  6  29:30    77:45  +32   80
 5. Arsenal                       42  15  2  4  36:13    7  6  8  22:27    58:40  +18   74
 6. Tottenham Hotspur             42  16  3  2  45:13    3 10  8  18:29    63:42  +21   70
 7. Manchester United             42  13  2  6  39:26    6  8  7  30:35    69:61   +8   67
 8. Chelsea                       42  12  7  2  41:20    6  5 10  17:29    58:49   +9   66
 9. Wolverhampton Wanderers       42  10  7  4  35:23    8  4  9  30:34    65:57   +8   65
10. Sheffield United              42  10  8  3  39:26    7  4 10  22:34    61:60   +1   63
11. Newcastle United              42  10  6  5  30:18    5  5 11  19:34    49:52   -3   56
12. Leicester City                42   9  6  6  18:11    4  7 10  23:35    41:46   -5   52
13. Ipswich Town                  42   7  8  6  19:19    4  8  9  20:34    39:53  -14   49
14. West Ham United               42  10  6  5  31:19    2  6 13  16:32    47:51   -4   48
15. West Bromwich Albion          42   6  7  8  22:23    6  4 11  20:31    42:54  -12   47
16. Everton                       42   8  9  4  28:17    1  9 11   9:31    37:48  -11   45
17. Stoke City                    42   6 10  5  26:25    4  5 12  13:31    39:56  -17   45
18. Southampton                   42   8  5  8  31:28    4  2 15  21:52    52:80  -28   43
19. Coventry City                 42   7 10  4  27:23    2  5 14  17:44    44:67  -23   42
20. Crystal Palace                42   4  8  9  26:31    4  5 12  13:34    39:65  -26   37
21. Nottingham Forest             42   6  4 11  25:29    2  5 14  22:52    47:81  -34   33
22. Huddersfield Town             42   4  7 10  12:22    2  6 13  15:37    27:59  -32   31
~~~

(Source: `1-division1.csv`)


~~~
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. Norwich City                  42  13  8  0  40:16    8  7  6  20:20    60:36  +24   78
 2. Birmingham City               42  15  6  0  46:14    4 12  5  14:17    60:31  +29   75
 3. Queens Park Rangers           42  16  4  1  39:9     4 10  7  18:19    57:28  +29   74
 4. Millwall                      42  14  7  0  38:17    5 10  6  26:29    64:46  +18   74
 5. Blackpool                     42  12  6  3  43:16    8  1 12  27:34    70:50  +20   67
 6. Sunderland                    42  11  7  3  42:24    6  9  6  25:33    67:57  +10   67
 7. Burnley                       42  13  4  4  43:22    7  2 12  27:33    70:55  +15   66
 8. Middlesbrough                 42  16  4  1  31:11    3  4 14  19:37    50:48   +2   65
 9. Bristol City                  42  14  3  4  43:22    4  7 10  18:27    61:49  +12   64
10. Carlisle United               42  12  6  3  38:22    5  3 13  23:35    61:57   +4   60
11. Swindon Town                  42  10  6  5  29:16    5  6 10  18:31    47:47        57
12. Hull City                     42  10  6  5  33:21    4  4 13  16:32    49:53   -4   52
13. Sheffield Wednesday           42  11  7  3  33:22    2  5 14  18:36    51:58   -7   51
14. Leyton Orient                 42  12  4  5  32:19    2  5 14  18:42    50:61  -11   51
15. Oxford United                 42  10  8  3  28:17    2  6 13  15:38    43:55  -12   50
16. Portsmouth                    42   9  7  5  31:26    3  6 12  28:42    59:68   -9   49
17. Luton Town                    42   7  8  6  25:24    3 10  8  18:24    43:48   -5   48
18. Preston North End             42  11  4  6  32:21    1  8 12  20:37    52:58   -6   48
19. Fulham                        42  10  7  4  29:20    2  3 16  16:48    45:68  -23   46
20. Charlton Athletic             42   9  7  5  33:25    3  2 16  22:52    55:77  -22   45
21. Cardiff City                  42   9  7  5  37:25    1  7 13  19:44    56:69  -13   44
22. Watford                       42   5  5 11  15:25    0  4 17   9:50    24:75  -51   24
~~~

(Source: `2-division2.csv`)


~~~
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. Aston Villa                   46  20  1  2  45:10   12  5  6  40:22    85:32  +53  102
 2. Brighton & Hove Albion        46  15  5  3  39:18   12  6  5  43:29    82:47  +35   92
 3. Notts County                  46  16  3  4  42:19    9  9  5  32:25    74:44  +30   87
 4. AFC Bournemouth               46  16  6  1  43:13    7 10  6  30:24    73:37  +36   85
 5. Bristol Rovers                46  17  2  4  54:26    4 10  9  21:30    75:56  +19   75
 6. Rotherham United              46  12  8  3  46:25    8  7  8  23:27    69:52  +17   75
 7. Plymouth Argyle               46  13  6  4  43:26    7  4 12  31:38    74:64  +10   70
 8. Bolton Wanderers              46  11  8  4  25:13    6  8  9  26:28    51:41  +10   67
 9. Blackburn Rovers              46  14  4  5  39:22    5  5 13  15:35    54:57   -3   66
10. Walsall                       46  12  8  3  38:16    3 10 10  24:41    62:57   +5   63
11. Chesterfield                  46  10  5  8  25:23    8  3 12  32:34    57:57        62
12. Oldham Athletic               46  11  4  8  37:35    6  7 10  22:28    59:63   -4   62
13. Shrewsbury Town               46  13  5  5  50:29    4  5 14  23:36    73:65   +8   61
14. Swansea City                  46  10  6  7  27:21    7  4 12  19:38    46:59  -13   61
15. Wrexham                       46  10  5  8  33:26    6  3 14  26:37    59:63   -4   56
16. Port Vale                     46  10 10  3  27:21    3  5 15  16:38    43:59  -16   54
17. Halifax Town                  46  11  6  6  31:22    2  6 15  17:39    48:61  -13   51
18. Rochdale                      46  11  7  5  35:26    1  6 16  22:57    57:83  -26   49
19. York City                     46   8  8  7  32:22    4  4 15  25:44    57:66   -9   48
20. Tranmere Rovers               46   9  7  7  34:30    1  9 13  16:41    50:71  -21   46
21. Barnsley                      46   6 10  7  23:30    3  8 12   9:34    32:64  -32   45
22. Mansfield Town                46   5 12  6  19:26    3  8 12  22:37    41:63  -22   44
23. Bradford City                 46   6  8  9  27:32    5  2 16  18:45    45:77  -32   43
24. Torquay United                46   8  6  9  31:31    2  6 15  10:38    41:69  -28   42
~~~

(Source: `3-division3.csv`)


~~~
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. Grimsby Town                  46  18  3  2  61:26   10  4  9  27:30    88:56  +32   91
 2. Southend United               46  18  2  3  56:26    6 10  7  25:29    81:55  +26   84
 3. Brentford                     46  16  2  5  52:21    8  9  6  24:23    76:44  +32   83
 4. Scunthorpe United             46  13  8  2  34:15    9  5  9  22:22    56:37  +19   79
 5. Lincoln City                  46  17  5  1  46:15    4  9 10  31:44    77:59  +18   77
 6. Bury                          46  16  4  3  55:22    3  8 12  18:37    73:59  +14   69
 7. Southport                     46  15  5  3  48:21    3  9 11  18:25    66:46  +20   68
 8. Peterborough United           46  14  6  3  51:24    3 10 10  31:40    82:64  +18   67
 9. Workington                    46  12  9  2  34:7     4 10  9  16:27    50:34  +16   67
10. Colchester United             46  13  6  4  38:23    6  4 13  32:46    70:69   +1   67
11. Cambridge United              46  11  8  4  38:22    6  6 11  24:38    62:60   +2   65
12. Doncaster Rovers              46  11  8  4  35:24    5  6 12  21:39    56:63   -7   62
13. Newport County                46  13  5  5  34:20    5  3 15  26:52    60:72  -12   62
14. Gillingham                    46  11  5  7  33:24    5  8 10  28:43    61:67   -6   61
15. Exeter City                   46  11  5  7  40:30    5  6 12  21:38    61:68   -7   59
16. Reading                       46  14  3  6  37:26    3  5 15  19:50    56:76  -20   59
17. Hartlepool United             46  14  2  7  39:25    3  4 16  19:44    58:69  -11   57
18. Darlington                    46   9  9  5  37:24    5  2 16  27:58    64:82  -18   53
19. Barrow                        46   8  8  7  23:26    5  3 15  17:45    40:71  -31   50
20. Aldershot                     46   5 13  5  27:20    4  9 10  21:34    48:54   -6   49
21. Northampton Town              46   8  9  6  43:27    4  4 15  23:52    66:79  -13   49
22. Chester                       46  10 11  2  34:16    0  7 16  13:40    47:56   -9   48
23. Stockport County              46   7 10  6  33:32    2  4 17  22:55    55:87  -32   41
24. Crewe Alexandra               46   9  4 10  27:25    1  5 17  16:44    43:69  -26   39
~~~

(Source: `4-division4.csv`)



---
Pld = Matches; W = Matches won; D = Matches drawn; L = Matches lost; F = Goals for; A = Goals against; +/- = Goal differencence; Pts = Points

