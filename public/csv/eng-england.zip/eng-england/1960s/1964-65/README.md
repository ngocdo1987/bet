

### Standings


~~~
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. Manchester United             42  16  4  1  52:13   10  5  6  37:26    89:39  +50   87
 2. Leeds United                  42  16  3  2  53:23   10  6  5  30:29    83:52  +31   87
 3. Chelsea                       42  15  2  4  48:19    9  6  6  41:35    89:54  +35   80
 4. Everton                       42   9 10  2  37:22    8  5  8  32:38    69:60   +9   66
 5. Tottenham Hotspur             42  18  3  0  65:20    1  4 16  22:51    87:71  +16   64
 6. Nottingham Forest             42  10  7  4  45:33    7  6  8  26:34    71:67   +4   64
 7. West Ham United               42  14  2  5  48:25    5  2 14  34:46    82:71  +11   61
 8. Liverpool                     42  12  5  4  42:33    5  5 11  25:40    67:73   -6   61
 9. Sheffield Wednesday           42  13  5  3  37:15    3  6 12  20:40    57:55   +2   59
10. Blackburn Rovers              42  12  2  7  46:33    4  8  9  37:46    83:79   +4   58
11. Stoke City                    42  11  4  6  40:27    5  6 10  27:39    67:66   +1   58
12. Burnley                       42   9  9  3  39:26    7  1 13  31:44    70:70        58
13. Arsenal                       42  11  5  5  42:31    6  2 13  27:44    69:75   -6   58
14. Aston Villa                   42  14  1  6  36:24    2  4 15  21:58    57:82  -25   53
15. West Bromwich Albion          42  10  5  6  45:25    3  8 10  25:40    70:65   +5   52
16. Sunderland                    42  12  6  3  45:26    2  3 16  19:48    64:74  -10   51
17. Blackpool                     42   9  7  5  41:28    3  4 14  26:50    67:78  -11   47
18. Sheffield United              42   7  5  9  30:29    5  6 10  20:35    50:64  -14   47
19. Leicester City                42   9  6  6  43:36    2  7 12  26:49    69:85  -16   46
20. Fulham                        42  10  5  6  44:32    1  7 13  16:46    60:78  -18   45
21. Wolverhampton Wanderers       42   8  2 11  33:36    5  2 14  26:53    59:89  -30   43
22. Birmingham City               42   6  8  7  36:40    2  3 16  28:56    64:96  -32   35
~~~

(Source: `1-division1.csv`)


~~~
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. Newcastle United              42  16  4  1  50:16    8  5  8  31:29    81:45  +36   81
 2. Northampton Town              42  14  7  0  37:16    6  9  6  29:34    66:50  +16   76
 3. Bolton Wanderers              42  13  6  2  46:17    7  4 10  34:41    80:58  +22   70
 4. Norwich City                  42  15  4  2  47:21    5  3 13  14:36    61:57   +4   67
 5. Southampton                   42  12  6  3  49:25    5  8  8  34:38    83:63  +20   65
 6. Ipswich Town                  42  11  7  3  48:30    4 10  7  26:37    74:67   +7   62
 7. Crystal Palace                42  11  6  4  37:24    5  7  9  18:27    55:51   +4   61
 8. Huddersfield Town             42  12  4  5  28:15    5  6 10  25:36    53:51   +2   61
 9. Coventry City                 42  10  5  6  41:29    7  4 10  31:41    72:70   +2   60
10. Derby County                  42  11  5  5  48:35    5  6 10  36:44    84:79   +5   59
11. Manchester City               42  12  3  6  40:24    4  6 11  23:38    63:62   +1   57
12. Plymouth Argyle               42  10  7  4  36:28    6  1 14  27:51    63:79  -16   56
13. Preston North End             42  11  8  2  46:29    3  5 13  30:52    76:81   -5   55
14. Rotherham United              42  10  7  4  39:25    4  5 12  31:44    70:69   +1   54
15. Cardiff City                  42  10  7  4  43:25    3  7 11  21:32    64:57   +7   53
16. Bury                          42   9  4  8  36:30    5  6 10  24:36    60:66   -6   52
17. Middlesbrough                 42   8  5  8  40:31    5  4 12  30:45    70:76   -6   48
18. Charlton Athletic             42   8  5  8  35:34    5  4 12  29:41    64:75  -11   48
19. Swindon Town                  42  12  3  6  43:30    2  2 17  20:51    63:81  -18   47
20. Leyton Orient                 42  10  4  7  36:34    2  7 12  14:38    50:72  -22   47
21. Portsmouth                    42  11  4  6  36:22    1  6 14  20:55    56:77  -21   46
22. Swansea City                  42   9  7  5  40:29    2  3 16  22:55    62:84  -22   43
~~~

(Source: `2-division2.csv`)


~~~
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. Carlisle United               46  14  5  4  46:24   11  5  7  30:29    76:53  +23   85
 2. Bristol City                  46  14  6  3  53:18   10  5  8  39:37    92:55  +37   83
 3. Mansfield Town                46  17  4  2  61:23    7  7  9  34:38    95:61  +34   83
 4. Hull City                     46  14  6  3  51:25    9  6  8  40:32    91:57  +34   81
 5. Brentford                     46  18  4  1  55:18    6  5 12  28:37    83:55  +28   81
 6. Gillingham                    46  16  5  2  45:13    7  4 12  25:37    70:50  +20   78
 7. Bristol Rovers                46  14  7  2  52:21    6  8  9  30:37    82:58  +24   75
 8. Peterborough United           46  16  3  4  61:33    6  4 13  24:41    85:74  +11   73
 9. Watford                       46  13  8  2  45:21    4  8 11  26:43    71:64   +7   67
10. AFC Bournemouth               46  12  4  7  40:24    6  7 10  32:39    72:63   +9   65
11. Southend United               46  14  4  5  48:24    5  4 14  30:47    78:71   +7   65
12. Grimsby Town                  46  11 10  2  37:21    5  7 11  31:46    68:67   +1   65
13. Queens Park Rangers           46  15  5  3  48:23    2  7 14  24:57    72:80   -8   63
14. Workington                    46  11  7  5  30:22    6  5 12  28:47    58:69  -11   63
15. Reading                       46  12  8  3  45:26    4  6 13  25:44    70:70        62
16. Shrewsbury Town               46  10  6  7  42:38    5  6 12  34:46    76:84   -8   57
17. Scunthorpe United             46   9  8  6  42:27    5  4 14  23:45    65:72   -7   54
18. Exeter City                   46   8  7  8  33:27    4 10  9  18:25    51:52   -1   53
19. Walsall                       46   9  4 10  34:36    6  3 14  21:44    55:80  -25   52
20. Oldham Athletic               46  10  3 10  40:39    3  7 13  21:44    61:83  -22   49
21. Luton Town                    46   6  8  9  32:36    5  3 15  19:58    51:94  -43   44
22. Port Vale                     46   7  6 10  27:33    2  8 13  14:43    41:76  -35   41
23. Colchester United             46   7  6 10  30:34    3  4 16  20:55    50:89  -39   40
24. Barnsley                      46   8  5 10  33:31    1  6 16  21:59    54:90  -36   38
~~~

(Source: `3-division3.csv`)


~~~
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. York City                     46  20  1  2  63:21    8  5 10  28:35    91:56  +35   90
 2. Brighton & Hove Albion        46  18  5  0  68:20    8  6  9  34:37   102:57  +45   89
 3. Tranmere Rovers               46  20  2  1  72:20    7  4 12  27:36    99:56  +43   87
 4. Millwall                      46  13 10  0  45:15   10  6  7  33:30    78:45  +33   85
 5. Oxford United                 46  18  4  1  54:13    5 11  7  33:31    87:44  +43   84
 6. Chester                       46  19  1  3  75:26    6  5 12  44:55   119:81  +38   81
 7. Rochdale                      46  15  4  4  46:22    7 10  6  28:31    74:53  +21   80
 8. Bradford Park Avenue          46  14  8  1  52:22    6  9  8  34:40    86:62  +24   77
 9. Doncaster Rovers              46  13  6  4  46:25    7  5 11  38:47    84:72  +12   71
10. Torquay United                46  11  5  7  41:33   10  2 11  29:37    70:70        70
11. Chesterfield                  46  13  5  5  36:22    7  3 13  22:48    58:70  -12   68
12. Crewe Alexandra               46  11  8  4  55:34    7  5 11  35:47    90:81   +9   67
13. Darlington                    46  14  2  7  52:30    4  4 15  32:57    84:87   -3   60
14. Wrexham                       46  12  5  6  59:37    5  4 14  25:55    84:92   -8   60
15. Newport County                46  14  5  4  54:26    3  3 17  31:55    85:81   +4   59
16. Notts County                  46  12  7  4  43:23    3  7 13  18:50    61:73  -12   59
17. Hartlepool United             46  11 10  2  44:28    4  3 16  17:57    61:85  -24   58
18. Aldershot                     46  14  3  6  46:25    1  4 18  18:59    64:84  -20   52
19. Bradford City                 46   9  2 12  37:36    3  6 14  33:52    70:88  -18   44
20. Barrow                        46   9  4 10  30:38    3  2 18  29:67    59:105 -46   42
21. Southport                     46   5  9  9  35:45    3  7 13  23:44    58:89  -31   40
22. Lincoln City                  46   8  4 11  35:33    3  2 18  23:66    58:99  -41   39
23. Halifax Town                  46   9  4 10  37:37    2  2 19  17:66    54:103 -49   39
24. Stockport County              46   8  4 11  30:34    2  3 18  14:53    44:87  -43   37
~~~

(Source: `4-division4.csv`)



---
Pld = Matches; W = Matches won; D = Matches drawn; L = Matches lost; F = Goals for; A = Goals against; +/- = Goal differencence; Pts = Points

