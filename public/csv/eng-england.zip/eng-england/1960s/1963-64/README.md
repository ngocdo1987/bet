

### Standings


~~~
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. Liverpool                     42  16  0  5  60:18   10  5  6  32:27    92:45  +47   83
 2. Manchester United             42  15  3  3  54:19    8  4  9  36:43    90:62  +28   76
 3. Everton                       42  14  4  3  53:26    7  6  8  31:38    84:64  +20   73
 4. Tottenham Hotspur             42  13  3  5  54:31    9  4  8  43:50    97:81  +16   73
 5. Chelsea                       42  12  3  6  36:24    8  7  6  36:32    72:56  +16   70
 6. Sheffield Wednesday           42  15  3  3  50:24    4  8  9  34:43    84:67  +17   68
 7. Blackburn Rovers              42  10  4  7  44:28    8  6  7  45:37    89:65  +24   64
 8. Arsenal                       42  10  7  4  56:37    7  4 10  34:45    90:82   +8   62
 9. Burnley                       42  14  3  4  46:23    3  7 11  25:41    71:64   +7   61
10. West Bromwich Albion          42   9  6  6  43:35    7  5  9  27:26    70:61   +9   59
11. Leicester City                42   9  4  8  33:27    7  7  7  28:31    61:58   +3   59
12. Sheffield United              42  10  6  5  35:22    6  5 10  26:42    61:64   -3   59
13. Nottingham Forest             42   9  5  7  34:24    7  4 10  30:44    64:68   -4   57
14. West Ham United               42   8  7  6  45:38    6  5 10  24:36    69:74   -5   54
15. Stoke City                    42   9  6  6  49:33    5  4 12  28:45    77:78   -1   52
16. Fulham                        42  11  8  2  45:23    2  5 14  13:42    58:65   -7   52
17. Wolverhampton Wanderers       42   6  9  6  36:34    6  6  9  34:46    70:80  -10   51
18. Blackpool                     42   8  6  7  26:29    5  3 13  26:44    52:73  -21   48
19. Aston Villa                   42   8  6  7  35:29    3  6 12  27:42    62:71   -9   45
20. Birmingham City               42   7  7  7  33:32    4  0 17  21:60    54:92  -38   40
21. Bolton Wanderers              42   6  5 10  30:35    4  3 14  18:45    48:80  -32   38
22. Ipswich Town                  42   9  3  9  38:45    0  4 17  18:76    56:121 -65   34
~~~

(Source: `1-division1.csv`)


~~~
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. Leeds United                  42  12  9  0  35:16   12  6  3  36:18    71:34  +37   87
 2. Sunderland                    42  16  3  2  47:13    9  8  4  34:24    81:37  +44   86
 3. Preston North End             42  13  7  1  37:14   10  3  8  40:40    77:54  +23   79
 4. Southampton                   42  13  3  5  69:31    6  6  9  31:41   100:72  +28   66
 5. Charlton Athletic             42  11  4  6  44:30    8  5  8  31:40    75:70   +5   66
 6. Newcastle United              42  14  2  5  49:26    6  3 12  25:43    74:69   +5   65
 7. Manchester City               42  12  4  5  50:27    6  6  9  34:39    84:66  +18   64
 8. Rotherham United              42  14  3  4  52:26    5  4 12  38:52    90:78  +12   64
 9. Portsmouth                    42   9  7  5  46:34    7  4 10  33:36    79:70   +9   59
10. Northampton Town              42  10  2  9  35:31    6  7  8  22:29    57:60   -3   57
11. Middlesbrough                 42  14  4  3  47:16    1  7 13  20:36    67:52  +15   56
12. Huddersfield Town             42  11  4  6  31:25    4  6 11  26:39    57:64   -7   55
13. Derby County                  42  10  6  5  34:27    4  5 12  22:40    56:67  -11   53
14. Swindon Town                  42  11  5  5  39:22    3  5 13  18:45    57:67  -10   52
15. Cardiff City                  42  10  7  4  31:27    4  3 14  25:54    56:81  -25   52
16. Leyton Orient                 42   8  6  7  32:32    5  4 12  22:40    54:72  -18   49
17. Bury                          42   8  5  8  35:36    5  4 12  22:37    57:73  -16   48
18. Norwich City                  42   9  7  5  43:30    2  6 13  21:50    64:80  -16   46
19. Swansea City                  42  11  4  6  44:26    1  5 15  19:48    63:74  -11   45
20. Plymouth Argyle               42   7  7  7  26:31    2  8 11  19:35    45:66  -21   42
21. Grimsby Town                  42   6  7  8  28:34    3  7 11  19:41    47:75  -28   41
22. Scunthorpe United             42   8  8  5  30:25    2  2 17  22:57    52:82  -30   40
~~~

(Source: `2-division2.csv`)


~~~
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. Crystal Palace                46  17  4  2  38:14    6 10  7  35:37    73:51  +22   83
 2. Coventry City                 46  14  7  2  62:32    8  9  6  36:29    98:61  +37   82
 3. Watford                       46  16  6  1  57:28    7  6 10  22:31    79:59  +20   81
 4. AFC Bournemouth               46  17  4  2  47:15    7  4 12  32:43    79:58  +21   80
 5. Bristol City                  46  13  7  3  52:24    7  8  8  32:40    84:64  +20   75
 6. Reading                       46  15  5  3  49:26    6  5 12  30:36    79:62  +17   73
 7. Mansfield Town                46  15  8  0  51:20    5  3 15  25:42    76:62  +14   71
 8. Oldham Athletic               46  13  3  7  44:35    7  5 11  29:35    73:70   +3   68
 9. Bristol Rovers                46   9  6  8  52:34   10  2 11  39:45    91:79  +12   65
10. Peterborough United           46  13  6  4  52:27    5  5 13  23:43    75:70   +5   65
11. Hull City                     46  11  9  3  45:27    5  8 10  28:41    73:68   +5   65
12. Shrewsbury Town               46  13  6  4  43:19    5  5 13  30:61    73:80   -7   65
13. Queens Park Rangers           46  13  4  6  47:34    5  5 13  29:44    76:78   -2   63
14. Port Vale                     46  13  6  4  35:13    3  8 12  18:36    53:49   +4   62
15. Southend United               46   9 10  4  42:26    6  5 12  35:52    77:78   -1   60
16. Brentford                     46  11  4  8  54:36    4 10  9  33:44    87:80   +7   59
17. Luton Town                    46  12  2  9  42:41    4  8 11  22:39    64:80  -16   58
18. Colchester United             46  10  8  5  45:26    2 11 10  25:42    70:68   +2   55
19. Walsall                       46   7  9  7  34:35    6  5 12  25:41    59:76  -17   53
20. Millwall                      46   9  4 10  33:29    5  6 12  20:38    53:67  -14   52
21. Barnsley                      46   9  9  5  34:29    3  6 14  34:65    68:94  -26   51
22. Crewe Alexandra               46  10  5  8  29:26    1  7 15  21:51    50:77  -27   45
23. Wrexham                       46   9  4 10  50:42    4  2 17  25:65    75:107 -32   45
24. Notts County                  46   7  8  8  29:26    2  1 20  16:66    45:92  -47   36
~~~

(Source: `3-division3.csv`)


~~~
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. Carlisle United               46  17  3  3  70:20    8  7  8  43:38   113:58  +55   85
 2. Gillingham                    46  16  7  0  37:10    7  7  9  22:20    59:30  +29   83
 3. Workington                    46  15  6  2  46:19    9  5  9  30:33    76:52  +24   83
 4. Bradford City                 46  15  3  5  45:24   10  3 10  31:38    76:62  +14   81
 5. Exeter City                   46  12  9  2  39:14    8  9  6  23:23    62:37  +25   78
 6. Torquay United                46  16  6  1  60:20    4  5 14  20:34    80:54  +26   71
 7. Tranmere Rovers               46  12  4  7  46:30    8  7  8  39:43    85:73  +12   71
 8. Brighton & Hove Albion        46  13  3  7  45:22    6  9  8  26:30    71:52  +19   69
 9. Aldershot                     46  15  3  5  58:28    4  7 12  25:50    83:78   +5   67
10. Lincoln City                  46  15  2  6  49:31    4  7 12  18:44    67:75   -8   66
11. Chester                       46  17  3  3  47:18    2  5 16  18:42    65:60   +5   65
12. Halifax Town                  46  14  4  5  47:28    3 10 10  30:49    77:77        65
13. Bradford Park Avenue          46  13  5  5  50:34    5  4 14  25:47    75:81   -6   63
14. Newport County                46  12  3  8  35:24    5  5 13  29:49    64:73   -9   59
15. Doncaster Rovers              46  11  8  4  46:23    4  4 15  24:52    70:75   -5   57
16. Chesterfield                  46   8  9  6  29:27    7  3 13  28:44    57:71  -14   57
17. Stockport County              46  12  7  4  32:19    3  5 15  18:49    50:68  -18   57
18. Oxford United                 46  10  7  6  37:27    4  6 13  22:36    59:63   -4   55
19. Southport                     46  12  6  5  42:29    3  3 17  21:59    63:88  -25   54
20. Darlington                    46   8  9  6  40:37    6  3 14  26:56    66:93  -27   54
21. Rochdale                      46   9  8  6  36:24    3  7 13  20:35    56:59   -3   51
22. York City                     46   9  3 11  29:26    5  4 14  23:40    52:66  -14   49
23. Hartlepool United             46   8  7  8  30:36    4  2 17  24:57    54:93  -39   45
24. Barrow                        46   4 10  9  30:36    2  8 13  21:57    51:93  -42   36
~~~

(Source: `4-division4.csv`)



---
Pld = Matches; W = Matches won; D = Matches drawn; L = Matches lost; F = Goals for; A = Goals against; +/- = Goal differencence; Pts = Points

