

### Standings


~~~
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. Everton                       42  17  3  1  46:19   12  5  4  26:15    72:34  +38   95
 2. Leeds United                  42  15  4  2  50:19    6 11  4  34:30    84:49  +35   78
 3. Chelsea                       42  13  7  1  36:18    8  6  7  34:32    70:50  +20   76
 4. Derby County                  42  15  3  3  45:14    7  6  8  19:23    64:37  +27   75
 5. Liverpool                     42  10  7  4  34:20   10  4  7  31:22    65:42  +23   71
 6. Coventry City                 42   9  6  6  35:28   10  5  6  23:20    58:48  +10   68
 7. Newcastle United              42  14  2  5  42:16    3 11  7  15:19    57:35  +22   64
 8. Stoke City                    42  10  7  4  31:23    5  8  8  25:29    56:52   +4   60
 9. Tottenham Hotspur             42  11  2  8  27:21    6  7  8  27:34    54:55   -1   60
10. Manchester City               42   8  6  7  25:22    8  5  8  30:26    55:48   +7   59
11. Manchester United             42   8  9  4  37:27    6  8  7  29:34    66:61   +5   59
12. Arsenal                       42   7 10  4  29:23    5  8  8  22:26    51:49   +2   54
13. Wolverhampton Wanderers       42   8  8  5  30:23    4  8  9  25:34    55:57   -2   52
14. Burnley                       42   7  7  7  33:29    5  8  8  23:32    56:61   -5   51
15. West Bromwich Albion          42  10  6  5  39:25    4  3 14  19:41    58:66   -8   51
16. West Ham United               42   8  8  5  28:21    4  4 13  23:39    51:60   -9   48
17. Nottingham Forest             42   8  9  4  28:28    2  9 10  22:43    50:71  -21   48
18. Ipswich Town                  42   9  5  7  23:20    1  6 14  17:43    40:63  -23   41
19. Southampton                   42   3 12  6  24:27    3  5 13  22:40    46:67  -21   35
20. Sheffield Wednesday           42   6  5 10  23:27    2  4 15  17:44    40:71  -31   33
21. Crystal Palace                42   5  6 10  20:36    1  9 11  14:32    34:68  -34   33
22. Sunderland                    42   4 11  6  17:24    2  3 16  13:44    30:68  -38   32
~~~

(Source: `1-division1.csv`)


~~~
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. Huddersfield Town             42  14  6  1  36:10   10  6  5  32:27    68:37  +31   84
 2. Blackpool                     42  10  9  2  25:16   10  4  7  31:29    56:45  +11   73
 3. Sheffield United              42  16  2  3  50:10    6  3 12  23:28    73:38  +35   71
 4. Leicester City                42  12  6  3  37:22    7  7  7  27:28    64:50  +14   70
 5. Middlesbrough                 42  15  4  2  36:14    5  6 10  19:31    55:45  +10   70
 6. Cardiff City                  42  12  7  2  38:14    6  6  9  23:27    61:41  +20   67
 7. Swindon Town                  42  13  7  1  35:17    4  9  8  22:30    57:47  +10   67
 8. Blackburn Rovers              42  15  2  4  42:19    5  5 11  12:31    54:50   +4   67
 9. Queens Park Rangers           42  13  5  3  47:24    4  6 11  19:33    66:57   +9   62
10. Norwich City                  42  13  5  3  37:14    3  6 12  12:32    49:46   +3   59
11. Millwall                      42  14  4  3  38:18    1 10 10  18:38    56:56        59
12. Hull City                     42  11  6  4  43:28    4  5 12  29:42    72:70   +2   56
13. Carlisle United               42  10  6  5  39:28    4  7 10  19:28    58:56   +2   55
14. Bristol City                  42  11  7  3  37:13    2  6 13  17:37    54:50   +4   52
15. Oxford United                 42   9  9  3  23:13    3  6 12  12:29    35:42   -7   51
16. Bolton Wanderers              42   9  6  6  31:23    3  6 12  23:38    54:61   -7   48
17. Portsmouth                    42   8  4  9  39:35    5  5 11  27:45    66:80  -14   48
18. Birmingham City               42   9  7  5  33:22    2  4 15  18:56    51:78  -27   44
19. Watford                       42   6  8  7  26:21    3  5 13  18:36    44:57  -13   40
20. Charlton Athletic             42   7  8  6  23:28    0  9 12  12:48    35:76  -41   38
21. Aston Villa                   42   7  8  6  23:21    1  5 15  13:41    36:62  -26   37
22. Preston North End             42   7  6  8  31:28    1  6 14  12:35    43:63  -20   36
~~~

(Source: `2-division2.csv`)


~~~
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. Leyton Orient                 46  16  5  2  43:15    9  7  7  24:21    67:36  +31   87
 2. Luton Town                    46  13  8  2  46:15   10  6  7  31:28    77:43  +34   83
 3. Brighton & Hove Albion        46  16  4  3  37:16    7  5 11  20:27    57:43  +14   78
 4. Bristol Rovers                46  15  5  3  51:26    5 11  7  29:33    80:59  +21   76
 5. Fulham                        46  12  9  2  43:26    8  6  9  38:29    81:55  +26   75
 6. Mansfield Town                46  14  4  5  46:22    7  7  9  24:27    70:49  +21   74
 7. Reading                       46  16  3  4  52:29    5  8 10  35:48    87:77  +10   74
 8. Barnsley                      46  14  6  3  43:24    5  9  9  25:35    68:59   +9   72
 9. Rochdale                      46  11  6  6  39:24    7  4 12  30:36    69:60   +9   64
10. Bradford City                 46  11  6  6  37:22    6  6 11  20:28    57:50   +7   63
11. Doncaster Rovers              46  13  4  6  31:19    4  8 11  21:35    52:54   -2   63
12. Walsall                       46  11  4  8  33:31    6  8  9  21:36    54:67  -13   63
13. Rotherham United              46  10  8  5  36:19    5  6 12  26:35    62:54   +8   59
14. Torquay United                46   9  9  5  36:22    5  8 10  26:37    62:59   +3   59
15. Plymouth Argyle               46  10  7  6  32:23    6  4 13  24:41    56:64   -8   59
16. Tranmere Rovers               46  10  8  5  38:29    4  8 11  18:43    56:72  -16   58
17. Shrewsbury Town               46  10 12  1  35:17    3  6 14  27:46    62:63   -1   57
18. Halifax Town                  46  10  9  4  31:25    4  6 13  16:38    47:63  -16   57
19. Bury                          46  13  4  6  47:29    2  7 14  28:51    75:80   -5   56
20. Gillingham                    46   7  6 10  28:33    6  7 10  24:31    52:64  -12   52
21. Southport                     46  11  5  7  31:22    3  5 15  17:44    48:66  -18   52
22. AFC Bournemouth               46   8  9  6  28:27    4  6 13  20:44    48:71  -23   51
23. Barrow                        46   7  9  7  28:27    1  5 17  18:54    46:81  -35   38
24. Stockport County              46   4  7 12  17:30    2  4 17  10:41    27:71  -44   29
~~~

(Source: `3-division3.csv`)


~~~
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. Chesterfield                  46  19  1  3  55:12    8  9  6  22:20    77:32  +45   91
 2. Wrexham                       46  17  6  0  56:16    9  3 11  28:33    84:49  +35   87
 3. Swansea City                  46  14  8  1  43:14    7 10  6  23:31    66:45  +21   81
 4. Port Vale                     46  13  9  1  39:10    7 10  6  22:23    61:33  +28   79
 5. Brentford                     46  14  8  1  36:11    6  8  9  22:28    58:39  +19   76
 6. Notts County                  46  14  4  5  44:21    8  4 11  29:41    73:62  +11   74
 7. Aldershot                     46  16  5  2  52:22    4  8 11  26:43    78:65  +13   73
 8. Chester                       46  14  3  6  39:23    7  3 13  19:43    58:66   -8   69
 9. Lincoln City                  46  11  8  4  38:20    6  8  9  28:32    66:52  +14   67
10. Peterborough United           46  13  8  2  51:21    4  6 13  26:48    77:69   +8   65
11. Colchester United             46  14  5  4  38:22    3  9 11  26:41    64:63   +1   65
12. Scunthorpe United             46  11  6  6  34:23    7  4 12  33:42    67:65   +2   64
13. York City                     46  14  7  2  38:16    2  7 14  17:46    55:62   -7   62
14. Northampton Town              46  11  7  5  41:19    5  5 13  23:36    64:55   +9   60
15. Crewe Alexandra               46  12  6  5  37:18    4  6 13  14:33    51:51        60
16. Grimsby Town                  46   9  9  5  33:24    5  6 12  21:34    54:58   -4   57
17. Southend United               46  12  8  3  40:28    3  2 18  19:57    59:85  -26   55
18. Exeter City                   46  13  5  5  48:20    1  6 16   9:39    57:59   -2   53
19. Oldham Athletic               46  11  4  8  45:28    2  9 12  15:37    60:65   -5   52
20. Workington                    46   9  9  5  31:21    3  5 15  15:43    46:64  -18   50
21. Newport County                46  12  3  8  39:24    1  8 14  14:50    53:74  -21   50
22. Darlington                    46   8  7  8  31:27    5  3 15  22:46    53:73  -20   49
23. Hartlepool United             46   7  7  9  31:30    3  3 17  11:52    42:82  -40   40
24. Bradford Park Avenue          46   6  5 12  23:32    0  6 17  18:64    41:96  -55   29
~~~

(Source: `4-division4.csv`)



---
Pld = Matches; W = Matches won; D = Matches drawn; L = Matches lost; F = Goals for; A = Goals against; +/- = Goal differencence; Pts = Points

