

### Standings


~~~
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. Manchester City               42  17  2  2  52:16    9  4  8  34:27    86:43  +43   84
 2. Manchester United             42  15  2  4  49:21    9  6  6  40:34    89:55  +34   80
 3. Liverpool                     42  17  2  2  51:17    5  9  7  20:23    71:40  +31   77
 4. Leeds United                  42  17  3  1  49:14    5  6 10  22:27    71:41  +30   75
 5. Everton                       42  18  1  2  43:13    5  5 11  24:27    67:40  +27   75
 6. Tottenham Hotspur             42  11  7  3  44:20    8  2 11  26:39    70:59  +11   66
 7. Chelsea                       42  11  7  3  34:25    7  5  9  28:43    62:68   -6   66
 8. West Bromwich Albion          42  12  4  5  45:25    5  8  8  30:37    75:62  +13   63
 9. Arsenal                       42  12  6  3  37:23    5  4 12  23:33    60:56   +4   61
10. Newcastle United              42  12  7  2  38:20    1  8 12  16:47    54:67  -13   54
11. Nottingham Forest             42  11  6  4  34:22    3  5 13  18:42    52:64  -12   53
12. West Ham United               42   8  5  8  43:30    6  5 10  30:39    73:69   +4   52
13. Burnley                       42  12  7  2  38:16    2  3 16  26:55    64:71   -7   52
14. Leicester City                42   7  7  7  37:34    6  5 10  27:35    64:69   -5   51
15. Wolverhampton Wanderers       42  10  4  7  45:36    4  4 13  21:39    66:75   -9   50
16. Sunderland                    42   8  7  6  28:28    5  4 12  23:33    51:61  -10   50
17. Southampton                   42   9  8  4  37:31    4  3 14  29:52    66:83  -17   50
18. Stoke City                    42  10  3  8  30:29    4  4 13  20:44    50:73  -23   49
19. Sheffield Wednesday           42   6 10  5  32:24    5  2 14  19:39    51:63  -12   45
20. Sheffield United              42   7  4 10  25:31    4  6 11  24:39    49:70  -21   43
21. Coventry City                 42   8  5  8  32:32    1 10 10  19:39    51:71  -20   42
22. Fulham                        42   6  4 11  27:41    4  3 14  29:57    56:98  -42   37
~~~

(Source: `1-division1.csv`)


~~~
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. Queens Park Rangers           42  18  2  1  45:9     7  6  8  22:27    67:36  +31   83
 2. Blackpool                     42  12  6  3  33:16   12  4  5  38:27    71:43  +28   82
 3. Ipswich Town                  42  12  7  2  45:20   10  8  3  34:24    79:44  +35   81
 4. Birmingham City               42  12  6  3  54:21    7  8  6  29:30    83:51  +32   71
 5. Portsmouth                    42  13  6  2  43:18    5  7  9  25:37    68:55  +13   67
 6. Middlesbrough                 42  10  7  4  39:19    7  5  9  21:35    60:54   +6   63
 7. Millwall                      42   9 10  2  35:16    5  7  9  25:34    60:50  +10   59
 8. Blackburn Rovers              42  13  5  3  34:16    3  6 12  22:33    56:49   +7   59
 9. Norwich City                  42  12  4  5  40:28    4  7 10  20:35    60:63   -3   59
10. Carlisle United               42   9  9  3  38:22    5  4 12  20:30    58:52   +6   55
11. Crystal Palace                42  11  4  6  34:19    3  7 11  22:37    56:56        53
12. Bolton Wanderers              42   8  6  7  37:28    5  7  9  23:35    60:63   -3   52
13. Aston Villa                   42  10  3  8  35:30    5  4 12  19:34    54:64  -10   52
14. Cardiff City                  42   9  6  6  35:29    4  6 11  25:37    60:66   -6   51
15. Huddersfield Town             42  10  6  5  29:23    3  6 12  17:38    46:61  -15   51
16. Charlton Athletic             42  10  6  5  43:25    2  7 12  20:43    63:68   -5   49
17. Derby County                  42   8  5  8  40:35    5  5 11  31:43    71:78   -7   49
18. Bristol City                  42   7  7  7  26:25    6  3 12  22:37    48:62  -14   49
19. Hull City                     42   6  8  7  25:23    6  5 10  33:50    58:73  -15   49
20. Preston North End             42   8  7  6  29:24    4  4 13  14:41    43:65  -22   47
21. Rotherham United              42   7  4 10  22:32    3  7 11  20:44    42:76  -34   41
22. Plymouth Argyle               42   5  4 12  26:36    4  5 12  12:36    38:72  -34   36
~~~

(Source: `2-division2.csv`)


~~~
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. Bury                          46  19  3  1  64:24    5  5 13  27:42    91:66  +25   80
 2. Oxford United                 46  18  3  2  49:20    4 10  9  20:27    69:47  +22   79
 3. Shrewsbury Town               46  14  6  3  42:17    6  9  8  19:32    61:49  +12   75
 4. Torquay United                46  15  6  2  40:17    6  5 12  20:39    60:56   +4   74
 5. Reading                       46  15  5  3  43:17    6  4 13  27:43    70:60  +10   72
 6. Watford                       46  15  3  5  59:20    6  5 12  15:30    74:50  +24   71
 7. Barrow                        46  14  6  3  43:13    7  2 14  22:41    65:54  +11   71
 8. Peterborough United           46  14  4  5  46:23    6  6 11  33:44    79:67  +12   70
 9. Walsall                       46  12  7  4  47:22    7  5 11  27:39    74:61  +13   69
10. Gillingham                    46  13  6  4  35:19    5  6 12  24:44    59:63   -4   66
11. Stockport County              46  16  5  2  49:22    3  4 16  21:53    70:75   -5   66
12. Swindon Town                  46  13  8  2  51:16    3  9 11  23:35    74:51  +23   65
13. Brighton & Hove Albion        46  11  8  4  31:14    5  8 10  26:41    57:55   +2   64
14. AFC Bournemouth               46  13  7  3  39:17    3  8 12  17:34    56:51   +5   63
15. Southport                     46  13  6  4  35:22    4  6 13  30:43    65:65        63
16. Oldham Athletic               46  11  3  9  37:32    7  4 12  23:33    60:65   -5   61
17. Bristol Rovers                46  14  3  6  42:25    3  6 14  30:53    72:78   -6   60
18. Northampton Town              46  10  8  5  40:25    4  5 14  18:47    58:72  -14   55
19. Tranmere Rovers               46  10  7  6  39:28    4  5 14  23:46    62:74  -12   54
20. Leyton Orient                 46  10  6  7  27:24    2 11 10  19:38    46:62  -16   53
21. Grimsby Town                  46  10  7  6  33:21    4  2 17  19:48    52:69  -17   51
22. Mansfield Town                46   8  7  8  32:31    4  6 13  19:36    51:67  -16   49
23. Scunthorpe United             46   8  9  6  36:34    2  3 18  20:53    56:87  -31   42
24. Colchester United             46   6  8  9  29:40    3  7 13  21:47    50:87  -37   42
~~~

(Source: `3-division3.csv`)


~~~
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. Luton Town                    46  19  3  1  55:16    8  9  6  32:28    87:44  +43   93
 2. Barnsley                      46  17  6  0  43:14    7  7  9  25:32    68:46  +22   85
 3. Hartlepool United             46  15  7  1  34:12   10  3 10  26:34    60:46  +14   85
 4. Bradford City                 46  14  5  4  41:22    9  6  8  31:29    72:51  +21   80
 5. Crewe Alexandra               46  13 10  0  44:18    7  8  8  30:31    74:49  +25   78
 6. Chesterfield                  46  15  4  4  47:20    6  7 10  24:30    71:50  +21   74
 7. Southend United               46  12  8  3  45:21    8  6  9  32:37    77:58  +19   74
 8. Wrexham                       46  17  3  3  47:12    3 10 10  25:41    72:53  +19   73
 9. Aldershot                     46  10 11  2  36:19    8  6  9  34:36    70:55  +15   71
10. Doncaster Rovers              46  12  8  3  36:16    6  7 10  30:40    66:56  +10   69
11. Halifax Town                  46  10  6  7  34:24    5 10  8  18:25    52:49   +3   61
12. Brentford                     46  13  4  6  40:24    5  3 15  20:40    60:64   -4   61
13. Newport County                46  11  7  5  32:22    5  6 12  26:40    58:62   -4   61
14. Lincoln City                  46  11  3  9  41:31    6  6 11  30:37    71:68   +3   60
15. Swansea City                  46  11  8  4  38:25    5  2 16  25:52    63:77  -14   58
16. Notts County                  46  10  7  6  27:27    5  4 14  26:52    53:79  -26   56
17. Darlington                    46   6 11  6  31:27    6  6 11  16:26    47:53   -6   53
18. Port Vale                     46  10  5  8  41:31    2 10 11  20:41    61:72  -11   51
19. Rochdale                      46   9  8  6  35:32    3  6 14  16:40    51:72  -21   50
20. Exeter City                   46   9  7  7  30:30    2  9 12  15:35    45:65  -20   49
21. York City                     46   9  6  8  44:30    2  8 13  21:38    65:68   -3   47
22. Chester                       46   6  6 11  35:38    3  8 12  22:40    57:78  -21   41
23. Workington                    46   8  8  7  35:29    2  3 18  19:58    54:87  -33   41
24. Bradford Park Avenue          46   3  7 13  18:35    1  8 14  12:47    30:82  -52   27
~~~

(Source: `4-division4.csv`)



---
Pld = Matches; W = Matches won; D = Matches drawn; L = Matches lost; F = Goals for; A = Goals against; +/- = Goal differencence; Pts = Points

