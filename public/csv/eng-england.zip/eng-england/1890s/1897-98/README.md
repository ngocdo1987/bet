

### Standings


~~~
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. Sheffield United              30   9  4  2  27:14    8  4  3  29:17    56:31  +25   59
 2. Sunderland                    30  12  2  1  27:8     4  3  8  16:22    43:30  +13   53
 3. Wolverhampton Wanderers       30  10  4  1  36:14    4  3  8  21:27    57:41  +16   49
 4. Sheffield Wednesday           30  12  0  3  39:15    3  3  9  12:27    51:42   +9   48
 5. Everton                       30  11  3  1  33:12    2  6  7  15:27    48:39   +9   48
 6. Aston Villa                   30  12  1  2  47:21    2  4  9  14:30    61:51  +10   47
 7. West Bromwich Albion          30   8  5  2  25:16    3  5  7  19:29    44:45   -1   43
 8. Nottingham Forest             30   7  5  3  30:19    4  4  7  17:30    47:49   -2   42
 9. Liverpool                     30   7  4  4  27:16    4  2  9  21:29    48:45   +3   39
10. Derby County                  30  10  3  2  40:19    1  3 11  17:42    57:61   -4   39
11. Bolton Wanderers              30   9  2  4  18:13    2  2 11  10:28    28:41  -13   37
12. Preston North End             30   7  5  3  26:15    1  3 11   9:28    35:43   -8   32
13. Notts County                  30   4  6  5  23:23    4  2  9  13:23    36:46  -10   32
14. Bury                          30   8  3  4  25:19    0  5 10  14:32    39:51  -12   32
15. Stoke City                    30   8  3  4  21:14    0  5 10  14:41    35:55  -20   32
16. Blackburn Rovers              30   4  7  4  20:22    3  3  9  19:32    39:54  -15   31
~~~

(Source: `1-division1.csv`)


~~~
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. Burnley                       30  14  1  0  64:13    6  7  2  16:11    80:24  +56   68
 2. Newcastle United              30  14  0  1  43:10    7  3  5  21:22    64:32  +32   66
 3. Manchester City               30  10  4  1  45:15    5  5  5  21:21    66:36  +30   54
 4. Manchester United             30  11  2  2  42:10    5  4  6  22:25    64:35  +29   54
 5. Arsenal                       30  10  4  1  41:14    6  1  8  28:35    69:49  +20   53
 6. Birmingham City               30  11  1  3  37:18    5  3  7  21:32    58:50   +8   52
 7. Leicester City                30   8  5  2  26:11    5  2  8  20:24    46:35  +11   46
 8. Luton Town                    30  10  2  3  50:13    3  2 10  18:37    68:50  +18   43
 9. Gainsborough Trinity          30  10  4  1  30:12    2  2 11  20:42    50:54   -4   42
10. Walsall                       30   9  3  3  42:15    3  2 10  16:43    58:58        41
11. Blackpool                     30   8  4  3  32:15    2  1 12  17:46    49:61  -12   35
12. Grimsby Town                  30   9  1  5  44:24    1  3 11   8:38    52:62  -10   34
13. Burton Swifts                 30   7  3  5  25:21    1  2 12  13:48    38:69  -31   29
14. Lincoln City                  30   6  3  6  27:27    0  2 13  16:55    43:82  -39   23
15. Darwen                        30   4  1 10  21:32    2  1 12  10:44    31:76  -45   20
16. Loughborough                  30   5  2  8  15:26    1  0 14   9:61    24:87  -63   20
~~~

(Source: `2-division2.csv`)



---
Pld = Matches; W = Matches won; D = Matches drawn; L = Matches lost; F = Goals for; A = Goals against; +/- = Goal differencence; Pts = Points

