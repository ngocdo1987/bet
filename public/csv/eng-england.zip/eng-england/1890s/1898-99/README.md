

### Standings


~~~
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. Aston Villa                   34  15  2  0  58:13    4  5  8  18:27    76:40  +36   64
 2. Liverpool                     34  12  3  2  29:10    7  2  8  20:23    49:33  +16   62
 3. Burnley                       34  11  5  1  32:15    4  4  9  13:32    45:47   -2   54
 4. Everton                       34  10  2  5  25:13    5  6  6  23:28    48:41   +7   53
 5. Sunderland                    34  11  3  3  26:10    4  3 10  15:31    41:41        51
 6. Blackburn Rovers              34   9  5  3  41:23    5  3  9  19:29    60:52   +8   50
 7. Wolverhampton Wanderers       34   9  5  3  30:13    5  2 10  24:35    54:48   +6   49
 8. Bury                          34   9  5  3  31:18    5  2 10  17:31    48:49   -1   49
 9. Notts County                  34   9  6  2  33:20    3  7  7  14:31    47:51   -4   49
10. Derby County                  34  11  5  1  46:19    1  6 10  16:38    62:57   +5   47
11. Stoke City                    34  10  4  3  29:17    3  3 11  18:35    47:52   -5   46
12. Nottingham Forest             34   6  6  5  22:18    5  5  7  20:24    42:42        44
13. West Bromwich Albion          34  11  1  5  28:9     1  5 11  14:48    42:57  -15   42
14. Newcastle United              34   9  3  5  33:18    2  5 10  16:30    49:48   +1   41
15. Preston North End             34  10  4  3  29:14    0  5 12  15:33    44:47   -3   39
16. Sheffield United              34   7  8  2  31:20    2  3 12  14:31    45:51   -6   38
17. Bolton Wanderers              34   6  5  6  24:21    3  2 12  13:30    37:51  -14   34
18. Sheffield Wednesday           34   8  2  7  26:24    0  6 11   6:37    32:61  -29   32
~~~

(Source: `1-division1.csv`)


~~~
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. Manchester City               34  15  1  1  64:10    8  5  4  28:25    92:35  +57   75
 2. Glossop North End             34  12  1  4  48:13    8  5  4  28:25    76:38  +38   66
 3. Leicester City                34  12  5  0  35:12    6  4  7  29:30    64:42  +22   63
 4. Manchester United             34  12  4  1  51:14    7  1  9  16:29    67:43  +24   62
 5. New Brighton Tower            34  13  2  2  48:13    5  5  7  23:39    71:52  +19   61
 6. Arsenal                       34  14  2  1  55:10    4  3 10  17:31    72:41  +31   59
 7. Birmingham City               34  14  1  2  66:17    3  6  8  19:33    85:50  +35   58
 8. Walsall                       34  12  5  0  64:11    3  7  7  15:25    79:36  +43   57
 9. Port Vale                     34  12  2  3  35:12    5  3  9  21:22    56:34  +22   56
10. Grimsby Town                  34  10  3  4  39:17    5  2 10  32:43    71:60  +11   50
11. Barnsley                      34  11  4  2  44:18    1  3 13   8:38    52:56   -4   43
12. Lincoln City                  34  10  5  2  31:16    2  2 13  20:40    51:56   -5   43
13. Burton Swifts                 34   7  5  5  35:25    3  3 11  16:45    51:70  -19   38
14. Gainsborough Trinity          34   8  4  5  40:22    2  1 14  16:50    56:72  -16   35
15. Luton Town                    34   8  1  8  37:31    2  2 13  14:64    51:95  -44   33
16. Blackpool                     34   6  3  8  35:30    2  1 14  14:60    49:90  -41   28
17. Loughborough                  34   5  4  8  31:26    1  2 14   7:66    38:92  -54   24
18. Darwen                        34   2  4 11  16:32    0  1 16   6:109   22:141 -119   11
~~~

(Source: `2-division2.csv`)



---
Pld = Matches; W = Matches won; D = Matches drawn; L = Matches lost; F = Goals for; A = Goals against; +/- = Goal differencence; Pts = Points

