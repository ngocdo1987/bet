

### Standings


~~~
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. Aston Villa                   34  12  4  1  45:18   10  2  5  32:17    77:35  +42   72
 2. Sheffield United              34  11  5  1  40:11    7  7  3  23:22    63:33  +30   66
 3. Sunderland                    34  12  2  3  27:9     7  1  9  23:26    50:35  +15   60
 4. Wolverhampton Wanderers       34   8  4  5  28:16    7  5  5  20:21    48:37  +11   54
 5. Derby County                  34  11  2  4  32:15    3  6  8  13:28    45:43   +2   50
 6. Newcastle United              34  10  5  2  34:15    3  5  9  19:28    53:43  +10   49
 7. Manchester City               34  10  3  4  33:15    3  5  9  17:29    50:44   +6   47
 8. Liverpool                     34   9  4  4  31:19    5  1 11  18:26    49:45   +4   47
 9. Nottingham Forest             34  12  3  2  42:16    1  5 11  14:39    56:55   +1   47
10. Stoke City                    34   9  5  3  24:15    4  3 10  13:30    37:45   -8   47
11. Everton                       34  11  1  5  30:15    2  6  9  17:34    47:49   -2   46
12. Bury                          34  12  2  3  29:14    1  4 12  11:30    40:44   -4   45
13. Blackburn Rovers              34  12  2  3  38:22    1  2 14  11:39    49:61  -12   43
14. West Bromwich Albion          34   8  6  3  27:11    3  2 12  16:40    43:51   -8   41
15. Preston North End             34   9  3  5  28:20    3  1 13  10:28    38:48  -10   40
16. Notts County                  34   5  7  5  29:22    4  4  9  17:38    46:60  -14   38
17. Burnley                       34  10  2  5  28:17    1  3 13   6:37    34:54  -20   38
18. Glossop North End             34   4  6  7  19:22    0  4 13  12:52    31:74  -43   22
~~~

(Source: `1-division1.csv`)


~~~
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. Sheffield Wednesday           34  17  0  0  61:7     8  4  5  23:15    84:22  +62   79
 2. Bolton Wanderers              34  14  2  1  47:7     8  6  3  32:18    79:25  +54   74
 3. Birmingham City               34  15  1  1  58:12    5  5  7  20:26    78:38  +40   66
 4. Manchester United             34  15  1  1  44:11    5  3  9  19:16    63:27  +36   64
 5. Leicester City                34  11  5  1  34:8     6  4  7  19:28    53:36  +17   60
 6. Grimsby Town                  34  10  3  4  46:24    7  3  7  21:22    67:46  +21   57
 7. Chesterfield                  34  10  4  3  35:24    6  2  9  30:36    65:60   +5   54
 8. Arsenal                       34  13  1  3  47:12    3  3 11  14:31    61:43  +18   52
 9. Lincoln City                  34  11  5  1  31:9     3  3 11  15:34    46:43   +3   50
10. New Brighton Tower            34   9  4  4  44:22    4  5  8  22:36    66:58   +8   48
11. Port Vale                     34  11  2  4  26:16    3  4 10  13:33    39:49  -10   48
12. Walsall                       34  10  5  2  35:18    2  3 12  15:37    50:55   -5   44
13. Gainsborough Trinity          34   8  4  5  37:24    1  3 13  10:51    47:75  -28   34
14. Burton Swifts                 34   8  5  4  31:24    1  1 15  12:60    43:84  -41   33
15. Middlesbrough                 34   8  4  5  28:15    0  4 13  11:54    39:69  -30   32
16. Barnsley                      34   8  5  4  36:23    0  2 15  10:56    46:79  -33   31
17. Luton Town                    34   5  3  9  25:25    0  5 12  15:50    40:75  -35   23
18. Loughborough                  34   1  6 10  12:26    0  0 17   6:74    18:100 -82    9
~~~

(Source: `2-division2.csv`)



---
Pld = Matches; W = Matches won; D = Matches drawn; L = Matches lost; F = Goals for; A = Goals against; +/- = Goal differencence; Pts = Points

