

### Standings


~~~
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. Sunderland                    26  13  0  0  55:11    8  0  5  38:25    93:36  +57   63
 2. Preston North End             26  12  0  1  42:8     6  1  6  19:23    61:31  +30   55
 3. Bolton Wanderers              26   9  2  2  29:14    8  0  5  22:23    51:37  +14   53
 4. Aston Villa                   26  10  0  3  63:23    5  0  8  26:33    89:56  +33   45
 5. Everton                       26   8  2  3  32:22    4  2  7  17:27    49:49        40
 6. Wolverhampton Wanderers       26   8  2  3  34:15    3  2  8  25:31    59:46  +13   37
 7. Notts County                  26   9  3  1  41:12    2  1 10  14:39    55:51   +4   37
 8. Burnley                       26   9  1  3  34:14    2  3  8  15:31    49:45   +4   37
 9. Blackburn Rovers              26   8  3  2  39:26    2  3  8  19:39    58:65   -7   36
10. Derby County                  26   6  3  4  28:18    4  1  8  18:34    46:52   -6   34
11. Accrington F.C.               26   7  3  3  24:20    1  1 11  16:58    40:78  -38   28
12. West Bromwich Albion          26   6  3  4  37:24    0  3 10  14:34    51:58   -7   24
13. Stoke City                    26   5  0  8  19:19    0  4  9  19:42    38:61  -23   19
14. Darwen                        26   4  1  8  31:43    0  2 11   7:69    38:112 -74   15
~~~

(Source: `1-division1.csv`)



---
Pld = Matches; W = Matches won; D = Matches drawn; L = Matches lost; F = Goals for; A = Goals against; +/- = Goal differencence; Pts = Points

