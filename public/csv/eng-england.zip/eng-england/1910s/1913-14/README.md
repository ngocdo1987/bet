

### Standings


~~~
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. Blackburn Rovers              38  14  4  1  51:15    6  7  6  27:27    78:42  +36   71
 2. Aston Villa                   38  11  3  5  36:21    8  3  8  29:29    65:50  +15   63
 3. Middlesbrough                 38  14  2  3  55:20    5  3 11  22:40    77:60  +17   62
 4. Oldham Athletic               38  11  5  3  34:16    6  4  9  21:29    55:45  +10   60
 5. Bolton Wanderers              38  13  4  2  41:14    3  6 10  24:38    65:52  +13   58
 6. West Bromwich Albion          38  11  7  1  30:16    4  6  9  16:26    46:42   +4   58
 7. Sunderland                    38  11  3  5  32:17    6  3 10  31:35    63:52  +11   57
 8. Chelsea                       38  12  3  4  28:18    4  4 11  18:37    46:55   -9   55
 9. Sheffield United              38  11  4  4  36:19    5  1 13  27:41    63:60   +3   53
10. Manchester United             38   8  4  7  27:23    7  2 10  25:39    52:62  -10   51
11. Bradford City                 38   8  6  5  23:17    4  8  7  17:23    40:40        50
12. Manchester City               38   9  3  7  28:23    5  5  9  23:30    51:53   -2   50
13. Newcastle United              38   9  6  4  27:18    4  5 10  12:30    39:48   -9   50
14. Liverpool                     38   8  4  7  27:25    6  3 10  19:37    46:62  -16   49
15. Burnley                       38  10  4  5  43:20    2  8  9  18:33    61:53   +8   48
16. Everton                       38   8  7  4  32:18    4  4 11  14:37    46:55   -9   47
17. Sheffield Wednesday           38   8  4  7  34:34    5  4 10  19:36    53:70  -17   47
18. Tottenham Hotspur             38   9  6  4  30:19    3  4 12  20:43    50:62  -12   46
19. Preston North End             38   9  4  6  39:31    3  2 14  13:38    52:69  -17   42
20. Derby County                  38   6  5  8  34:32    2  6 11  21:39    55:71  -16   35
~~~

(Source: `1-division1.csv`)


~~~
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. Notts County                  38  16  2  1  55:13    7  5  7  22:23    77:36  +41   76
 2. Bradford Park Avenue          38  15  1  3  44:20    8  2  9  27:27    71:47  +24   72
 3. Arsenal                       38  14  3  2  34:10    6  6  7  20:28    54:38  +16   69
 4. Leeds City                    38  15  2  2  54:16    5  5  9  22:30    76:46  +30   67
 5. Barnsley                      38  14  1  4  33:15    5  6  8  18:30    51:45   +6   64
 6. Leyton Orient                 38  14  5  0  38:11    2  6 11   9:24    47:35  +12   59
 7. Wolverhampton Wanderers       38  14  1  4  33:16    4  4 11  18:36    51:52   -1   59
 8. Hull City                     38   9  5  5  29:13    7  4  8  24:24    53:37  +16   57
 9. Bristol City                  38  12  5  2  32:10    4  4 11  20:40    52:50   +2   57
10. Bury                          38  12  6  1  30:14    3  4 12   9:26    39:40   -1   55
11. Fulham                        38  10  3  6  31:20    6  3 10  15:23    46:43   +3   54
12. Stockport County              38   9  6  4  32:18    4  4 11  23:39    55:57   -2   49
13. Huddersfield Town             38   8  4  7  28:22    5  4 10  19:31    47:53   -6   47
14. Grimsby Town                  38  10  4  5  24:15    3  4 12  18:43    42:58  -16   47
15. Birmingham City               38  10  4  5  31:18    2  6 11  17:42    48:60  -12   46
16. Blackpool                     38   6 10  3  24:19    3  4 12   9:25    33:44  -11   41
17. Glossop North End             38   8  3  8  32:24    3  3 13  19:43    51:67  -16   39
18. Leicester City                38   7  2 10  29:28    4  2 13  16:33    45:61  -16   37
19. Lincoln City                  38   8  5  6  23:23    2  1 16  13:43    36:66  -30   36
20. Nottingham Forest             38   7  7  5  27:23    0  2 17  10:53    37:76  -39   30
~~~

(Source: `2-division2.csv`)



---
Pld = Matches; W = Matches won; D = Matches drawn; L = Matches lost; F = Goals for; A = Goals against; +/- = Goal differencence; Pts = Points

