

### Standings


~~~
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. West Bromwich Albion          42  17  1  3  65:21   11  3  7  39:26   104:47  +57   88
 2. Burnley                       42  13  5  3  43:27    8  4  9  22:32    65:59   +6   72
 3. Chelsea                       42  15  3  3  33:10    7  2 12  23:41    56:51   +5   71
 4. Sunderland                    42  17  2  2  45:16    5  2 14  27:43    72:59  +13   70
 5. Liverpool                     42  12  5  4  35:18    7  5  9  24:26    59:44  +15   67
 6. Bolton Wanderers              42  11  3  7  35:29    8  6  7  37:36    72:65   +7   66
 7. Manchester City               42  14  5  2  52:27    4  4 13  19:35    71:62   +9   63
 8. Newcastle United              42  11  5  5  31:13    6  4 11  13:26    44:39   +5   60
 9. Aston Villa                   42  11  3  7  49:36    7  3 11  26:37    75:73   +2   60
10. Arsenal                       42  11  5  5  32:21    4  7 10  24:37    56:58   -2   57
11. Bradford Park Avenue          42   8  6  7  31:26    7  6  8  29:37    60:63   -3   57
12. Sheffield United              42  14  5  2  43:20    2  3 16  16:49    59:69  -10   56
13. Middlesbrough                 42  10  5  6  35:23    5  5 11  26:42    61:65   -4   55
14. Manchester United             42   6  8  7  20:17    7  6  8  34:33    54:50   +4   53
15. Oldham Athletic               42  12  4  5  33:19    3  4 14  16:33    49:52   -3   53
16. Bradford City                 42  10  6  5  36:25    4  5 12  18:38    54:63   -9   53
17. Preston North End             42   9  6  6  35:27    5  4 12  22:46    57:73  -16   52
18. Derby County                  42  12  5  4  36:18    1  7 13  11:39    47:57  -10   51
19. Everton                       42   8  6  7  42:29    4  8  9  27:39    69:68   +1   50
20. Blackburn Rovers              42  11  4  6  48:30    2  7 12  16:47    64:77  -13   50
21. Notts County                  42   9  8  4  39:25    3  4 14  17:49    56:74  -18   48
22. Sheffield Wednesday           42   6  4 11  14:23    1  5 15  14:41    28:64  -36   30
~~~

(Source: `1-division1.csv`)


~~~
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. Tottenham Hotspur             42  19  2  0  60:11   13  4  4  42:21   102:32  +70  102
 2. Huddersfield Town             42  16  4  1  58:13   12  4  5  39:25    97:38  +59   92
 3. Birmingham City               42  14  3  4  54:16   10  5  6  31:18    85:34  +51   80
 4. Blackpool                     42  13  4  4  40:18    8  6  7  25:29    65:47  +18   73
 5. Bury                          42  14  4  3  35:15    6  4 11  25:29    60:44  +16   68
 6. Fulham                        42  11  6  4  36:18    8  3 10  25:32    61:50  +11   66
 7. West Ham United               42  14  3  4  34:14    5  6 10  13:26    47:40   +7   66
 8. Hull City                     42  13  4  4  53:23    5  2 14  25:49    78:72   +6   60
 9. Stoke City                    42  13  3  5  37:15    5  3 13  23:39    60:54   +6   60
10. South Shields                 42  13  5  3  47:18    2  7 12  11:30    58:48  +10   57
11. Bristol City                  42   9  9  3  30:18    4  8  9  16:25    46:43   +3   56
12. Barnsley                      42   9  5  7  41:28    6  5 10  20:27    61:55   +6   55
13. Leicester City                42   8  6  7  26:29    7  4 10  15:32    41:61  -20   55
14. Leyton Orient                 42  14  3  4  34:17    2  3 16  17:42    51:59   -8   54
15. Stockport County              42  11  4  6  34:24    3  5 13  18:37    52:61   -9   51
16. Rotherham County              42  10  4  7  32:27    3  4 14  19:56    51:83  -32   47
17. Port Vale                     34   9  2  6  29:24    3  4 10  13:28    42:52  -10   42
18. Nottingham Forest             42   9  4  8  23:22    2  5 14  20:51    43:73  -30   42
19. Wolverhampton Wanderers       42   8  4  9  41:32    2  6 13  14:48    55:80  -25   40
20. Coventry City                 42   7  7  7  20:26    2  4 15  15:47    35:73  -38   38
21. Lincoln City                  42   8  6  7  27:30    1  3 17  17:71    44:101 -57   36
22. Grimsby Town                  42   8  4  9  23:24    2  1 18  11:51    34:75  -41   35
23. Leeds City                     8   2  1  1   6:3     2  1  1  11:7     17:10   +7   14
~~~

(Source: `2-division2.csv`)



---
Pld = Matches; W = Matches won; D = Matches drawn; L = Matches lost; F = Goals for; A = Goals against; +/- = Goal differencence; Pts = Points

