

### Standings


~~~
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. Sunderland                    38  14  2  3  47:17   11  2  6  39:26    86:43  +43   79
 2. Sheffield Wednesday           38  12  4  3  44:23    9  3  7  31:32    75:55  +20   70
 3. Aston Villa                   38  13  4  2  57:21    6  8  5  29:31    86:52  +34   69
 4. Manchester United             38  13  3  3  41:14    6  5  8  28:29    69:43  +26   65
 5. Manchester City               38  12  3  4  34:15    6  5  8  19:22    53:37  +16   62
 6. Blackburn Rovers              38  10  5  4  54:21    6  8  5  25:22    79:43  +36   61
 7. Derby County                  38  10  2  7  40:29    7  6  6  29:37    69:66   +3   59
 8. Bolton Wanderers              38  10  6  3  36:20    6  4  9  26:43    62:63   -1   58
 9. Oldham Athletic               38  11  7  1  33:12    3  7  9  17:43    50:55   -5   56
10. Liverpool                     38  12  2  5  40:24    4  3 12  21:47    61:71  -10   53
11. Everton                       38   8  2  9  28:31    7  5  7  20:23    48:54   -6   52
12. West Bromwich Albion          38   8  7  4  30:20    5  5  9  27:30    57:50   +7   51
13. Sheffield United              38  10  5  4  36:24    4  1 14  20:46    56:70  -14   48
14. Newcastle United              38   8  5  6  30:23    5  3 11  17:24    47:47        47
15. Bradford City                 38  10  5  4  33:22    2  6 11  17:38    50:60  -10   47
16. Middlesbrough                 38   6  9  4  29:22    5  1 13  26:47    55:69  -14   43
17. Tottenham Hotspur             38   9  3  7  28:25    3  3 13  17:47    45:72  -27   42
18. Chelsea                       38   7  2 10  29:40    4  4 11  22:33    51:73  -22   39
19. Notts County                  38   6  4  9  19:20    1  5 13   9:36    28:56  -28   30
20. Arsenal                       38   1  8 10  11:31    2  4 13  15:43    26:74  -48   21
~~~

(Source: `1-division1.csv`)


~~~
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. Preston North End             38  13  5  1  34:12    6 10  3  22:21    56:33  +23   72
 2. Burnley                       38  13  4  2  58:23    8  4  7  30:30    88:53  +35   71
 3. Birmingham City               38  11  6  2  39:18    7  4  8  20:26    59:44  +15   64
 4. Barnsley                      38  15  3  1  46:18    4  4 11  11:29    57:47  +10   64
 5. Huddersfield Town             38  13  5  1  49:12    4  4 11  17:28    66:40  +26   60
 6. Fulham                        38  13  5  1  47:16    4  0 15  18:39    65:55  +10   56
 7. Leeds City                    38  12  3  4  45:22    3  7  9  25:42    70:64   +6   55
 8. Grimsby Town                  38  10  8  1  32:11    5  2 12  19:39    51:50   +1   55
 9. Lincoln City                  38  10  6  3  31:16    5  4 10  19:36    50:52   -2   55
10. Bury                          38  10  6  3  29:14    5  2 12  24:43    53:57   -4   53
11. Wolverhampton Wanderers       38  10  6  3  34:16    4  4 11  22:38    56:54   +2   52
12. Hull City                     38  12  2  5  42:19    3  4 12  18:37    60:56   +4   51
13. Bradford Park Avenue          38  12  4  3  47:18    2  4 13  13:42    60:60        50
14. Leicester City                38  12  2  5  34:20    1  5 13  16:45    50:65  -15   46
15. Nottingham Forest             38   9  3  7  35:25    3  5 11  23:34    58:59   -1   44
16. Leyton Orient                 38   8  6  5  25:20    2  8  9   9:27    34:47  -13   44
17. Glossop North End             38  11  2  6  34:26    1  6 12  15:42    49:68  -19   44
18. Bristol City                  38   7  9  3  32:25    2  6 11  14:47    46:72  -26   42
19. Blackpool                     38   8  4  7  22:22    1  4 14  17:47    39:69  -30   35
20. Stockport County              38   8  4  7  32:23    0  6 13  24:55    56:78  -22   34
~~~

(Source: `2-division2.csv`)



---
Pld = Matches; W = Matches won; D = Matches drawn; L = Matches lost; F = Goals for; A = Goals against; +/- = Goal differencence; Pts = Points

