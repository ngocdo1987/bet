

### Standings


~~~
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. Liverpool                     42  13  3  5  42:24   12  4  5  42:28    84:52  +32   82
 2. Wolverhampton Wanderers       42  15  1  5  66:31   10  5  6  32:25    98:56  +42   81
 3. Stoke City                    42  14  5  2  52:21   10  2  9  38:32    90:53  +37   79
 4. Manchester United             42  17  3  1  61:19    5  9  7  34:35    95:54  +41   78
 5. Blackpool                     42  14  1  6  38:32    8  5  8  33:38    71:70   +1   72
 6. Sheffield United              42  12  4  5  51:32    9  3  9  38:43    89:75  +14   70
 7. Preston North End             42  10  7  4  45:27    8  4  9  31:47    76:74   +2   65
 8. Aston Villa                   42   9  6  6  39:24    9  3  9  28:29    67:53  +14   63
 9. Sunderland                    42  11  3  7  33:27    7  5  9  32:39    65:66   -1   62
10. Everton                       42  13  5  3  40:24    4  4 13  22:43    62:67   -5   60
11. Middlesbrough                 42  11  3  7  46:32    6  5 10  27:36    73:68   +5   59
12. Derby County                  42  13  2  6  44:28    5  3 13  29:51    73:79   -6   59
13. Portsmouth                    42  11  3  7  42:27    5  6 10  24:33    66:60   +6   57
14. Arsenal                       42   9  5  7  43:33    7  4 10  29:37    72:70   +2   57
15. Chelsea                       42   9  3  9  33:39    7  4 10  36:45    69:84  -15   55
16. Grimsby Town                  42   9  6  6  37:35    4  6 11  24:47    61:82  -21   51
17. Blackburn Rovers              42   6  5 10  23:27    8  3 10  22:26    45:53   -8   50
18. Bolton Wanderers              42   8  5  8  30:28    5  3 13  27:41    57:69  -12   47
19. Huddersfield Town             42  11  4  6  34:24    2  3 16  19:55    53:79  -26   46
20. Charlton Athletic             42   6  6  9  34:32    5  6 10  23:39    57:71  -14   45
21. Brentford                     42   5  5 11  19:35    4  2 15  26:53    45:88  -43   34
22. Leeds United                  42   6  5 10  30:30    0  1 20  15:60    45:90  -45   24
~~~

(Source: `1-division1.csv`)


~~~
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. Manchester City               42  17  3  1  49:14    9  7  5  29:21    78:35  +43   88
 2. Birmingham City               42  17  2  2  51:11    8  3 10  23:22    74:33  +41   80
 3. Burnley                       42  11  8  2  30:14   11  6  4  35:15    65:29  +36   80
 4. Chesterfield                  42  12  6  3  37:17    6  8  7  21:27    58:44  +14   68
 5. West Bromwich Albion          42  12  4  5  53:37    8  4  9  35:38    88:75  +13   68
 6. Newcastle United              42  11  4  6  60:32    8  6  7  35:30    95:62  +33   67
 7. Tottenham Hotspur             42  11  8  2  35:21    6  6  9  30:32    65:53  +12   65
 8. Coventry City                 42  12  8  1  40:17    4  5 12  26:42    66:59   +7   61
 9. Leicester City                42  11  4  6  42:25    7  3 11  27:39    69:64   +5   61
10. Barnsley                      42  13  2  6  48:29    4  6 11  36:57    84:86   -2   59
11. West Ham United               42  12  4  5  46:31    4  4 13  24:45    70:76   -6   56
12. Luton Town                    42  13  4  4  50:29    3  3 15  21:44    71:73   -2   55
13. Nottingham Forest             42  13  5  3  47:20    2  5 14  22:54    69:74   -5   55
14. Southampton                   42  11  5  5  45:24    4  4 13  24:52    69:76   -7   54
15. Fulham                        42  12  4  5  40:25    3  5 13  23:49    63:74  -11   54
16. Bradford Park Avenue          42   7  6  8  29:28    7  5  9  36:49    65:77  -12   53
17. Millwall                      42   7  7  7  30:30    7  1 13  26:49    56:79  -23   50
18. Bury                          42  11  6  4  62:34    1  6 14  18:44    80:78   +2   48
19. Plymouth Argyle               42  11  3  7  45:34    3  2 16  34:62    79:96  -17   47
20. Sheffield Wednesday           42  10  5  6  39:28    2  3 16  28:60    67:88  -21   44
21. Swansea City                  42   9  1 11  36:40    2  6 13  19:43    55:83  -28   40
22. Newport County                42   9  1 11  41:52    1  2 18  20:81    61:133 -72   33
~~~

(Source: `2-division2.csv`)


~~~
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. Doncaster Rovers              42  15  5  1  67:16   18  1  2  56:24   123:40  +83  105
 2. Rotherham United              42  20  1  0  81:19    9  5  7  33:34   114:53  +61   93
 3. Chester                       42  17  2  2  53:13    8  4  9  42:38    95:51  +44   81
 4. Stockport County              42  17  0  4  50:19    7  2 12  28:34    78:53  +25   74
 5. Bradford City                 42  12  5  4  40:20    8  5  8  22:27    62:47  +15   70
 6. Rochdale                      42   9  5  7  39:25   10  5  6  41:39    80:64  +16   67
 7. Wrexham                       42  13  5  3  43:21    4  7 10  22:30    65:51  +14   63
 8. Crewe Alexandra               42  12  4  5  39:26    5  5 11  31:48    70:74   -4   60
 9. Barrow                        42  10  2  9  28:24    7  5  9  26:38    54:62   -8   58
10. Tranmere Rovers               42  11  5  5  43:33    6  2 13  23:44    66:77  -11   58
11. Lincoln City                  42  12  3  6  52:32    5  2 14  34:55    86:87   -1   56
12. Hull City                     42   9  5  7  25:19    7  3 11  24:34    49:53   -4   56
13. Hartlepool United             42  10  5  6  36:26    5  4 12  28:47    64:73   -9   54
14. Gateshead                     42  10  3  8  39:33    6  3 12  23:39    62:72  -10   54
15. Darlington                    42  12  4  5  48:26    3  2 16  20:54    68:80  -12   51
16. York City                     42   6  4 11  35:42    8  5  8  32:39    67:81  -14   51
17. Carlisle United               42  10  5  6  45:38    4  4 13  25:55    70:93  -23   51
18. New Brighton                  42  11  3  7  37:30    3  5 13  20:47    57:77  -20   50
19. Accrington Stanley            42   8  3 10  37:38    6  1 14  19:54    56:92  -36   46
20. Oldham Athletic               42   6  5 10  29:31    6  3 12  26:49    55:80  -25   44
21. Southport                     42   6  5 10  35:41    1  6 14  18:44    53:85  -32   32
22. Halifax Town                  42   6  3 12  28:36    2  3 16  15:56    43:92  -49   30
~~~

(Source: `3a-division3n.csv`)


~~~
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. Cardiff City                  42  18  3  0  60:11   12  3  6  33:19    93:30  +63   96
 2. Queens Park Rangers           42  15  2  4  42:15    8  9  4  32:25    74:40  +34   80
 3. Bristol City                  42  13  4  4  56:20    7  7  7  38:36    94:56  +38   71
 4. Swindon Town                  42  15  4  2  56:25    4  7 10  28:48    84:73  +11   68
 5. Walsall                       42  11  6  4  42:25    6  6  9  32:34    74:59  +15   63
 6. AFC Bournemouth               42  12  4  5  43:20    6  4 11  29:34    72:54  +18   62
 7. Ipswich Town                  42  11  5  5  33:21    5  9  7  28:32    61:53   +8   62
 8. Southend United               42   9  7  5  38:22    8  3 10  33:38    71:60  +11   61
 9. Port Vale                     42  14  4  3  51:28    3  5 13  17:35    68:63   +5   60
10. Reading                       42  11  6  4  53:30    5  5 11  30:44    83:74   +9   59
11. Torquay United                42  11  5  5  33:23    4  7 10  19:38    52:61   -9   57
12. Bristol Rovers                42   9  6  6  34:26    7  2 12  25:43    59:69  -10   56
13. Watford                       42  11  4  6  39:27    6  1 14  22:49    61:76  -15   56
14. Notts County                  42  11  4  6  35:19    4  6 11  28:44    63:63        55
15. Northampton Town              42  11  5  5  46:33    4  5 12  26:42    72:75   -3   55
16. Exeter City                   42  11  6  4  37:27    4  3 14  23:42    60:69   -9   54
17. Brighton & Hove Albion        42   8  7  6  31:35    5  5 11  23:37    54:72  -18   51
18. Crystal Palace                42   9  7  5  29:19    4  4 13  20:43    49:62  -13   50
19. Leyton Orient                 42  10  5  6  40:28    2  3 16  14:47    54:75  -21   44
20. Aldershot                     42   6  7  8  25:26    4  5 12  23:52    48:78  -30   42
21. Norwich City                  42   6  3 12  38:48    4  5 12  26:52    64:100 -36   38
22. Mansfield Town                42   8  5  8  31:38    1  5 15  17:58    48:96  -48   37
~~~

(Source: `3b-division3s.csv`)



---
Pld = Matches; W = Matches won; D = Matches drawn; L = Matches lost; F = Goals for; A = Goals against; +/- = Goal differencence; Pts = Points

