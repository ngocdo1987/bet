

### Standings


~~~
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. Everton                       42  16  4  1  49:11   10  4  7  27:20    76:31  +45   86
 2. Liverpool                     42  15  3  3  43:16    8  5  8  29:26    72:42  +30   77
 3. Tottenham Hotspur             42  14  3  4  40:14    7  5  9  28:29    68:43  +25   71
 4. Arsenal                       42  12  5  4  31:12    8  5  8  27:23    58:35  +23   70
 5. Norwich City                  42   9 10  2  27:20    8  7  6  26:31    53:51   +2   68
 6. Wimbledon                     42  11  5  5  32:22    8  4  9  25:28    57:50   +7   66
 7. Luton Town                    42  14  5  2  29:13    4  7 10  18:32    47:45   +2   66
 8. Nottingham Forest             42  12  8  1  36:14    6  3 12  28:37    64:51  +13   65
 9. Watford                       42  12  5  4  38:20    6  4 11  29:34    67:54  +13   63
10. Coventry City                 42  14  4  3  35:17    3  8 10  15:28    50:45   +5   63
11. Manchester United             42  13  3  5  38:18    1 11  9  14:27    52:45   +7   56
12. Southampton                   42  11  5  5  44:24    3  5 13  25:44    69:68   +1   52
13. Sheffield Wednesday           42   9  7  5  39:24    4  6 11  19:35    58:59   -1   52
14. Chelsea                       42   8  6  7  30:30    5  7  9  23:34    53:64  -11   52
15. West Ham United               42  10  4  7  33:28    4  6 11  19:39    52:67  -15   52
16. Queens Park Rangers           42   9  7  5  31:27    4  4 13  17:37    48:64  -16   50
17. Newcastle United              42  10  4  7  33:29    2  7 12  14:36    47:65  -18   47
18. Oxford United                 42   8  8  5  30:25    3  5 13  14:44    44:69  -25   46
19. Charlton Athletic             42   7  7  7  26:22    4  4 13  19:33    45:55  -10   44
20. Leicester City                42   9  7  5  39:24    2  2 17  15:52    54:76  -22   42
21. Manchester City               42   8  6  7  28:24    0  9 12   8:33    36:57  -21   39
22. Aston Villa                   42   7  7  7  25:25    1  5 15  20:54    45:79  -34   36
~~~

(Source: `1-division1.csv`)


~~~
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. Derby County                  42  14  6  1  42:18   11  3  7  22:20    64:38  +26   84
 2. Portsmouth                    42  17  2  2  37:11    6  7  8  16:17    53:28  +25   78
 3. Oldham Athletic               42  13  6  2  36:16    9  3  9  29:28    65:44  +21   75
 4. Leeds United                  42  15  4  2  43:16    4  7 10  15:28    58:44  +14   68
 5. Ipswich Town                  42  12  6  3  29:10    5  7  9  30:33    59:43  +16   64
 6. Crystal Palace                42  12  4  5  35:20    7  1 13  16:33    51:53   -2   62
 7. Plymouth Argyle               42  12  6  3  40:23    4  7 10  22:34    62:57   +5   61
 8. Stoke City                    42  11  5  5  40:21    5  5 11  23:32    63:53  +10   58
 9. Sheffield United              42  10  8  3  31:19    5  5 11  19:30    50:49   +1   58
10. Bradford City                 42  10  5  6  36:27    5  5 11  26:35    62:62        55
11. Barnsley                      42   8  7  6  26:23    6  6  9  23:29    49:52   -3   55
12. Blackburn Rovers              42  11  4  6  30:22    4  6 11  15:33    45:55  -10   55
13. Reading                       42  11  4  6  33:23    3  7 11  19:36    52:59   -7   53
14. Hull City                     42  10  6  5  25:22    3  8 10  16:33    41:55  -14   53
15. West Bromwich Albion          42   8  6  7  29:22    5  6 10  22:27    51:49   +2   51
16. Millwall                      42  10  5  6  27:16    4  4 13  12:29    39:45   -6   51
17. Huddersfield Town             42   9  6  6  38:30    4  6 11  16:31    54:61   -7   51
18. Shrewsbury Town               42  11  3  7  24:14    4  3 14  17:39    41:53  -12   51
19. Birmingham City               42   8  9  4  27:21    3  8 10  20:38    47:59  -12   50
20. Sunderland                    42   8  6  7  25:23    4  6 11  24:36    49:59  -10   48
21. Grimsby Town                  42   5  8  8  18:21    5  6 10  21:38    39:59  -20   44
22. Brighton & Hove Albion        42   7  6  8  22:20    2  6 13  15:34    37:54  -17   39
~~~

(Source: `2-division2.csv`)


~~~
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. AFC Bournemouth               46  19  3  1  44:14   10  7  6  32:26    76:40  +36   97
 2. Middlesbrough                 46  16  5  2  38:11   12  5  6  29:19    67:30  +37   94
 3. Swindon Town                  46  14  5  4  37:19   11  7  5  40:28    77:47  +30   87
 4. Wigan Athletic                46  15  5  3  47:26   10  5  8  36:34    83:60  +23   85
 5. Gillingham                    46  16  5  2  42:14    7  4 12  23:34    65:48  +17   78
 6. Bristol City                  46  14  6  3  42:15    7  8  8  21:21    63:36  +27   77
 7. Notts County                  46  14  6  3  52:24    7  7  9  25:32    77:56  +21   76
 8. Walsall                       46  16  4  3  50:27    6  5 12  30:40    80:67  +13   75
 9. Blackpool                     46  11  7  5  35:20    5  9  9  39:39    74:59  +15   64
10. Mansfield Town                46   9  9  5  30:23    6  7 10  22:32    52:55   -3   61
11. Brentford                     46   9  7  7  39:32    6  8  9  25:34    64:66   -2   60
12. Port Vale                     46   8  6  9  43:36    7  6 10  33:34    76:70   +6   57
13. Doncaster Rovers              46  11  8  4  32:19    3  7 13  24:43    56:62   -6   57
14. Rotherham United              46  10  6  7  29:23    5  6 12  19:34    48:57   -9   57
15. Chester                       46   7  9  7  32:28    6  8  9  29:31    61:59   +2   56
16. Bury                          46   9  7  7  30:26    5  6 12  24:34    54:60   -6   55
17. Chesterfield                  46  11  5  7  36:33    2 10 11  20:36    56:69  -13   54
18. Fulham                        46   8  8  7  35:41    4  9 10  24:36    59:77  -18   53
19. Bristol Rovers                46   7  8  8  26:29    6  4 13  23:46    49:75  -26   51
20. York City                     46  11  8  4  34:29    1  5 17  21:50    55:79  -24   49
21. Bolton Wanderers              46   8  5 10  29:26    2 10 11  17:32    46:58  -12   45
22. Carlisle United               46   7  5 11  26:35    3  3 17  13:43    39:78  -39   38
23. Darlington                    46   6 10  7  25:28    1  6 16  20:49    45:77  -32   37
24. Newport County                46   4  9 10  26:34    4  4 15  23:52    49:86  -37   37
~~~

(Source: `3-division3.csv`)


~~~
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. Northampton Town              46  20  2  1  56:20   10  7  6  47:33   103:53  +50   99
 2. Preston North End             46  16  4  3  36:18   10  8  5  36:29    72:47  +25   90
 3. Southend United               46  14  4  5  43:27   11  1 11  25:28    68:55  +13   80
 4. Wolverhampton Wanderers       46  12  3  8  36:24   12  4  7  33:26    69:50  +19   79
 5. Colchester United             46  15  3  5  41:20    6  4 13  23:36    64:56   +8   70
 6. Aldershot                     46  13  5  5  40:22    7  5 11  24:35    64:57   +7   70
 7. Leyton Orient                 46  15  2  6  40:25    5  7 11  24:36    64:61   +3   69
 8. Scunthorpe United             46  15  3  5  52:27    3  9 11  21:30    73:57  +16   66
 9. Wrexham                       46   8 13  2  38:24    7  7  9  32:27    70:51  +19   65
10. Peterborough United           46  10  7  6  29:21    7  7  9  28:29    57:50   +7   65
11. Cambridge United              46  12  6  5  37:23    5  5 13  23:39    60:62   -2   62
12. Swansea City                  46  13  3  7  31:21    4  8 11  25:40    56:61   -5   62
13. Cardiff City                  46   6 12  5  24:18    9  4 10  24:32    48:50   -2   61
14. Exeter City                   46  11 10  2  37:17    0 13 10  16:32    53:49   +4   56
15. Halifax Town                  46  10  5  8  32:32    5  5 13  27:42    59:74  -15   55
16. Hereford United               46  10  6  7  33:23    4  5 14  27:38    60:61   -1   53
17. Crewe Alexandra               46   8  9  6  38:35    5  5 13  32:37    70:72   -2   53
18. Hartlepool United             46   6 11  6  24:30    5  7 11  20:35    44:65  -21   51
19. Stockport County              46   9  6  8  25:27    4  6 13  15:42    40:69  -29   51
20. Tranmere Rovers               46   6 10  7  32:37    5  7 11  22:35    54:72  -18   50
21. Rochdale                      46   8  8  7  31:30    3  9 11  23:43    54:73  -19   50
22. Burnley                       46   9  7  7  31:35    3  6 14  22:39    53:74  -21   49
23. Torquay United                46   8  8  7  28:29    2 10 11  28:43    56:72  -16   48
24. Lincoln City                  46   8  7  8  30:27    4  5 14  15:38    45:65  -20   48
~~~

(Source: `4-division4.csv`)



---
Pld = Matches; W = Matches won; D = Matches drawn; L = Matches lost; F = Goals for; A = Goals against; +/- = Goal differencence; Pts = Points

