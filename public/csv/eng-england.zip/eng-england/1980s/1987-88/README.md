

### Standings


~~~
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. Liverpool                     40  15  5  0  49:9    11  7  2  38:15    87:24  +63   90
 2. Manchester United             40  14  5  1  41:17    9  7  4  30:21    71:38  +33   81
 3. Nottingham Forest             40  11  7  2  40:17    9  6  5  27:22    67:39  +28   73
 4. Everton                       40  14  4  2  34:11    5  9  6  19:16    53:27  +26   70
 5. Queens Park Rangers           40  12  4  4  30:14    7  6  7  18:24    48:38  +10   67
 6. Arsenal                       40  11  4  5  35:16    7  8  5  23:23    58:39  +19   66
 7. Wimbledon                     40   8  9  3  32:20    6  6  8  26:27    58:47  +11   57
 8. Newcastle United              40   9  6  5  32:23    5  8  7  23:30    55:53   +2   56
 9. Luton Town                    40  11  6  3  40:21    3  5 12  17:37    57:58   -1   53
10. Coventry City                 40   6  8  6  23:25    7  6  7  23:28    46:53   -7   53
11. Sheffield Wednesday           40  10  2  8  27:30    5  6  9  25:36    52:66  -14   53
12. Southampton                   40   6  8  6  27:26    6  6  8  22:27    49:53   -4   50
13. Tottenham Hotspur             40   9  5  6  26:23    3  6 11  12:25    38:48  -10   47
14. Norwich City                  40   7  5  8  26:26    5  4 11  14:26    40:52  -12   45
15. Derby County                  40   6  7  7  18:17    4  6 10  17:28    35:45  -10   43
16. West Ham United               40   6  9  5  23:21    3  6 11  17:31    40:52  -12   42
17. Charlton Athletic             40   7  7  6  23:21    2  8 10  15:31    38:52  -14   42
18. Chelsea                       40   7 11  2  24:17    2  4 14  26:51    50:68  -18   42
19. Portsmouth                    40   4  8  8  21:27    3  6 11  15:39    36:66  -30   35
20. Watford                       40   4  5 11  15:24    3  6 11  12:27    27:51  -24   32
21. Oxford United                 40   5  7  8  24:34    1  6 13  20:46    44:80  -36   31
~~~

(Source: `1-division1.csv`)


~~~
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. Millwall                      44  15  3  4  45:23   10  4  8  27:29    72:52  +20   82
 2. Aston Villa                   44   9  7  6  31:21   13  5  4  37:20    68:41  +27   78
 3. Middlesbrough                 44  15  4  3  44:16    7  8  7  19:20    63:36  +27   78
 4. Bradford City                 44  14  3  5  49:26    8  8  6  25:28    74:54  +20   77
 5. Blackburn Rovers              44  12  8  2  38:22    9  6  7  30:30    68:52  +16   77
 6. Crystal Palace                44  16  3  3  50:21    6  6 10  36:38    86:59  +27   75
 7. Leeds United                  44  14  4  4  37:18    5  8  9  24:33    61:51  +10   69
 8. Ipswich Town                  44  14  3  5  38:17    5  6 11  23:35    61:52   +9   66
 9. Manchester City               44  11  4  7  50:28    8  4 10  30:32    80:60  +20   65
10. Oldham Athletic               44  13  4  5  43:27    5  7 10  29:37    72:64   +8   65
11. Stoke City                    44  12  6  4  34:22    5  5 12  16:35    50:57   -7   62
12. Swindon Town                  44  10  7  5  43:25    6  4 12  30:35    73:60  +13   59
13. Leicester City                44  12  5  5  35:20    4  6 12  27:41    62:61   +1   59
14. Barnsley                      44  11  4  7  42:32    4  8 10  19:30    61:62   -1   57
15. Hull City                     44  10  8  4  32:22    4  7 11  22:38    54:60   -6   57
16. Plymouth Argyle               44  12  4  6  44:26    4  4 14  21:41    65:67   -2   56
17. AFC Bournemouth               44   7  7  8  36:30    6  3 13  20:38    56:68  -12   49
18. Shrewsbury Town               44   7  8  7  23:22    4  8 10  19:32    42:54  -12   49
19. Birmingham City               44   7  9  6  20:24    4  6 12  21:42    41:66  -25   48
20. West Bromwich Albion          44   8  7  7  29:26    4  4 14  21:43    50:69  -19   47
21. Sheffield United              44   8  6  8  27:28    5  1 16  18:46    45:74  -29   46
22. Reading                       44   5  7 10  20:25    5  5 12  24:45    44:70  -26   42
23. Huddersfield Town             44   4  6 12  20:38    2  4 16  21:62    41:100 -59   28
~~~

(Source: `2-division2.csv`)


~~~
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. Sunderland                    46  14  7  2  51:22   13  5  5  41:26    92:48  +44   93
 2. Brighton & Hove Albion        46  15  7  1  37:16    8  8  7  32:31    69:47  +22   84
 3. Walsall                       46  15  6  2  39:22    8  7  8  29:28    68:50  +18   82
 4. Notts County                  46  14  4  5  53:24    9  8  6  29:25    82:49  +33   81
 5. Bristol City                  46  14  6  3  51:30    7  6 10  26:32    77:62  +15   75
 6. Northampton Town              46  12  8  3  36:18    6 11  6  34:33    70:51  +19   73
 7. Wigan Athletic                46  11  8  4  36:23    9  4 10  34:38    70:61   +9   72
 8. Bristol Rovers                46  14  5  4  43:19    4  7 12  25:37    68:56  +12   66
 9. Fulham                        46  10  5  8  36:24    9  4 10  33:36    69:60   +9   66
10. Blackpool                     46  13  4  6  45:27    4 10  9  26:35    71:62   +9   65
11. Port Vale                     46  12  8  3  36:19    6  3 14  22:37    58:56   +2   65
12. Brentford                     46   9  8  6  27:23    7  6 10  26:36    53:59   -6   62
13. Gillingham                    46   8  9  6  45:21    6  8  9  32:40    77:61  +16   59
14. Bury                          46   9  7  7  33:26    6  7 10  25:31    58:57   +1   59
15. Chester                       46   9  8  6  29:30    5  8 10  22:32    51:62  -11   58
16. Preston North End             46  10  6  7  30:23    5  7 11  18:36    48:59  -11   58
17. Southend United               46  10  6  7  42:33    4  7 12  23:50    65:83  -18   55
18. Chesterfield                  46  10  5  8  25:28    5  5 13  16:42    41:70  -29   55
19. Mansfield Town                46  10  6  7  25:21    4  6 13  23:38    48:59  -11   54
20. Aldershot                     46  12  3  8  45:32    3  5 15  19:42    64:74  -10   53
21. Rotherham United              46   8  8  7  28:25    4  8 11  22:41    50:66  -16   52
22. Grimsby Town                  46   6  7 10  25:29    6  7 10  23:29    48:58  -10   50
23. York City                     46   4  7 12  27:45    4  2 17  21:46    48:91  -43   33
24. Doncaster Rovers              46   6  5 12  25:36    2  4 17  15:48    40:84  -44   33
~~~

(Source: `3-division3.csv`)


~~~
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. Wolverhampton Wanderers       46  15  3  5  47:19   12  6  5  35:24    82:43  +39   90
 2. Cardiff City                  46  15  6  2  39:14    9  7  7  27:27    66:41  +25   85
 3. Bolton Wanderers              46  15  6  2  42:12    7  6 10  24:30    66:42  +24   78
 4. Scunthorpe United             46  14  5  4  42:20    6 12  5  34:31    76:51  +25   77
 5. Torquay United                46  10  7  6  34:16   11  7  5  32:25    66:41  +25   77
 6. Swansea City                  46   9  7  7  35:28   11  3  9  27:28    62:56   +6   70
 7. Peterborough United           46  10  5  8  28:26   10  5  8  24:27    52:53   -1   70
 8. Leyton Orient                 46  13  4  6  55:27    6  8  9  30:36    85:63  +22   69
 9. Colchester United             46  10  5  8  23:22    9  5  9  24:29    47:51   -4   67
10. Burnley                       46  12  5  6  31:22    8  2 13  26:40    57:62   -5   67
11. Wrexham                       46  13  3  7  46:26    7  3 13  23:32    69:58  +11   66
12. Tranmere Rovers               46  14  2  7  43:20    5  7 11  18:33    61:53   +8   66
13. Scarborough                   46  12  8  3  38:19    5  6 12  18:29    56:48   +8   65
14. Darlington                    46  13  6  4  39:25    5  5 13  32:44    71:69   +2   65
15. Cambridge United              46  10  6  7  32:24    6  7 10  18:28    50:52   -2   61
16. Hartlepool United             46   9  7  7  25:25    6  7 10  25:32    50:57   -7   59
17. Crewe Alexandra               46   7 11  5  25:19    6  8  9  32:34    57:53   +4   58
18. Halifax Town                  46  11  7  5  37:25    3  7 13  17:34    54:59   -5   56
19. Hereford United               46   8  7  8  25:27    6  5 12  16:32    41:59  -18   54
20. Stockport County              46   7  7  9  26:26    5  8 10  18:32    44:58  -14   51
21. Rochdale                      46   5  9  9  28:34    6  6 11  19:42    47:76  -29   48
22. Exeter City                   46   8  6  9  33:29    3  7 13  20:39    53:68  -15   46
23. Carlisle United               46   9  5  9  38:33    3  3 17  19:53    57:86  -29   44
24. Newport County                46   4  5 14  19:36    2  2 19  16:69    35:105 -70   25
~~~

(Source: `4-division4.csv`)



---
Pld = Matches; W = Matches won; D = Matches drawn; L = Matches lost; F = Goals for; A = Goals against; +/- = Goal differencence; Pts = Points

