

### Standings


~~~
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. Everton                       42  16  3  2  58:17   12  3  6  30:26    88:43  +45   90
 2. Liverpool                     42  12  4  5  36:19   10  7  4  32:16    68:35  +33   77
 3. Tottenham Hotspur             42  11  3  7  46:31   12  5  4  32:20    78:51  +27   77
 4. Manchester United             42  13  6  2  47:13    9  4  8  30:34    77:47  +30   76
 5. Southampton                   42  13  4  4  29:18    6  7  8  27:29    56:47   +9   68
 6. Chelsea                       42  13  3  5  38:20    5  9  7  25:28    63:48  +15   66
 7. Arsenal                       42  14  5  2  37:14    5  4 12  24:35    61:49  +12   66
 8. Sheffield Wednesday           42  12  7  2  39:21    5  7  9  19:24    58:45  +13   65
 9. Nottingham Forest             42  13  4  4  35:18    6  3 12  21:30    56:48   +8   64
10. Aston Villa                   42  10  7  4  34:20    5  4 12  26:40    60:60        56
11. Watford                       42  10  5  6  48:30    4  8  9  33:41    81:71  +10   55
12. West Bromwich Albion          42  11  4  6  36:23    5  3 13  22:39    58:62   -4   55
13. Luton Town                    42  12  5  4  40:22    3  4 14  17:39    57:61   -4   54
14. Newcastle United              42  11  4  6  33:26    2  9 10  22:44    55:70  -15   52
15. Leicester City                42  10  4  7  39:25    5  2 14  26:48    65:73   -8   51
16. West Ham United               42   7  8  6  27:23    6  4 11  24:45    51:68  -17   51
17. Ipswich Town                  42   8  7  6  27:20    5  4 12  19:37    46:57  -11   50
18. Coventry City                 42  11  3  7  29:22    4  2 15  18:42    47:64  -17   50
19. Queens Park Rangers           42  11  6  4  41:30    2  5 14  12:42    53:72  -19   50
20. Norwich City                  42   9  6  6  28:24    4  4 13  18:40    46:64  -18   49
21. Sunderland                    42   7  6  8  20:26    3  4 14  20:36    40:62  -22   40
22. Stoke City                    42   3  3 15  18:41    0  5 16   6:50    24:91  -67   17
~~~

(Source: `1-division1.csv`)


~~~
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. Oxford United                 42  18  2  1  62:15    7  7  7  22:21    84:36  +48   84
 2. Birmingham City               42  12  6  3  30:15   13  1  7  29:18    59:33  +26   82
 3. Manchester City               42  14  4  3  42:16    7  7  7  24:24    66:40  +26   74
 4. Portsmouth                    42  11  6  4  39:25    9  8  4  30:25    69:50  +19   74
 5. Blackburn Rovers              42  14  3  4  38:15    7  7  7  28:26    66:41  +25   73
 6. Brighton & Hove Albion        42  13  6  2  31:11    7  6  8  23:23    54:34  +20   72
 7. Leeds United                  42  12  7  2  37:11    7  5  9  29:32    66:43  +23   69
 8. Shrewsbury Town               42  12  6  3  45:22    6  5 10  21:31    66:53  +13   65
 9. Fulham                        42  13  3  5  35:26    6  5 10  33:38    68:64   +4   65
10. Grimsby Town                  42  13  1  7  47:32    5  7  9  25:32    72:64   +8   62
11. Barnsley                      42  11  7  3  27:12    3  9  9  15:30    42:42        58
12. Wimbledon                     42   9  8  4  40:29    7  2 12  31:46    71:75   -4   58
13. Huddersfield Town             42   9  5  7  28:29    6  5 10  24:35    52:64  -12   55
14. Oldham Athletic               42  10  4  7  27:23    5  4 12  22:44    49:67  -18   53
15. Crystal Palace                42   8  7  6  25:27    4  5 12  21:38    46:65  -19   48
16. Charlton Athletic             42   8  7  6  34:30    3  5 13  17:33    51:63  -12   45
17. Carlisle United               42   7  6  8  28:25    5  3 13  23:44    51:69  -18   45
18. Sheffield United              42   7  6  8  31:28    3  8 10  23:38    54:66  -12   44
19. Middlesbrough                 42   6  8  7  22:26    4  2 15  19:31    41:57  -16   40
20. Notts County                  42   6  5 10  25:32    3  4 14  21:42    46:74  -28   36
21. Cardiff City                  42   5  3 13  24:42    4  5 12  23:37    47:79  -32   35
22. Wolverhampton Wanderers       42   5  5 11  18:31    3  5 13  19:47    37:78  -41   34
~~~

(Source: `2-division2.csv`)


~~~
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. Bradford City                 46  15  6  2  44:23   13  4  6  33:22    77:45  +32   94
 2. Millwall                      46  18  5  0  44:12    8  7  8  29:30    73:42  +31   90
 3. Hull City                     46  16  4  3  46:20    9  8  6  32:29    78:49  +29   87
 4. Gillingham                    46  15  5  3  54:29   10  3 10  26:33    80:62  +18   83
 5. Bristol City                  46  17  2  4  46:19    7  7  9  28:28    74:47  +27   81
 6. Bristol Rovers                46  15  6  2  37:13    6  6 11  29:35    66:48  +18   75
 7. Derby County                  46  14  7  2  40:20    5  6 12  25:34    65:54  +11   70
 8. York City                     46  13  5  5  42:22    7  4 12  28:35    70:57  +13   69
 9. Reading                       46   8  7  8  31:29   11  5  7  37:33    68:62   +6   69
10. AFC Bournemouth               46  16  3  4  42:16    3  8 12  15:30    57:46  +11   68
11. Walsall                       46   9  7  7  33:22    9  6  8  25:30    58:52   +6   67
12. Rotherham United              46  11  6  6  36:24    7  5 11  19:31    55:55        65
13. Brentford                     46  13  5  5  42:27    3  9 11  20:37    62:64   -2   62
14. Doncaster Rovers              46  11  5  7  42:33    6  3 14  30:41    72:74   -2   59
15. Plymouth Argyle               46  11  7  5  33:23    4  7 12  29:42    62:65   -3   59
16. Wigan Athletic                46  12  6  5  36:22    3  8 12  24:42    60:64   -4   59
17. Bolton Wanderers              46  12  5  6  38:22    4  1 18  31:53    69:75   -6   54
18. Newport County                46   9  6  8  30:30    4  7 12  25:37    55:67  -12   52
19. Lincoln City                  46   8 11  4  32:20    3  7 13  18:31    50:51   -1   51
20. Swansea City                  46   7  5 11  31:39    5  6 12  22:41    53:80  -27   47
21. Burnley                       46   6  8  9  30:24    5  5 13  30:49    60:73  -13   46
22. Leyton Orient                 46   7  7  9  30:36    4  6 13  21:40    51:76  -25   46
23. Preston North End             46   9  5  9  33:41    4  2 17  18:59    51:100 -49   46
24. Cambridge United              46   2  3 18  17:48    2  6 15  20:47    37:95  -58   21
~~~

(Source: `3-division3.csv`)


~~~
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. Chesterfield                  46  16  6  1  40:13   10  7  6  24:22    64:35  +29   91
 2. Blackpool                     46  15  7  1  42:15    9  7  7  31:24    73:39  +34   86
 3. Darlington                    46  16  4  3  41:22    8  9  6  25:27    66:49  +17   85
 4. Bury                          46  15  6  2  46:20    9  6  8  30:30    76:50  +26   84
 5. Hereford United               46  16  2  5  38:21    6  9  8  27:26    65:47  +18   77
 6. Tranmere Rovers               46  17  1  5  50:21    7  2 14  33:45    83:66  +17   75
 7. Colchester United             46  13  7  3  49:29    7  7  9  38:36    87:65  +22   74
 8. Swindon Town                  46  16  4  3  42:21    5  5 13  20:37    62:58   +4   72
 9. Scunthorpe United             46  14  6  3  61:33    5  8 10  22:29    83:62  +21   71
10. Crewe Alexandra               46  10  7  6  32:28    8  5 10  33:41    65:69   -4   66
11. Peterborough United           46  11  7  5  29:21    5  7 11  25:32    54:53   +1   62
12. Port Vale                     46  11  8  4  39:24    3 10 10  22:35    61:59   +2   60
13. Aldershot                     46  11  6  6  33:20    6  2 15  23:43    56:63   -7   59
14. Mansfield Town                46  10  8  5  25:15    3 10 10  16:23    41:38   +3   57
15. Wrexham                       46  10  6  7  39:27    5  3 15  28:43    67:70   -3   54
16. Chester                       46  11  3  9  35:30    4  6 13  25:42    60:72  -12   54
17. Rochdale                      46   8  7  8  33:30    5  7 11  22:39    55:69  -14   53
18. Exeter City                   46   9  7  7  30:27    4  7 12  27:52    57:79  -22   53
19. Hartlepool United             46  10  6  7  34:29    4  4 15  20:38    54:67  -13   52
20. Southend United               46   8  8  7  30:34    5  3 15  28:49    58:83  -25   50
21. Halifax Town                  46   9  3 11  26:32    6  2 15  16:37    42:69  -27   50
22. Stockport County              46  11  5  7  40:26    2  3 18  18:53    58:79  -21   47
23. Northampton Town              46  10  1 12  32:32    4  4 15  21:42    53:74  -21   47
24. Torquay United                46   5 11  7  18:24    4  3 16  20:39    38:63  -25   41
~~~

(Source: `4-division4.csv`)



---
Pld = Matches; W = Matches won; D = Matches drawn; L = Matches lost; F = Goals for; A = Goals against; +/- = Goal differencence; Pts = Points

