

### Standings


~~~
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. Liverpool                     42  14  3  4  39:14   12  6  3  41:18    80:32  +48   87
 2. Ipswich Town                  42  17  1  3  47:25    9  4  8  28:28    75:53  +22   83
 3. Manchester United             42  12  6  3  27:9    10  6  5  32:20    59:29  +30   78
 4. Tottenham Hotspur             42  12  4  5  41:26    8  7  6  26:22    67:48  +19   71
 5. Arsenal                       42  13  5  3  27:15    7  6  8  21:22    48:37  +11   71
 6. Swansea City                  42  13  3  5  34:16    8  3 10  24:35    58:51   +7   69
 7. Southampton                   42  15  2  4  49:30    4  7 10  23:37    72:67   +5   66
 8. Everton                       42  11  7  3  33:21    6  6  9  23:29    56:50   +6   64
 9. West Ham United               42   9 10  2  42:29    5  6 10  24:28    66:57   +9   58
10. Manchester City               42   9  7  5  32:23    6  6  9  17:27    49:50   -1   58
11. Aston Villa                   42   9  6  6  28:24    6  6  9  27:29    55:53   +2   57
12. Nottingham Forest             42   7  7  7  19:20    8  5  8  23:28    42:48   -6   57
13. Brighton & Hove Albion        42   8  7  6  30:24    5  6 10  13:28    43:52   -9   52
14. Coventry City                 42   9  4  8  31:24    4  7 10  25:38    56:62   -6   50
15. Notts County                  42   8  5  8  32:33    5  3 13  29:36    61:69   -8   47
16. Birmingham City               42   8  6  7  29:25    2  8 11  24:36    53:61   -8   44
17. West Bromwich Albion          42   6  6  9  24:25    5  5 11  22:32    46:57  -11   44
18. Stoke City                    42   9  2 10  27:28    3  6 12  17:35    44:63  -19   44
19. Sunderland                    42   6  5 10  19:26    5  6 10  19:32    38:58  -20   44
20. Leeds United                  42   6 11  4  23:20    4  1 16  16:41    39:61  -22   42
21. Wolverhampton Wanderers       42   8  5  8  19:20    2  5 14  13:43    32:63  -31   40
22. Middlesbrough                 42   5  9  7  20:24    3  6 12  14:28    34:52  -18   39
~~~

(Source: `1-division1.csv`)


~~~
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. Luton Town                    42  16  3  2  48:19    9 10  2  38:27    86:46  +40   88
 2. Watford                       42  13  6  2  46:16   10  5  6  30:26    76:42  +34   80
 3. Norwich City                  42  14  3  4  41:19    8  2 11  23:31    64:50  +14   71
 4. Sheffield Wednesday           42  10  8  3  31:23   10  2  9  24:28    55:51   +4   70
 5. Queens Park Rangers           42  15  4  2  40:9     6  2 13  25:34    65:43  +22   69
 6. Barnsley                      42  13  4  4  33:14    6  6  9  26:27    59:41  +18   67
 7. Rotherham United              42  13  5  3  42:19    7  2 12  24:35    66:54  +12   67
 8. Leicester City                42  12  5  4  31:19    6  7  8  25:29    56:48   +8   66
 9. Newcastle United              42  14  4  3  30:14    4  4 13  22:36    52:50   +2   62
10. Blackburn Rovers              42  11  4  6  26:15    5  7  9  21:28    47:43   +4   59
11. Oldham Athletic               42   9  9  3  28:23    6  5 10  22:28    50:51   -1   59
12. Chelsea                       42  10  5  6  37:30    5  7  9  23:30    60:60        57
13. Charlton Athletic             42  11  5  5  33:22    2  7 12  17:43    50:65  -15   51
14. Cambridge United              42  11  4  6  31:19    2  5 14  17:34    48:53   -5   48
15. Crystal Palace                42   9  2 10  25:26    4  7 10   9:19    34:45  -11   48
16. Derby County                  42   9  8  4  32:23    3  4 14  21:45    53:68  -15   48
17. Grimsby Town                  42   5  8  8  29:30    6  5 10  24:35    53:65  -12   46
18. Shrewsbury Town               42  10  6  5  26:19    1  7 13  11:38    37:57  -20   46
19. Bolton Wanderers              42  10  4  7  28:24    3  3 15  11:37    39:61  -22   46
20. Cardiff City                  42   9  2 10  28:32    3  6 12  17:29    45:61  -16   44
21. Wrexham                       42   9  4  8  22:22    2  7 12  18:34    40:56  -16   44
22. Leyton Orient                 42   6  8  7  23:24    4  1 16  13:37    36:61  -25   39
~~~

(Source: `2-division2.csv`)


~~~
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. Burnley                       46  13  7  3  37:20    8 10  5  29:25    66:45  +21   80
 2. Carlisle United               46  17  4  2  44:21    6  7 10  21:29    65:50  +15   80
 3. Fulham                        46  12  9  2  44:22    9  6  8  33:29    77:51  +26   78
 4. Lincoln City                  46  13  7  3  40:16    8  7  8  26:24    66:40  +26   77
 5. Oxford United                 46  10  8  5  28:18    9  6  8  35:31    63:49  +14   71
 6. Gillingham                    46  14  5  4  44:26    6  6 11  20:30    64:56   +8   71
 7. Southend United               46  11  7  5  35:23    7  8  8  28:28    63:51  +12   69
 8. Millwall                      46  12  4  7  36:28    6  9  8  26:34    62:62        67
 9. Plymouth Argyle               46  12  5  6  37:24    6  6 11  27:32    64:56   +8   65
10. Brentford                     46   8  6  9  28:22   10  5  8  27:27    55:49   +6   65
11. Chesterfield                  46  12  4  7  33:27    6  6 11  24:31    57:58   -1   64
12. Bristol Rovers                46  12  4  7  35:28    6  5 12  23:37    58:65   -7   63
13. Reading                       46  11  6  6  43:35    6  5 12  24:40    67:75   -8   62
14. Portsmouth                    46  11 10  2  33:14    3  9 11  23:37    56:51   +5   61
15. Newport County                46  10 10  3  30:20    5  6 12  26:33    56:53   +3   61
16. Preston North End             46  10  7  6  25:22    6  6 11  25:34    50:56   -6   61
17. Huddersfield Town             46  10  5  8  38:25    5  7 11  26:34    64:59   +5   57
18. Exeter City                   46  14  4  5  46:33    2  5 16  25:51    71:84  -13   57
19. Doncaster Rovers              46   9  9  5  31:24    4  8 11  24:44    55:68  -13   56
20. Walsall                       46  10  7  6  32:23    3  7 13  19:32    51:55   -4   53
21. Wimbledon                     46  10  6  7  33:27    4  5 14  28:48    61:75  -14   53
22. Swindon Town                  46   9  5  9  37:36    4  8 11  18:35    55:71  -16   52
23. Bristol City                  46   7  6 10  24:29    4  7 12  16:36    40:65  -25   46
24. Chester                       46   2 10 11  16:30    5  1 17  20:48    36:78  -42   32
~~~

(Source: `3-division3.csv`)


~~~
                                        - Home -          - Away -            - Total -
                                 Pld   W  D  L   F:A     W  D  L   F:A      F:A   +/-  Pts
 1. Sheffield United              46  15  8  0  53:15   12  7  4  41:26    94:41  +53   96
 2. Bradford City                 46  14  7  2  52:23   12  6  5  36:22    88:45  +43   91
 3. Wigan Athletic                46  17  5  1  47:18    9  8  6  33:28    80:46  +34   91
 4. AFC Bournemouth               46  12 10  1  37:15   11  9  3  25:15    62:30  +32   88
 5. Peterborough United           46  16  3  4  46:22    8  7  8  25:35    71:57  +14   82
 6. Colchester United             46  12  6  5  47:23    8  6  9  35:34    82:57  +25   72
 7. Port Vale                     46   9 12  2  26:17    9  4 10  30:32    56:49   +7   70
 8. Hull City                     46  14  3  6  36:23    5  9  9  34:38    70:61   +9   69
 9. Bury                          46  13  7  3  53:26    4 10  9  27:33    80:59  +21   68
10. Hereford United               46  10  9  4  36:25    6 10  7  28:33    64:58   +6   67
11. Tranmere Rovers               46   7  9  7  27:25    7  9  7  24:31    51:56   -5   60
12. Blackpool                     46  11  5  7  40:26    4  8 11  26:34    66:60   +6   58
13. Darlington                    46  10  5  8  36:28    5  8 10  25:34    61:62   -1   58
14. Hartlepool United             46   9  8  6  39:34    4  8 11  34:50    73:84  -11   55
15. Torquay United                46   9  8  6  30:25    5  5 13  17:34    47:59  -12   55
16. Aldershot                     46   8  7  8  34:29    5  8 10  23:39    57:68  -11   54
17. York City                     46   9  5  9  45:37    5  3 15  24:54    69:91  -22   50
18. Mansfield Town                46   8  6  9  39:39    5  4 14  24:42    63:81  -18   49
19. Stockport County              46  10  5  8  34:28    2  8 13  14:39    48:67  -19   49
20. Halifax Town                  46   6 11  6  28:30    3 11  9  23:42    51:72  -21   49
21. Rochdale                      46   7  9  7  26:22    3  7 13  24:40    50:62  -12   46
22. Northampton Town              46   9  5  9  32:27    2  4 17  25:57    57:84  -27   42
23. Scunthorpe United             46   7  9  7  26:35    2  6 15  17:44    43:79  -36   42
24. Crewe Alexandra               46   3  6 14  19:32    3  3 17  10:52    29:84  -55   27
~~~

(Source: `4-division4.csv`)



---
Pld = Matches; W = Matches won; D = Matches drawn; L = Matches lost; F = Goals for; A = Goals against; +/- = Goal differencence; Pts = Points

